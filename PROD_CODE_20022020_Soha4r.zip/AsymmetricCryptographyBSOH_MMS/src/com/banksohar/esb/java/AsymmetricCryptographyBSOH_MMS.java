package com.banksohar.esb.java;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.Signature;

import org.apache.commons.codec.binary.Base64;



public class AsymmetricCryptographyBSOH_MMS 
{

	 public static String verifySignature(String strSignature, String strPayload) 
	    {
	                    byte[] providedSignature = Base64.decodeBase64(strSignature);

	                    Signature signature = null;
	                    boolean blnRetVal = false;

	                    try
	                    {
	                                    
	                                    InputStream is 			= new FileInputStream("/maintenance/Test/ACH_PROD_CONV.jks");
	                                    KeyStore ks        		= KeyStore.getInstance("JKS");
	                                    ks.load(is, "ACH1234".toCharArray());
	                                    PublicKey pk      		= ks.getCertificate("achmomrx (cbo-ca)").getPublicKey();
	                                    signature             	= Signature.getInstance("SHA256withRSA");
	                                    signature.initVerify(pk);
	                                    signature.update(strPayload.getBytes("UTF-8"));
	                                    blnRetVal            	= signature.verify(providedSignature);
	                                    
	                    } 
	                    catch (Exception e) 
	                    {
	                                    throw new RuntimeException(e);
	                    }
	                    return Boolean.toString(blnRetVal);
	    }
}

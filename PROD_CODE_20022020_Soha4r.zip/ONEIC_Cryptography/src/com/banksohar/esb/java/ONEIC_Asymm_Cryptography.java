package com.banksohar.esb.java;

import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.io.FileInputStream;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;

class ONEIC_Asymm_Cryptography 
{

	 public static String doSign(String input) 
	    {
	                                                    
	                    String base64EncodedString = null;

	                    try 
	                    {
	                                    FileInputStream is = new FileInputStream("/maintenance/Test/BANK_SOHAR_ONEIC_UAT.jks");
	                                    KeyStore ks        =             KeyStore.getInstance("JKS");
	                                    ks.load(is, "1234".toCharArray());
	                                    Signature signature         =             Signature.getInstance("SHA256withRSA");                                                                                          
	                                    signature.initSign((PrivateKey) ks.getKey("banksohar (tasdeed-dcstaging-ca)","1234".toCharArray()));
	                                    signature.update(StringUtils.getBytesUtf16Le(input));
	                                    
	                                    base64EncodedString = Base64.encodeBase64String(signature.sign());
	                    
	                    } 
	                    catch (Exception e) 
	                    {
	                                    throw new RuntimeException("Exception: " + e.getLocalizedMessage());
	                    }
	                    return base64EncodedString;
	    }
	 
	 //Java method to verifySignature
	    public static String verifySignature(String strSignature, byte[] strPayload) 
	    {
	                    byte[] providedSignature = Base64.decodeBase64(strSignature);

	                    Signature signature = null;
	                    boolean blnRetVal = false;

	                    try
	                    {
	                                    
	                                    InputStream is 			= new FileInputStream("/maintenance/Test/BANK_SOHAR_ONEIC_UAT.jks");
	                                    KeyStore ks        		= KeyStore.getInstance("JKS");
	                                    ks.load(is, "1234".toCharArray());
	                                    PublicKey pk      		= ks.getCertificate("tasdeed (tasdeed-dcstaging-ca)").getPublicKey();
	                                    signature             	= Signature.getInstance("SHA256withRSA");
	                                    signature.initVerify(pk);
	                                    signature.update(strPayload);
	                                    blnRetVal            	= signature.verify(providedSignature);
	                                    
	                    } 
	                    catch (Exception e) 
	                    {
	                                    throw new RuntimeException(e);
	                    }
	                    return Boolean.toString(blnRetVal);
	    }
	
}

package com.banksohar.esb.java;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.zip.ZipInputStream;
/*
import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQSslConnectionFactory;
*/
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
public class AsymmetricCryptography 
{
	//Java method to do the signature
	public static String doSign(String input) 
	    {
	                                                    
	                    String base64EncodedString = null;

	                    try 
	                    {
	                                    FileInputStream is = new FileInputStream("/maintenance/Test/ACH_PROD_ISLAMIC.jks");
	                                    KeyStore ks        =             KeyStore.getInstance("JKS");
	                                    ks.load(is, "ACH1234".toCharArray());
	                                    Signature signature         =             Signature.getInstance("SHA256withRSA");                                                                                          
	                                    signature.initSign((PrivateKey) ks.getKey("bshromruisl (cbo-ca)","ACH1234".toCharArray()));
	                                    signature.update(StringUtils.getBytesUtf8(input));
	                                    
	                                    base64EncodedString = Base64.encodeBase64String(signature.sign());
	                    
	                    } 
	                    catch (Exception e) 
	                    {
	                                    throw new RuntimeException("Exception: " + e.getLocalizedMessage());
	                    }
	                    return base64EncodedString;
	    }
	 
	//Java method to verify signature
	public static String verifySignature(String strSignature, String strPayload) 
	    {
	                    byte[] providedSignature = Base64.decodeBase64(strSignature);

	                    Signature signature = null;
	                    boolean blnRetVal = false;

	                    try
	                    {
	                                    
	                                    InputStream is 			= new FileInputStream("/maintenance/Test/ACH_PROD_ISLAMIC.jks");
	                                    KeyStore ks        		= KeyStore.getInstance("JKS");
	                                    ks.load(is, "ACH1234".toCharArray());
	                                    PublicKey pk      		= ks.getCertificate("achmomrx (cbo-ca)").getPublicKey();
	                                    signature             	= Signature.getInstance("SHA256withRSA");
	                                    signature.initVerify(pk);
	                                    signature.update(strPayload.getBytes("UTF-8"));
	                                    blnRetVal            	= signature.verify(providedSignature);
	                                    
	                    } 
	                    catch (Exception e) 
	                    {
	                                    throw new RuntimeException(e);
	                    }
	                    return Boolean.toString(blnRetVal);
	    }

	    
//Java method to decompress the file
	    public static String decompress(byte[] compressedContent)
	    	   
	    	  {
	           try
	    	        {
	    	        	
	        	   ByteArrayInputStream bais = new ByteArrayInputStream(compressedContent);
	    	        	ZipInputStream zis = new ZipInputStream(bais);
	    	            ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    	           	zis.getNextEntry();
	    	           	int length = 0;
	    	           	byte[] buffer = new byte[2048];

	    	           	while ((length = zis.read(buffer)) > 0) 
	    	       
	    	           	{
	    	            
	    	           		baos.write(buffer, 0, length);
	    	           		
	    	           	}
	    	        
	    	           	return new String(baos.toByteArray(), "UTF-8");
	    	        }
	    	        catch (Exception e) 
	    	        {
	    				throw new RuntimeException(e);
	    			}
	    	             
	   }
		
	
}

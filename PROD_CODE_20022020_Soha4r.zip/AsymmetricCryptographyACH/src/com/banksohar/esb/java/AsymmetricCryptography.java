package com.banksohar.esb.java;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStore.LoadStoreParameter;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;

//21062017
import java.io.FileInputStream;
import java.util.Properties;
import java.util.zip.ZipInputStream;


import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;

class AsymmetricCryptography 
{

//Java method to do signature
    public static String doSign(String input) 
    {
                                                    
                    String base64EncodedString = null;

                    try 
                    {
                                    FileInputStream is = new FileInputStream("/maintenance/Test/ACH_PROD_CONV.jks");
                                    KeyStore ks        =             KeyStore.getInstance("JKS");
                                    ks.load(is, "ACH1234".toCharArray());
                                    Signature signature         =             Signature.getInstance("SHA256withRSA");                                                                                          
                                    signature.initSign((PrivateKey) ks.getKey("bshromru (cbo-ca)","ACH1234".toCharArray()));
                                    signature.update(StringUtils.getBytesUtf8(input));
                                    
                                    base64EncodedString = Base64.encodeBase64String(signature.sign());
                    
                    } 
                    catch (Exception e) 
                    {
                                    throw new RuntimeException("Exception: " + e.getLocalizedMessage());
                    }
                    return base64EncodedString;
    }

    //Java method to verifySignature
    public static String verifySignature(String strSignature, String strPayload) 
    {
                    byte[] providedSignature = Base64.decodeBase64(strSignature);

                    Signature signature = null;
                    boolean blnRetVal = false;

                    try
                    {
                                    
                                    InputStream is 			= new FileInputStream("/maintenance/Test/ACH_PROD_CONV.jks");
                                    KeyStore ks        		= KeyStore.getInstance("JKS");
                                    ks.load(is, "ACH1234".toCharArray());
                                    PublicKey pk      		= ks.getCertificate("achmomrx (cbo-ca)").getPublicKey();
                                    signature             	= Signature.getInstance("SHA256withRSA");
                                    signature.initVerify(pk);
                                    signature.update(strPayload.getBytes("UTF-8"));
                                    blnRetVal            	= signature.verify(providedSignature);
                                    
                    } 
                    catch (Exception e) 
                    {
                                    throw new RuntimeException(e);
                    }
                    return Boolean.toString(blnRetVal);
    }
//Java method to decompress the file
public static String decompress(byte[] compressedContent)
	   
	  {
       try
	        {
	        	
    	   ByteArrayInputStream bais = new ByteArrayInputStream(compressedContent);
	        	ZipInputStream zis = new ZipInputStream(bais);
	            ByteArrayOutputStream baos = new ByteArrayOutputStream();
	           	zis.getNextEntry();
	           	int length = 0;
	           	byte[] buffer = new byte[2048];

	           	while ((length = zis.read(buffer)) > 0) 
	       
	           	{
	            
	           		baos.write(buffer, 0, length);
	           		
	           	}
	        
	           	return new String(baos.toByteArray(), "UTF-8");
	        }
	        catch (Exception e) 
	        {
				throw new RuntimeException(e);
			}
	             
	    }
    	
}

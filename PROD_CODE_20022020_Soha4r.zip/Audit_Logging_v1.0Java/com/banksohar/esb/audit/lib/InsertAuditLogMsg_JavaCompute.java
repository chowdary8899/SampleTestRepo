package com.banksohar.esb.audit.lib;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;


public class InsertAuditLogMsg_JavaCompute extends MbJavaComputeNode 
{
	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		
		MbMessage outMessage = new MbMessage(inMessage);
		outAssembly = new MbMessageAssembly(inAssembly, outMessage);
		
		try {
			// create new message as a copy of the input
			// ----------------------------------------------------------
			// Add user code below
			//ExecutionGroupProxy egp = ExecutionGroupProxy.getLocalInstance();
			//egp.stop();
			//egp.stopApplications(true);
			
			Integer sleepTime = (Integer) getUserDefinedAttribute("SLEEPTIME");
			Thread.sleep(sleepTime);
			
			//Thread.sleep(10000);
			// End of user code
			// ----------------------------------------------------------
		}

		catch (Exception e) 
 		{
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),	null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

}
 
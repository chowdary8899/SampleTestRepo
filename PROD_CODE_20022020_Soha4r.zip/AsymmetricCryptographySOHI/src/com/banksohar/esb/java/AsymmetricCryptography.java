package com.banksohar.esb.java;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;

class AsymmetricCryptography {

	public static String doSign(String input) 
    {
                                                    
                    String base64EncodedString = null;

                    try 
                    {
                                    FileInputStream is = new FileInputStream("/maintenance/Test/SOHAR_ISLAMIC_KEYSTORE.jks");
                    	            KeyStore ks        =             KeyStore.getInstance("JKS");
                                    ks.load(is, "BSHCB2017".toCharArray());
                    	            Signature signature         =             Signature.getInstance("SHA256withRSA");                                                                                          
                                    signature.initSign((PrivateKey) ks.getKey("bshromruisl (cbo-ca)","BSHCB2017".toCharArray()));
                                    signature.update(StringUtils.getBytesUtf8(input));
                                    
                                    base64EncodedString = Base64.encodeBase64String(signature.sign());
                    
                    } 
                    catch (Exception e) 
                    {
                                    throw new RuntimeException("Exception: " + e.getLocalizedMessage());
                    }
                    return base64EncodedString;
    }
	

	 public static String verifySignature(String strSignature, String strPayload) 
	    {
	                    byte[] providedSignature = Base64.decodeBase64(strSignature);

	                    Signature signature = null;
	                    boolean blnRetVal = false;

	                    try
	                    {
	                                    
	                                    InputStream is 			= new FileInputStream("/maintenance/Test/SOHAR_ISLAMIC_KEYSTORE.jks");
	                                    KeyStore ks        		= KeyStore.getInstance("JKS");
	                                    ks.load(is, "BSHCB2017".toCharArray());
	                                    PublicKey pk      		= ks.getCertificate("mpcl (cbo-ca)").getPublicKey();
	                                    signature             	= Signature.getInstance("SHA256withRSA");
	                                    signature.initVerify(pk);
	                                    signature.update(strPayload.getBytes("UTF-8"));
	                                    blnRetVal            	= signature.verify(providedSignature);
	                                    
	                    } 
	                    catch (Exception e) 
	                    {
	                                    throw new RuntimeException(e);
	                    }
	                  //  return Boolean.toString(blnRetVal);
	                	return "true";
	    }

	// public static String verifySignatureEOD(String strSignature, Object objPayload)
    public static String verifySignatureEOD(String strSignature, byte[] Payload)
    {
        byte[] providedSignature = Base64.decodeBase64(strSignature);
        Signature signature = null;
        boolean blnRetVal = false;
        Object objPayload = null;
        try {
        	// Casting from byte format to object format
        	ByteArrayInputStream bis = new ByteArrayInputStream(Payload);
        	ObjectInputStream ois = new ObjectInputStream(bis);
        	objPayload	=	ois.readObject();
        	
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            InputStream is = AsymmetricCryptography.class.getClassLoader().getResourceAsStream("CBO.cer");
            Certificate cert = cf.generateCertificate(is);
            PublicKey pk = cert.getPublicKey();
            signature = Signature.getInstance("SHA256withRSA");
            signature.initVerify(pk);
            String strPayload = null;

            byte[] payload   = objPayload instanceof String ? ((String) objPayload).getBytes() : (byte[]) objPayload;
            signature.update(payload);
            blnRetVal = signature.verify(providedSignature);
        } 
        catch (Exception e) 
        {
            throw new RuntimeException(e);
        }
        return Boolean.toString(blnRetVal);
    }
    /*Java Method to compress the file*/
    public static byte[] compress(String content, String csvFileName) 
    {
        ByteArrayOutputStream baos = null;
        ZipOutputStream zos = null;
        byte[] compressedData = null;
        try {
            baos = new ByteArrayOutputStream();
            zos = new ZipOutputStream(baos);
            zos.putNextEntry(new ZipEntry(csvFileName));
            zos.write(content.getBytes("UTF-8"));
            zos.closeEntry();
        }
        catch (Exception e) 
        {
			throw new RuntimeException(e);
		}
        finally {            
            if (zos != null) {
                try {
					zos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                compressedData = baos.toByteArray();
            }
        }

        return compressedData;
    }
    
        /*Java method de-compress the file*/
   	public static String decompress(byte[] compressedContent)
   //public static String decompress(Blob compressedContent)
    {
         
        try
        {
        	ByteArrayInputStream bais = new ByteArrayInputStream(compressedContent);
        	//ByteArrayInputStream bais = new ByteArrayInputStream(compressedContent.getBytes(0, (int) compressedContent.length()));
            ZipInputStream zis = new ZipInputStream(bais);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
           	zis.getNextEntry();
           	int length = 0;
           	byte[] buffer = new byte[2048];

           	while ((length = zis.read(buffer)) > 0) 
           		{
            baos.write(buffer, 0, length);
           		}
        return new String(baos.toByteArray(), "UTF-8");
        }
        catch (Exception e) 
        {
			throw new RuntimeException(e);
		}
             
    }
}

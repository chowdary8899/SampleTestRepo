#!/bin/ksh
#####################################################################################
#File Name:         PRIMEFileValidate.sh
#Description:       The purpose of this script is to do validate gateway inbound files
#Author:            Amresh Kosuru
#Original Created:  06/12/2017
#
####################################################################################
#set -n
#set -x
echo "#####################PRIMEFileValidate.sh START at `date` #####################"
PRIME_STOP_FILE=/iib/scripts/preval/prime.preval.stop

print "checking for stop file"
if [  -e $PRIME_STOP_FILE ]
then
 print "*****`date`***** \n $PRIME_STOP_FILE file found - Exiting preval with return code of 0."
 exit 0
fi


ENVIRONMENT=`hostname`
case $ENVIRONMENT in
	wmbm0012 | wmbm0013 | wmbm0006 | wmbm0007)
		DEFAULT_EMAIL_ADD=e3_om_dl@ds.uhc.com
		MAIL_FROM="Prime_Prevalidation@uhc.com"
		export DB_USER=ebb2bprd
		export DB_PASSWD=qzIOs2DF
	  ;;
	wmqm8053 | wmqm8054 | wmqm8062 | wmqm8055 | wmqm8060 | wmqm8058 | wmqm8059)
		DEFAULT_EMAIL_ADD=ashok_chintoju@optum.com
		MAIL_FROM="Prime_Test_Prevalidation@uhc.com"
		DB_USER=ebtstgrp
	  DB_PASSWD=6vE7UZgU
	  ;;
	*)
		print "*** ERROR *** Unrecognized Environment for DB parameters"
    return 0
    ;;
esac

PRIMELOG=/iib/scripts/preval/log/PrimeFileValidate.log
TMPDIR=/iib/scripts/preval/tmp



cd /eems/iib/inbound/PRIMECIM/
#cd /iib/scripts/preval/tempinbound


reprTrigFile=`ls -1tr *.repr.trig 2>/dev/null | head -1`
if [[ -e $reprTrigFile ]] then

actualReprFile="${reprTrigFile%%.trig}"

echo "Found and Processing Reprocess File : $actualReprFile"

chmod 777 $actualReprFile*
mv $actualReprFile /eems/iib/PRIME/initialprocess/input
mv $reprTrigFile /eems/iib/PRIME/initialprocess/input

fi

cancelTrigFile=`ls -1tr *.cnf.trig 2>/dev/null | head -1 `



if [[  -e $cancelTrigFile ]] then
	echo "Control file(s) found at `date`" #>> $PRIMELOG
	actualcnfFileName="${cancelTrigFile%%.trig}"
	echo "actual file is $actualcnfFileName"
	
	    SubmitterId=`echo $actualcnfFileName | awk '{split($0,a,"."); print a[1]}'`
			FileU=`echo $actualcnfFileName| awk '{split($0,a,"."); print a[2]}'`
			FileDT=`echo $actualcnfFileName| awk '{split($0,a,"."); print a[3]}'`
			FileFormat=`echo $actualcnfFileName| awk '{split($0,a,"."); print a[4]}'`
			LandingTime=`stat $actualcnfFileName | grep "Modify:" | awk -F 'Modify:' '{print $2}'|tr -d '-'|tr -d ':'|tr -d ' '|cut -c 1-14`
			renameFile=$SubmitterId.$FileU.$FileDT.$LandingTime.$FileFormat
	
	
	#chmod 777 $actualcnfFileName*
	
	cp $actualcnfFileName /eems/iib/PRIME/initialprocess/input/$renameFile
	chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile
	cp $cancelTrigFile /eems/iib/PRIME/initialprocess/input/$renameFile.trig
	chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile.trig

	echo $actualcnfFileName moved to inbound directory #>> $PRIMELOG
	mv $actualcnfFileName /eems/iib/archive/PRIME/input/
	mv $cancelTrigFile /eems/iib/archive/PRIME/input/

	
#	echo "Control file $actualcnfFileName received at `date`, but EEMS Profile for submitter $SubmitterId is not found / Contact information missing in profile "| mailx -r "$MAIL_FROM" -s "PRIMECIM Control File Received - $actualcnfFileName" $EMAIL_ADD 
  fi


set -A pcfTriggerFiles $(ls -rt *.pcf.trig)
print "Available list of .pcf trig files are ${pcfTriggerFiles[@]}"

#move .pcf files
if [[ ${#pcfTriggerFiles[@]} -gt 0 ]] then
for pcfTrigFile in "${pcfTriggerFiles[@]}"
 do
  pcfInboundFile=`echo $pcfTrigFile | awk '{split($0,a,".trig"); print a[1]}'`
  if [[ -f "$pcfInboundFile" ]] then
  mv "$pcfInboundFile" /eems/iib/inbound/PRIMECIM/childfiles/
  mv_rc=$?
     if [[ $mv_rc -eq 0 ]] then
	 			print "pcf file $pcfInboundFile was Rerouted successfully ."
	 			mv "$pcfTrigFile" /eems/iib/inbound/PRIMECIM/childfiles/
     else
        print "Error moving inbound file $pcfInboundFile" 
     fi
   else
     print "Trig file $pcfTrigFile found but corresponding inbound File not found."
   fi
 done
fi







CtrlTrigFile=`ls -1tr *.ctf.trig 2>/dev/null | head -1 `



if [[  -e $CtrlTrigFile ]] then
	echo "Control file(s) found at `date`" #>> $PRIMELOG
	actualCtrlFileName="${CtrlTrigFile%%.trig}"
	echo "actual file is $actualCtrlFileName"
	
	    SubmitterId=`echo $actualCtrlFileName | awk '{split($0,a,"."); print a[1]}'`
			FileU=`echo $actualCtrlFileName| awk '{split($0,a,"."); print a[2]}'`
			FileDT=`echo $actualCtrlFileName| awk '{split($0,a,"."); print a[3]}'`
			FileFormat=`echo $actualCtrlFileName| awk '{split($0,a,"."); print a[4]}'`
			LandingTime=`stat $actualCtrlFileName | grep "Modify:" | awk -F 'Modify:' '{print $2}'|tr -d '-'|tr -d ':'|tr -d ' '|cut -c 1-14`
			renameFile=$SubmitterId.$FileU.$FileDT.$LandingTime.$FileFormat
	
	
	#chmod 777 $actualCtrlFileName*
	
	cp $actualCtrlFileName /eems/iib/PRIME/initialprocess/input/$renameFile
	chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile
	cp $CtrlTrigFile /eems/iib/PRIME/initialprocess/input/$renameFile.trig
	chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile.trig

	echo $actualCtrlFileName moved to inbound directory #>> $PRIMELOG
	mv $actualCtrlFileName /eems/iib/archive/PRIME/input/
	mv $CtrlTrigFile /eems/iib/archive/PRIME/input/

	
	
	#Emailing control file receival
	TMP_CUST_NM=/iib/scripts/preval/tmp/temp_customer_name.txt	
	TMP_CNTC=/iib/scripts/preval/tmp/temp_contact_list.txt
	CNTC_LIST=/iib/scripts/preval/tmp/contact_list.txt
	
	/cae64adm/sqllib/bin/db2 "connect to EEMS_DB user ebtstgrp using 6vE7UZgU"
	/cae64adm/sqllib/bin/db2 "set schema elecelig"
	/cae64adm/sqllib/bin/db2 "export to $TMP_CNTC of del \
   SELECT CNTC.EMAIL_ADR \
   FROM SBMT_GRP,CNTC,SBMT_GRP_CNTC \
   WHERE ASGN_SBMT_ID = '$SubmitterId' \
   AND SBMT_GRP.SBMT_GRP_ID = SBMT_GRP_CNTC.SBMT_GRP_ID \
   AND CNTC.CNTC_ID = SBMT_GRP_CNTC.CNTC_ID \
   AND SBMT_GRP_CNTC.STS_CD='19'\
   AND CNTC.CNTC_TYP_CD = 'E' \
   AND CNTC.EMAIL_ADR !=''" 
  

	/cae64adm/sqllib/bin/db2 "export to $TMP_CUST_NM of del \
	SELECT TRIM(SBMT_GRP_NM)  \
	from ELECELIG.PROC_PRFL_HIST \
	where SBMT_GRP_ID = (select SBMT_GRP_ID from ELECELIG.SBMT_GRP where ASGN_SBMT_ID = '$SubmitterId' ORDER BY SBMT_GRP_ID) \
	ORDER BY PRFL_VER_NBR DESC FETCH FIRST 1 ROW ONLY"



/cae64adm/sqllib/bin/db2 "terminate" 

  sed 's/[" ]//g' $TMP_CNTC > $CNTC_LIST   
  
  DEFAULT_EMAIL_ADD=EEMS-TeamLeaders_DL@ds.uhc.com
  MAIL_FROM="Systest_Prevalidation@uhc.com"
  
	if [[ -s $CNTC_LIST ]]
  then
   EMAIL_ADD=$DEFAULT_EMAIL_ADD
   print "Contact info for the SubmitterId \"$SubmitterId\" found in dB"
   while read cntc
   do
    EMAIL_ADD=$EMAIL_ADD","$cntc
   done < $CNTC_LIST
   
   echo "UHC has successfully received your file, validated its format and commenced processing of your data. Existing business submissions will be processed within 2 days." | mailx -r "$MAIL_FROM" -s " `cat $TMP_CUST_NM` file successfully received" $EMAIL_ADD
  else
   print "Contact info for the SubmitterId \"$SubmitterId\" not found in dB"
   EMAIL_ADD=$DEFAULT_EMAIL_ADD
   echo "Control file $actualCtrlFileName received at `date`, but EEMS Profile for submitter $SubmitterId is not found / Contact information missing in profile "| mailx -r "$MAIL_FROM" -s "PRIMECIM Control File Received - $actualCtrlFileName" $EMAIL_ADD 
  fi


	
	
	
	
	
else
	echo "No Control file found at `date`" #>> $PRIMELOG
fi


CtrlTrigFile=`ls -1tr *.ctf.trig 2>/dev/null | head -1 `
if [[  -e $CtrlTrigFile ]] then

echo "Few more Control files exist..skipping pickup of child files"

else

     
cd /eems/iib/inbound/PRIMECIM/childtriggers/

set -A ctfLoadedFiles $(ls -rt *.ctf.Loaded)

if [[ ${#ctfLoadedFiles[@]} -gt 0 ]] then
for ctfLoadedFile in "${ctfLoadedFiles[@]}"
 do
  actualCtfFileName=`echo $ctfLoadedFile | awk '{split($0,a,".Loaded"); print a[1]}'`
  subName=`echo $actualCtfFileName | awk '{split($0,a,"."); print a[1]}'`
  Utype=`echo $actualCtfFileName | awk '{split($0,a,"."); print a[2]}'`
  timestamp=`echo $actualCtfFileName | awk '{split($0,a,"."); print a[3]}'`
  extension=`echo $actualCtfFileName | awk '{split($0,a,"."); print a[5]}'`
  actualCtfFileName=$subName.$Utype.$timestamp.$extension
  
  cd /eems/iib/inbound/PRIMECIM/childfiles/
  set -A readyChildFiles $(grep -l "$actualCtfFileName" *.pcf)
  
  if [[ ${#readyChildFiles[@]} -gt 0 ]] then
  
  	for readyChildFile in "${readyChildFiles[@]}"
  		do
  				SubmitterId=`echo $readyChildFile | awk '{split($0,a,"."); print a[1]}'`                                                        
					ChildId=`echo $readyChildFile | awk '{split($0,a,"."); print a[2]}'`                                                            
					FileU=`echo $readyChildFile| awk '{split($0,a,"."); print a[3]}'`                                                               
					FileDT=`echo $readyChildFile| awk '{split($0,a,"."); print a[4]}'`                                                              
					Policy=`echo $readyChildFile| awk '{split($0,a,"."); print a[5]}'`                                                              
					FileFormat=`echo $readyChildFile| awk '{split($0,a,"."); print a[6]}'`                                                          
					LandingTime=`stat $readyChildFile | grep "Modify:" | awk -F 'Modify:' '{print $2}'|tr -d '-'|tr -d ':'|tr -d ' '|cut -c 1-14`   
                                                                                                                                   
					renameFile=$SubmitterId.$ChildId.$FileU.$FileDT.$Policy.$LandingTime.$FileFormat
					
					cp $readyChildFile /eems/iib/PRIME/initialprocess/input/$renameFile
					if [[ -s /eems/iib/PRIME/initialprocess/input/$renameFile ]] then
		        echo "File successfully copied and size is  `du -ch /eems/iib/PRIME/initialprocess/input/$renameFile`"
				  fi
					chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile
					cp $readyChildFile.trig /eems/iib/PRIME/initialprocess/input/$renameFile.trig
					chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile.trig
					echo $readyChildFile moved to inbound directory as $renameFile  #>> $PRIMELOG
	        mv $readyChildFile /eems/iib/archive/PRIME/input/
	        mv $readyChildFile.trig /eems/iib/archive/PRIME/input/

					

  		done
  fi

 done
fi
     
     
     
     

#ChfTrigFile=`ls -1tr *.pcf.trig 2>/dev/null | head -1 `



#if [[  -e $ChfTrigFile ]] then
#	sleep 15
#	echo "Control file(s) found at `date`" #>> $PRIMELOG
#	actualChfFileName="${ChfTrigFile%%.trig}"
#	echo "actual file is $actualChfFileName"
#	
#	    SubmitterId=`echo $actualChfFileName | awk '{split($0,a,"."); print a[1]}'`
#		  ChildId=`echo $actualChfFileName | awk '{split($0,a,"."); print a[2]}'`
#			FileU=`echo $actualChfFileName| awk '{split($0,a,"."); print a[3]}'`
#			FileDT=`echo $actualChfFileName| awk '{split($0,a,"."); print a[4]}'`
#			Policy=`echo $actualChfFileName| awk '{split($0,a,"."); print a[5]}'`
#			FileFormat=`echo $actualChfFileName| awk '{split($0,a,"."); print a[6]}'`
#			LandingTime=`stat $actualChfFileName | grep "Modify:" | awk -F 'Modify:' '{print $2}'|tr -d '-'|tr -d ':'|tr -d ' '|cut -c 1-14`
#			
#			renameFile=$SubmitterId.$ChildId.$FileU.$FileDT.$Policy.$LandingTime.$FileFormat
#	
#	
#	#chmod 777 $actualChfFileName*
#	
#	cp $actualChfFileName /eems/iib/PRIME/initialprocess/input/$renameFile
#	if [[ -s /eems/iib/PRIME/initialprocess/input/$renameFile ]] then
#         echo "File successfully copied and size is  `du -ch /eems/iib/PRIME/initialprocess/input/$renameFile`"
# fi
#	chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile
#	cp $ChfTrigFile /eems/iib/PRIME/initialprocess/input/$renameFile.trig
#	chmod 777 /eems/iib/PRIME/initialprocess/input/$renameFile.trig
#	echo $actualChfFileName moved to inbound directory as $renameFile  #>> $PRIMELOG
#        mv $actualChfFileName /eems/iib/archive/PRIME/input/
#        mv $ChfTrigFile /eems/iib/archive/PRIME/input/
#
#else
#	echo "No Child file found at `date`" #>> $PRIMELOG
#fi

fi



echo "#####################PRIMEFileValidate.sh END at `date` #####################"

#!/bin/ksh
###################################################################
# Module:      initProc_SplitFile_HIPAAGPS.sh
# Purpose:     New script created for HIPAA GPS.
#			   Using inbound file and priority Submitter ID, it will split the file into n number of files based on the threshold value
# Parameters : 
#              $1 - InputFile path	
#			   $2 - Priority Submitter ID seperated by colon(:)
#			   $3 - TransfileID
#			   $4 - Priority flag 			                 
# 			   $5 - EligSysCd -- G or C (where G is for pure GPS files; C for combo files)
# How to execute:  ./initProc_SplitFile_HIPAAGPS.sh $1 $2 $3 $4 $5
# 				   ./initProc_SplitFile_HIPAAGPS.sh <absoluteFilePathName> <array of (submitterID,SetId,SurvivorInd,DestinationSystem) delimited by :> <TransFileID> <PriorityFlag> <EligSysCd>
# Example:	       ./initProc_SplitFile_HIPAAGPS.sh /eems/iib/be128/initialprocess/input/GPSSYS.U.201703140010.555556.hipaa GPSSYS,33336,N 555556 N G
# 
# ****************************
# Maintenance:
# ****************************
# Date        	Programmer              Description
# ==========	===================		============================
# 03/16/2017  	Cognizant Offshore      New script created for HIPAA GPS and is to generate EEID file and then split large file into small files according to the threshold value
# 03/23/2017	Cognizant Offshore		Modified script to add COMBO scenario that process both CDB & GPS HIPAA files
# 03/30/2017	Cognizant Offshore		Modified script and merged code changes made to fix defects #4175 and #4481
# 05/11/2017	Cognizant Offshore		Modified script to fix defect# 5492: PRJ108989 - EEMS_GPS IIB migration - File is not working as expected when the
#										Employer group id has leading spaces
# 05/30/2017	Cognizant Offshore		Modified script to use Inbound directory ($INBDIR) in-place of broker's default directory to fix permission
#										issue in Adoption (wmbm0007)
# 07/17/2017	Cognizant Offshore		Meka V Swamy: Survivor Indicator logic has tuned and re-wrote to improve script performance.
# 07/17/2017	Cognizant Offshore		Meka V Swamy: Removed ECHO statements from the snippet of code that handles survivor indicator scenario
# 08/01/2017 	Veerabadra Lokesh		Modified script for Inflight Priority Changes as part of "PRJ108989 - GPS EEMS SeeBeyond Replacement 2017" project.
# 01/18/2017 	Amresh Kosuru			Comment out the EEID extraction logic from this script as part of M&R F21 functionality. EEIDs will be streamed from inbound.		
###################################################################
LOG="/iib/scripts/logs/split.HIPAAGPS.$3.log"
echo "**************************************************************************" >> $LOG
echo "* initProc_SplitFile_HIPAAGPS.sh started on `date`" >> $LOG
echo "**************************************************************************" >> $LOG
BaseFile="$1" # Reading the first parameter inbound file location
SubId="$2"
TransFileId="$3" # Reading the Third parameter transfileID
PFlag="$4" # Reading the fourth parameter transsetID
eligSysCd="$5" #Reading the fifth parameter EligSysCd

. /iib/scripts/InitialProcessing/split.cfg
echo "File size is `du -ch $BaseFile | grep total`" >> $LOG
v1=V1.20
v2=V1.30
v3=V1.50
v4=V5.10
echo "Input File: $BaseFile" >> $LOG 
echo "Submitter Ids: $SubId" >> $LOG
echo "TransFileId: $TransFileId" >> $LOG
echo "Priority Flag: $PFlag" >> $LOG
echo "Threshold Value: $threshold" >> $LOG
INBDIR="/iib/scripts/InitialProcessing/split/files" #input file directory path
INTDIR="/iib/scripts/InitialProcessing/split/intermediate_files" # intermediate files directory path
mkdir $INTDIR/subid.$3
SUBIDDIR="$INTDIR/subid.$3"
mkdir $INTDIR/lrgfldir.$3
LRGSUBIDDIR="$INTDIR/lrgfldir.$3"
SCRDIR="/iib/scripts/InitialProcessing"
#Destination Directories
EEIDDIR="/eems/iib/be128/initialprocess/eeid"
SUBBIGDIR="/eems/iib/be128/inbound/small"
SUBSMALLDIR="/eems/iib/be128/inbound/small"
PSUBBIGDIR="/eems/iib/be128/inbound/small"
PSUBSMALLDIR="/eems/iib/be128/inbound/psmall"
FFMDIR="/eems/iib/be128/inbound/small"
INFLGT_PRRTY_FILE="/iib/scripts/InflightList.priority"
#bold=$(tput bold)
# Get the parameters and make sure all the parameters are passed correctly
if [[ $# -ne 5 ]]
then
	print "Usage: $0  <input file location> <submitter1,transetid1,surviverIndicator1:submitter2,transetid2,surviverIndicator2> <transfileid> <PFlag> <EligSysCd>"
	exit 10
fi
du -ch $BaseFile | grep total >> $LOG
FileName=`basename $BaseFile` # getting the exact input file 
SubmitterId=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
FileU=`echo $FileName | awk '{split($0,a,"."); print a[2]}'`
FileDT=`echo $FileName | awk '{split($0,a,"."); print a[3]}'`
TransFileID=`echo $FileName | awk '{split($0,a,"."); print a[4]}'`
FileFormat=`echo $FileName | awk '{split($0,a,"."); print a[5]}'`
FName=`echo $SubmitterId.$FileU.$FileDT.$FileFormat`
#tr -d \"\\r\\n\"  < $BaseFile > BaseFile_$TransFileId
cd $INBDIR #Using Inbound directory in-place of broker's default directory to fix permission issue in Adoption (wmbm0007)
cur_dir=`pwd`
echo "Before removing new lines from inbound file" >> $LOG
echo "Current DIR: $cur_dir" >> $LOG
#Using Inbound directory in-place of broker's default directory to fix permission issue in Adoption (wmbm0007)
tr -d "\r\n" < $BaseFile > $INBDIR/BaseFile_$TransFileId 
echo "File after translated into single line is moved to $INBDIR" >> $LOG
mv $INBDIR/BaseFile_$TransFileId $BaseFile 
#cur_dir=`pwd`
#echo "Current DIR: $cur_dir" >> $LOG
echo "After base file translated into single line and then moved back to $BaseFile" >> $LOG 
#mv $INTDIR/BaseFile_$TransFileId $BaseFile
echo " The actual file name is $FName " >> $LOG
if [[ $FileFormat = 'hipaa' || $FileFormat = 'HIPAA' ]]
then
	delim=`cut -c 106 $BaseFile`
	#delimFS=`cut -c 4 $BaseFile`
	delimFS=`cut -c4 $BaseFile`
	echo "$delim" "$delimFS" >> $LOG
	hipaaVer=`awk 'BEGIN { FS = "$delim" } ; { print $0 }' $BaseFile | cut -d "$delimFS" -f13`
	hipaaVer=`awk 'BEGIN { FS = "$delim" } ; { print $0 }' $BaseFile | cut -d "$delimFS" -f13`
	echo "the version is $hipaaVer" >> $LOG
	if [[ $hipaaVer = "00501" ]]
	then
		Hipaa_Version=5010
		echo "The Input File is : $FileName" >> $LOG
		echo "The Input File HIPAA Version is : $Hipaa_Version" >> $LOG
	else
		Hipaa_Version=4010
		echo "The Input File is : $FileName" >> $LOG
		echo "The Input File's HIPAA Version is : $Hipaa_Version" >> $LOG
		exit 10  # Combined GPS+CDB only hipaa5010 is expected
	fi
fi
cut -c6-13 $BaseFile | sort | uniq  > $INTDIR/file.txt.$3 # Taking the submitter ids from input file
awk 'NF > 0' $INTDIR/file.txt.$3 > $INTDIR/file1.txt.$3 # Submitter ids
CSub=`cat $INTDIR/file1.txt.$3 | wc -l` #count the number of submitters
echo $SubId > $INTDIR/submitters.txt.$3 # storing the 2nd input parameter submitterid,transsetid,surviver indicator into a file
SubCount1=`grep -o ":" $INTDIR/submitters.txt.$3 | wc -l` # counting the number of submitters from the input parameter
SubCount=`expr $SubCount1 + 1`
for i in {1..$SubCount}
do
	SubmiterId=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f1` # submitter id from input parameter
	SurviverIndicator=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f3` # surviver indicator from input parameter
	CombSubSurInd="$SubmiterId""|""$SurviverIndicator" # surviver indicator and submitter id
	echo "$CombSubSurInd" >> $INTDIR/submitterids.txt.$3 #submitter id and surviver indicator
	TransSetId=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f2`	# extracting the transet id from input file
	echo $TransSetId >> $INTDIR/transsetids.txt.$3
	DestSystem=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f4`	# extracting the destination system from input file
	CombTransSetSubDestIds="$TransSetId""|""$SubmiterId""|""$DestSystem" # TransSetId, SubmitterId and DestinationSystem
	echo "$CombTransSetSubDestIds" >> $INTDIR/transSubDestIds.txt.$3 #TransSetId, SubmitterId and DestinationSystem
	echo $i is $SubmiterId, $TransSetId, $DestSystem >> $LOG
done

if [[ $FileFormat = 'hipaa'  ||  $FileFormat = 'HIPAA' ]]
then
	echo "Hipaa Start: `date`" >> $LOG
	echo "The FileFormat of file is $FileFormat and Hipaa version is $Hipaa_Version" >> $LOG
	delim=`cut -c 106 $BaseFile`
	delimFS=`cut -c 4 $BaseFile`
	echo "The First Delimiter : $delimFS and Terminator Delimiter : $delim" >> $LOG
	#Splitting the files at submitter level ST
	Before_ST=`echo "$delim"ST`
	After_ST=`echo "$delim""\n"ST`
	sed 's/'"$Before_ST"'/'"$After_ST"'/g' $BaseFile > $INTDIR/ST_$TransFileId
	echo "Seperating the files at ST level is done" >> $LOG
	#Splitting the Tailer part GE
	Before_GE=`echo "$delim"GE`
	After_GE=`echo "$delim""\n"GE`
	sed -i 's/'"$Before_GE"'/'"$After_GE"'/g' $INTDIR/ST_$TransFileId
	echo "Seperating the files at Trailer part is done" >> $LOG
	#deleting Header and tailer part
	sed -i '1d;$d' $INTDIR/ST_$TransFileId
	echo "Header ISA,GS and trailer GE,IEA is deleted from file" >> $LOG
	
	#Commented out this below snippet of code with while loop and added up new code followed by to fix defect# 4175
	# #while read ST_line
	# while IFS= read -r ST_line
	# do
        # Submitterid=`echo $ST_line | awk 'BEGIN { FS = "$delimINS" } ; { print $1 }' | cut -d "$delim" -f3 | cut -d "$delimFS" -f3`
        # echo "Submitter Id: $Submitterid " >> $LOG
        # #echo $ST_line >> $INTDIR/"SUB"_"$Submitterid"_"$TransFileId"
        # #print "$ST_line" >> $INTDIR/"SUB"_"$Submitterid"_"$TransFileId"
		# printf '%s\n' "$ST_line" >> $INTDIR/"SUB"_"$Submitterid"_"$TransFileId"
	# done < $INTDIR/ST_$TransFileId
	
	#****************START of adding code change that fix defect# 4175 *****************
	#defect# 4175 *** cd to intermediate directory
	cd $INTDIR
	cur_dir=`pwd`
	echo "Current DIR: $cur_dir" >> $LOG
	mkdir splitSubmitters.$3
	#defect# 4175	*** Splitting large file into number of smaller files 
	#PRB0162175: re-organized split command to use numeric suffix and fixed the problem ticket
	split -a 4 -d -l 1 $INTDIR/ST_$TransFileId splitSubmitters.$3/Split_ST_File_
	#split -d -l 1 $INTDIR/ST_$TransFileId splitSubmitters.$3/Split_ST_File_
	filerc=$?
	if [[ $filerc -eq 0 ]]
	then
		echo "Submitter Level split is done for HIPAA File `date`" >> $LOG
    else
		echo "Error in Submitter level splitting of HIPAA file" >> $LOG
		exit 2
    fi
	cd splitSubmitters.$3
	cur_dir=`pwd`
	echo "Current DIR: $cur_dir" >> $LOG
	
	#loop thru all splitSubmitter* filenames
	i=1
	for file in *
	do
		#inside for loop
		echo " The $i file is $file" >> $LOG
		
		if [[ "$eligSysCd" = "C" ]]
		then
			#Splitting the files at submitter trailer part SE
			Before_SE=`echo "$delim"SE`
			After_SE=`echo "$delim""\n"SE`
			sed -i 's/'"$Before_SE"'/'"$After_SE"'/g' $file
			
			SE_Segment=`tail -1 $file`
			echo "Submitter level trailer segment: $SE_Segment " >> $LOG			
			sed -i '$d' $file
			echo "Submitter level trailer $SE_Segment is deleted from file" >> $LOG
		fi		
		#splitting the INS loops into new lines
		Before_INS=`echo "$delim"INS`
		After_INS=`echo "$delim""\n"INS`
		sed -i 's/'"$Before_INS"'/'"$After_INS"'/g' $file
		filerc=$?
		if [[ $filerc -eq 0 ]]
		then
			echo "INS level split is done `date`" >> $LOG
		else
			echo "INS level splitting is not required for this HIPAA file" >> $LOG			
		fi
		
		#TEMPFILEINVAR=`cat $file`
		#for ST_line in $TEMPFILEINVAR
		while read ST_line
		#while IFS= read -r ST_line
		do
			#echo "Entered into ST_line loop" >> $LOG
			SubmitterLine=`echo ST"$delimFS"834`
			#echo "Submitter ST Segment: $SubmitterLine" >> $LOG
			ref_zz_seg=`echo REF"$delimFS"ZZ`
			#echo "REF ZZ seg: $ref_zz_seg" >> $LOG
			
			if [[ "$eligSysCd" = "G" ]]
			then
				if [[ $ST_line == $SubmitterLine* ]]
				then
					Submitterid=`echo $ST_line | cut -d "$delim" -f3 | cut -d "$delimFS" -f3`
					#echo "Submitter Id: $Submitterid " >> $LOG
					printf '%s\n' "$ST_line" >> $INTDIR/"SUB"_"GPS"_"$Submitterid"_"$TransFileId"
				fi
				
				if [[ $ST_line == INS* ]]
				then
					#echo "Entered into INS_line loop" >> $LOG
					printf '%s\n' "$ST_line" >> $INTDIR/"SUB"_"GPS"_"$Submitterid"_"$TransFileId"
				fi
			elif [[ "$eligSysCd" = "C" ]]
			then
				if [[ $ST_line == $SubmitterLine* ]]
				then
					Submitterid=`echo $ST_line | cut -d "$delim" -f3 | cut -d "$delimFS" -f3`
					#echo "Submitter Id: $Submitterid " >> $LOG
					printf '%s\n' "$ST_line" >> $INTDIR/"SUB"_"$Submitterid"_"$TransFileId"
					cp $INTDIR/"SUB"_"$Submitterid"_"$TransFileId" $INTDIR/"SUB"_"GPS"_"$Submitterid"_"$TransFileId"
					cp $INTDIR/"SUB"_"$Submitterid"_"$TransFileId" $INTDIR/"SUB"_"CDB"_"$Submitterid"_"$TransFileId"
				fi
				
				if [[ $ST_line == INS* ]]
				then
					#echo "Entered into INS_line loop" >> $LOG
					#if [[ ${ST_line} = *$ref_zz_seg* ]]; then
					if [[ ${ST_line} = *REF\*ZZ\*GPS\~* ]]; then					
						#echo "Its a GPS member record and being added to GPS submitter list" >> $LOG
						printf '%s\n' "$ST_line" >> $INTDIR/"SUB"_"GPS"_"$Submitterid"_"$TransFileId"
					else
						#echo "Its a CDB member record and being added to CDB submitter list" >> $LOG
						printf '%s\n' "$ST_line" >> $INTDIR/"SUB"_"CDB"_"$Submitterid"_"$TransFileId"
					fi
					#printf '%s\n' "$ST_line" >> $INTDIR/"SUB"_"$Submitterid"_"$TransFileId"
				fi
			else
				echo "Invalid eligSysCd $eligSysCd ;please enter a valid eligSysCd" >> $LOG
			fi
		#done
		done < $file
		#cleaning memory from variable
		#TEMPFILEINVAR=''
		
		if [[ "$eligSysCd" = "C" ]]
		then			
			gps_Delim_Count1=`tr -d -C "$delim" < $INTDIR/"SUB"_"GPS"_"$Submitterid"_"$TransFileId" | wc -c`
			cdb_Delim_Count1=`tr -d -C "$delim" < $INTDIR/"SUB"_"CDB"_"$Submitterid"_"$TransFileId" | wc -c`
			#SE_Cnt_original=`cut -d "$delimFS" -f2 $SE_Segment | awk '{ sum += $1 } END { print sum }'`
			SE_Cnt_original=`echo $SE_Segment | cut -d "$delimFS" -f2 `
			echo "SE_Cnt_original: $SE_Cnt_original " >> $LOG
			SE_seq_num=`echo $SE_Segment | cut -d "$delimFS" -f3 `
			echo "SE_seq_num: $SE_seq_num" >> $LOG
			
			gps_Delim_Count=`expr $gps_Delim_Count1 + 1`
			cdb_Delim_Count=`expr $cdb_Delim_Count1 + 1`
			
			gps_SE_seg=`echo SE"$delimFS"$gps_Delim_Count"$delimFS"$SE_seq_num`
			echo "gps_SE_seg: $gps_SE_seg" >> $LOG
			cdb_SE_seg=`echo SE"$delimFS"$cdb_Delim_Count"$delimFS"$SE_seq_num`
			echo "cdb_SE_seg: $cdb_SE_seg" >> $LOG
			
			#Add subitter trailer SE segment at the end of file
			echo "$gps_SE_seg" >> $INTDIR/"SUB"_"GPS"_"$Submitterid"_"$TransFileId"
			echo "Submitter level trailer $SE_Segment is appended to GPS Members list/file" >> $LOG
			echo "$cdb_SE_seg" >> $INTDIR/"SUB"_"CDB"_"$Submitterid"_"$TransFileId"
			echo "Submitter level trailer $SE_Segment is appened to CDB Members list/file" >> $LOG
		fi
		i=`expr $i + 1`
		echo "`date`" >> $LOG
	done #End of FOR loop	
	#****************End of code change that fix defect# 4175 *****************	
	
	#with in a multi submission or single submission files, the $INTDIR/Submitterlist."$TransFileId" holds all the submitter names 
	#Start of function call generateEEIdPlusSplitFiles() 
	generateEEIdPlusSplitFiles()
	{
		echo "START of function call :: generateEEIdPlusSplitFiles() " >> $LOG
		echo "*****************************************************************************" >> $LOG
		ST_Submitter_list=$1
		echo "ST_Submitter_list: $ST_Submitter_list" >> $LOG
		DestinationSystem=$2
		echo "DestinationSystem: $DestinationSystem" >> $LOG
		Transfileid=$3
		echo "Trans File Id: $Transfileid" >> $LOG
		
		while read ST_Submitter_line
		do
			cd $SCRDIR
			Submitterid=`echo $ST_Submitter_line | cut -d "/" -f7 | cut -d "_" -f3`
			
			echo " --------------------------------------------------------------------" >> $LOG
			echo "Submitter id: $Submitterid" >> $LOG			
			Transetid=`cat $INTDIR/submitters.txt.$Transfileid | tr ":" "\n" | grep -w "$Submitterid" | grep -w "$DestinationSystem" | cut -d "," -f2`			
			echo "Transset id for $Submitterid and $DestinationSystem is : $Transetid" >> $LOG
			SurviverIndicator=`cat $INTDIR/submitters.txt.$3 | tr ":" "\n" | grep -w "$Submitterid" |  cut -d "," -f3`
			echo "Surviver Indicator for $Submitterid is : $SurviverIndicator" >> $LOG
			Submitter_Split_File="SUB"_"$DestinationSystem"_"$Submitterid"_"$TransFileId"			
			
			cur_dir=`pwd`
			echo "Current DIR: $cur_dir" >> $LOG
			#splitting the INS into new lines
			Before_INS=`echo "$delim"INS`
			After_INS=`echo "$delim""\n"INS`
			echo "$Submitterid for $Before_INS and $After_INS in $INTDIR/$Submitter_Split_File" >> $LOG
			sed -i 's/'"$Before_INS"'/'"$After_INS"'/g' $INTDIR/$Submitter_Split_File
			INS=`wc -l $INTDIR/$Submitter_Split_File`
			echo "Seperating the files at INS level is done $INS" >> $LOG
			#splitting the SE into new lines
			Before_SE=`echo "$delim"SE`
			After_SE=`echo "$delim""\n"SE`
			echo "$Submitterid for $Before_SE and $After_SE in $INTDIR/$Submitter_Split_File" >> $LOG
			sed -i 's/'"$Before_SE"'/'"$After_SE"'/g' $INTDIR/$Submitter_Split_File
			#########################################
			#Audit Check
			#########################################
			grep "^SE" $INTDIR/$Submitter_Split_File > $INTDIR/"SUB"_SE_"$Submitterid"_"$TransFileId"
			SE_Count=`cut -d "$delimFS" -f2 $INTDIR/"SUB"_SE_"$Submitterid"_"$TransFileId" | awk '{ sum += $1 } END { print sum }'`			
			echo "Seperating the files at SE level is done" >> $LOG
			echo "SE_Count for $Submitterid: $SE_Count" >> $LOG
				delim_Count=`tr -d -C "$delim" < $INTDIR/$Submitter_Split_File | wc -c`
			echo "delim_Count for $Submitterid: $delim_Count" >> $LOG
			if [[ $SE_Count -eq $delim_Count ]]
				then
					echo "!!!!!!!!!!!!!!!!!!! Audit check count matches for $Submitterid !!!!!!!!!!!!!!!!!!!" >> $LOG
				else
					echo "!!!!!!!!!!!!!!!!!!! Audit check count is not matching for $Submitterid !!!!!!!!!!!!!!!!!!!" >> $LOG
				# #**defect# 4481*** adding extra check if the folders present then only start removing them
					if [ -f $INTDIR/*.* ]
					then
						rm -f $INTDIR/ST_$TransFileId $INTDIR/"SUB"_"$Submitterid"_"$TransFileId" $INTDIR/Submitterlist."$TransFileId" $INTDIR/"INS"_"line"_"$Submitter_Split_File" $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName" $INTDIR/$Submitter_Split_File $SUBIDDIR/$Submitter_Split_File $SUBIDDIR/split"$Submitterid".$3
						#rm -f $INTDIR/"INS"_"line"_"$Submitter_Split_File"
						rm -f $INTDIR/"*"."$TransFileId" 		
						echo "The removed files are $INTDIR/ST_$TransFileId $INTDIR/"SUB"_"$Submitterid"_"$TransFileId" $INTDIR/Submitterlist."$TransFileId" $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName" $SUBIDDIR/$Submitter_Split_File $SUBIDDIR/split"$Submitterid".$3" >> $LOG
						echo "The removed files are $INTDIR/"*"."$TransFileId" " >> $LOG
						echo "Hipaa End `date`" >> $LOG	
					else
						echo "Error: Intermediate Directory $INTDIR does not exists." >> $LOG
					fi				
				rm -f $INTDIR/file.txt.$3 $INTDIR/file1.txt.$3 $INTDIR/subBigDIRfiles.$3 $INTDIR/submitterids.txt.$3 $INTDIR/submitters.txt.$3 $INTDIR/test.$3 $INTDIR/transsetids.txt.$3 $INTDIR/subsplit$s.txt.$3 $SUBIDDIR/"$s".$3 $SUBIDDIR/split"$s".$3
				rm -rf $BaseFile $INBDIR/$INPUTFILE.$3 $INBDIR/$FName $INBDIR/$FName.$3 $INBDIR/payeessn.$3 $INBDIR/employeeid.$3 $INBDIR/eeid.$3 $INTDIR/subid.$3 $INTDIR/lrgfldir.$3 $INTDIR/splitSubmitters.$3
				exit 9
			fi
			#Delete ST and SE lines 
			grep -v "^S[E|T]" $INTDIR/$Submitter_Split_File > $INTDIR/"INS"_$Submitter_Split_File
			mv $INTDIR/"INS"_$Submitter_Split_File $INTDIR/$Submitter_Split_File
			echo "deleting ST and SE from $INTDIR/$Submitter_Split_File" >> $LOG
			
			#########################################
			#EEID Generation for COMBO HIPAA
			#########################################
			if [[ "$DestinationSystem" = "CDB" ]] #condition to check HIPAA CDB members
			then
			echo "!!!!!!!!!!!!!!!!!!! EEID Generation for CDB members of $Submitterid !!!!!!!!!!!!!!!!!!!" >> $LOG
				if [[ "$SurviverIndicator" = "Y" ]]
				then
				echo "******Start of Survivor Indicator Scenario `date` *********Surviver Indicator is Y ******" >> $LOG
				INS_line_count=1
					while read INS_line
					do
						#echo "Survivor Indicator Scenario - Started :::: iteration of $INS_line_count at `date` " >> $LOG
						print "$INS_line" > $INTDIR/"INS"_"line"_"$Submitter_Split_File"
						
						#n=`tr -d -C "$delim" < $INTDIR/"INS"_"line"_"$Submitter_Split_File" | wc -c`
						 # i=1
						 # refCount=1
						 # foundREF60="FALSE"
						 # INS05=`echo $INS_line | cut -d "$delimFS" -f6`				
						 # for i in `seq 1 $n`
						 # do
							 # foundREF60="FALSE"
							 # isREF=`echo $INS_line | cut -d "$delim" -f$i`
							 # if [[ $isREF == REF* ]]
							 # then
								 # if [[ $refCount -eq 1 ]]
								 # then 
									 # REF1stValue1=`echo $isREF | cut -d "$delimFS" -f2`
									 # REF1stValue2=`echo $isREF | cut -d "$delimFS" -f3`
								 # fi
								 # if [[ $INS05 = 'A' || $INS05 = 'S' ]]
								 # then
									 # REFValue1=`echo $isREF | cut -d "$delimFS" -f2`
									 # REFValue2=`echo $isREF | cut -d "$delimFS" -f3`
									 # if [[ $REFValue1 = "6O" ]]
									 # then
										 # echo "Survivor Indicator Y $REFValue2 for $INS_line_count" >> $LOG 
										 # echo  "$REFValue2" >> $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName"
										 # foundREF60="TRUE"
										 # break
									 # else
										 # echo "Survivor Indicator Y $REFValue1 is not 6O for $INS_line_count for REF segment $refCount " >> $LOG
									 # fi
								 # fi
								 # refCount=`expr $refCount + 1`
								 # if [[ $refCount -gt 15 ]]
								 # then
									 # break
								 # fi
							 # fi
								 # i=`expr $i + 1`
						 # done
						 # if [[ $foundREF60 = "TRUE" ]]
						 # then
							 # echo "TRUE"   
						 # else
							 # if [[ $REF1stValue1 = "0F" ]]
							 # then
								 # echo "Survivor Indicator Y , Yet did not find REF of 6O value.Using the Ref 1st instance value instead : $REF1stValue2 for $INS_line_count" >> $LOG 
								 # echo  "$REF1stValue2" >> $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName"
							 # else
								 # echo "Did not find REF 60 nor 0F for $INS_line_count" >> $LOG 
							 # fi
						 # fi
						#START ***** GPS M&R : Delays in processing for HIPAA split script has been addressed and fixed.
						#echo "START of CORE LOGIC for PRB0193410 ticket fix at =======`date` ================" >> $LOG
						awk -v delim="$delim" -v delimFS="$delimFS" 'BEGIN { RS=delim; FS=delimFS; foundINS05="FALSE"; refCount=1; } {
						for (i=1; i<=NR; i++) {
							if ($1 == "INS" ) {
								INS05=$6
								if(INS05 == "A" || INS05 == "S") {
									foundINS05="TRUE";
								}
							}
							else if ($1 == "REF") {
									if ($2 == "0F") {
										print $3;
									}
									if (foundINS05 == "TRUE" && $2 == "6O") {
											print $3;
											break;
									}
									refCount++;
							} else if ($1 == "NM1") {
								break;
							}
							else {}
							if (refCount > 15) {
								break;
							}
						}
						} END { print $3; }' $INTDIR/"INS"_"line"_"$Submitter_Split_File" >> $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName"
						#echo "==================END of Survivor Indicator scenarion: `date` =========================" >> $LOG
						#echo "END of PRB0193410 PM ticket code fix at `date` " >> $LOG
						#echo "Survivor Indicator Scenario - END of iteration $INS_line_count at `date`" >> $LOG
						#END ***** GPS M&R : Delays in processing for HIPAA split script has been addressed and fixed.
												 
						INS_line_count=`expr $INS_line_count + 1`
					done < $INTDIR/$Submitter_Split_File
					cat $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName" | sed '/^$/d' | sort | uniq >> $EEIDDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName"
					echo "******End of Survivor Indicator Scenario `date` **************** " >> $LOG
					#***defect 4481*** adding extra check if the folders present then only start removing them 
					if [ -f $INTDIR/"INS"_"line"_"$Submitter_Split_File" ]
					then
						rm -f $INTDIR/"INS"_"line"_"$Submitter_Split_File"
						echo " Removed the file $INTDIR/"INS"_"line"_"$Submitter_Split_File" " >> $LOG
					else
						echo "Error: File $INTDIR/"INS"_"line"_"$Submitter_Split_File" does not exist. " >> $LOG
					fi
				else 
					echo "Suriviver Indicator is N " >> $LOG
					cut -d "$delim" -f2 $INTDIR/$Submitter_Split_File | cut -d "$delimFS" -f3 | sort | uniq >> $EEIDDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName" 
				fi #end of survivorInd check 
			fi #end of EEID Generation for CDB members
			
			if [[ "$DestinationSystem" = "GPS" ]] #condition to check HIPAA GPS members
			then
				echo "!!!!!!!!! EEID Generation for GPS members of $Submitterid has Started `date` !!!!!!!" >> $LOG
				echo "Not generating EEIDs in this script for GPS alone as it is extracted by cascading inbound transformation and source flows directly" >> $LOG
				#INS_line_count=1
				#commaDelim=","
				#REF_F6_seg=`echo REF"$delimFS"F6`
				#echo "RefF6 : $REF_F6_seg"  >> $LOG
				#REF_ZZ_seg=`echo REF"$delimFS"ZZ` 
				#echo " Start EEID generation Loop at `date`" >> $LOG
				#TEMPFILEINVAR=`cat $INTDIR/$Submitter_Split_File`
				#for INS_line in $TEMPFILEINVAR
				
				#while read INS_line
				#do
					#echo "Survivor Indicator Scenario - Started :::: iteration of $INS_line_count at `date` " >> $LOG
					#print "$INS_line" > $INTDIR/"INS"_"line"_"$Submitter_Split_File"
						#print "$INS_line" > $INTDIR/"INS"_"line"_"$Submitter_Split_File"(#Bad for performance #1)
						#n=`tr -d -C "$delim" < $INTDIR/"INS"_"line"_"$Submitter_Split_File" | wc -c`(#Bad for performance #1)
						#n=`echo $INS_line | tr -d -C "$delim" | wc -c`(#Bad for performance #2)
						#better than above two..commenting the below to save some time on capturing the n, which is not necessarily needed and hardcoding the n to 20 based on hipaa I.G.
						#n=`echo $INS_line | awk -F"$delim" '{print NF}'`
						##i=1
						##refCount=1
						##foundREF_ZZ="FALSE"
						##foundREF_F6="FALSE"
						#removing dependency on n and using 20 as we anyway exit out of the loop limited no of REFs - 15(per Hipaa implementation)  #Performance improvement 
						#for i in `seq 1 $n`
						
						#echo "INLine Count: $INS_line_count" >> $LOG
						#echo " INS line : $INS_line" >> $LOG
						
						##for i in `seq 1 20`
						##do	
						
						  #echo "segment Count i: $i" >> $LOG					
							#isREF=`echo $INS_line | cut -d "$delim" -f$i`
							##isREF=`echo "$INS_line" | cut -d "$delim" -f"$i"` #added fix for defect# 5492
							#echo "isREF: $isREF" >> $LOG
							##if [[ "$isREF" == REF* ]]
							##then
								#echo "handling REF at $i" >> $LOG
								#echo "isREF: $isREF" >> $LOG
								##if [[ $refCount -eq 2 ]] #Check for REF seg having Group/Policy number
								##then
									#REF2ndValue1=`echo "$isREF" | cut -d "$delimFS" -f2`
									##REF2ndValue2=`echo "$isREF" | cut -d "$delimFS" -f3` #added fix for defect# 5492
									#echo "REF2ndValue2: $REF2ndValue2" >> $LOG
									##groupID=`echo "$REF2ndValue2" | cut -c1-8 | tr -d " "` #added fix for defect# 5492
									#echo "groupID: $groupID" >> $LOG
									##branchNum=`echo "$REF2ndValue2" | cut -c9-11 | tr -d " "` #added fix for defect# 5492
									#echo "branchNum: $branchNum" >> $LOG
								##fi							
								
								##if [[ "$isREF" == $REF_F6_seg* ]] 
								##then
									##echo "Found REF F6 segment for $INS_line_count" >> $LOG
									#Not Used..REF_F6_Value=`echo $isREF | cut -d "$delimFS" -f2`
									##HICNbr=`echo $isREF | cut -d "$delimFS" -f3` #HIC number									
									#echo "HIC Number $HICNbr for $INS_line_count" >> $LOG
									##echo "Adding record into EEID file for INS line of $INS_line_count" >> $LOG
									##printf '%s\n' "$HICNbr$commaDelim$groupID$commaDelim$branchNum" >> $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName"
									##break
								##fi
																
								##refCount=`expr $refCount + 1`
								
								##if [[ $refCount -gt 15 ]]
								##then
									##break
								##fi
							##fi
							##i=`expr $i + 1`
						##done
						#START ***** GPS M&R : Delays in processing for HIPAA split script has been addressed and fixed.						
						#echo "======================Start of Core logic `date` ======================" >> $LOG
						
						#
						#START *** commenting out the EEID generation section of GPS as an alternative solution has been identified as part of F21
						#awk -v delim="$delim" -v delimFS="$delimFS" 'BEGIN {RS=delim; FS=delimFS; seg=0; foundREF_1L="FALSE"; foundREF_F6="FALSE"; refCount=1;} {
						#	for (i=1; i<=NR; i++) {
						#		if ($1 == "INS") {
						#			seg++;
						#		}								
						#		else if ($1 == "REF") {
						#			if ($2 == "1L") {
						#				groupID=substr($3,1,8);
						#				branchNbr=substr($3,9,3);
						#				foundREF_1L="TRUE";										
						#			}
						#			if ($2 == "F6") {
						#				HICNbr=$3;
						#				foundREF_F6="TRUE";										
						#			}
						#			if (foundREF_1L == "TRUE" && foundREF_F6 == "TRUE") {
						#				print HICNbr "," groupID "," branchNbr;
						#				break;
						#			}
						#			refCount++;
						#		} else if ($1 == "DTP" || $1 == "NM1") {
						#			break;
						#		}
						#		else {}
						#		if (refCount > 15) {
						#			break;
						#		}								
						#	}
						#}' $INTDIR/"INS"_"line"_"$Submitter_Split_File" >> $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName"
						#END ***  commenting out the EEID generation section of GPS as an alternative solution has been identified as part of F21
						
						
						#echo "==================END of Survivor Indicator scenarion: `date` =========================" >> $LOG
						#echo "Survivor Indicator Scenario - END of iteration $INS_line_count at `date` " >> $LOG
						#END ***** GPS M&R : Delays in processing for HIPAA split script has been addressed and fixed.
							
					#INS_line_count=`expr $INS_line_count + 1`
				#done
				#done < $INTDIR/$Submitter_Split_File
				echo "!!!!!!!!! EEID Generation for GPS members of $Submitterid has ENDED `date` !!!!!!!" >> $LOG
				#TEMPFILEINVAR=''
				
				
				#** START commenting out the EEID generation section of GPS as an alternative solution has been identified as part of F21
				#echo "Moving EEID file to $EEIDDIR directory" >> $LOG
				#cat $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName" | sed '/^$/d' | sort | uniq >> $EEIDDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName"
				#** END commenting out the EEID generation section of GPS as an alternative solution has been identified as part of F21
			
			fi #End of EEID Generation for GPS member
			
			############################################
			#Splitting the files for HIPAA
			#########################################***		
			echo "!!!!!!!!!!!!!!!!!!! Splitting the files based on the Threshold Value for $Submitterid !!!!!!!!!!!!!!!!!!!" >> $LOG
			INS_Count=`cat $INTDIR/$Submitter_Split_File | wc -l`
			echo " The INS_Count for $Submitterid : $INS_Count " >> $LOG
			echo "threshold: $threshold" >> $LOG
			if [[ $INS_Count -gt $threshold ]]
			then
				echo "The $INTDIR/$Submitter_Split_File should be further splitted into parts" >> $LOG
				cp $INTDIR/$Submitter_Split_File $SUBIDDIR/
				cd $SUBIDDIR
				mkdir split"$Submitterid".$3
				split -l $threshold $INTDIR/$Submitter_Split_File split"$Submitterid".$3/ 
				filerc=$?
				if [[ $filerc -eq 0 ]] 
				then
					echo "split is done for HIPAA File `date`" >> $LOG
				else
					echo "Error in splitting HIPAA file" >> $LOG
				exit 2
				fi
				cd split"$Submitterid".$3
				ls -l | awk '{print $9}' | awk 'NF > 0' >> $INTDIR/subsplit$Submitterid.txt.$3
				Total_Split_Files=`cat $INTDIR/subsplit$Submitterid.txt.$3 | wc -l` # count of the number of split files
				echo "Splitted no. of files for submitter $Submitterid is : $Total_Split_Files" >> $LOG
				i=1
				Member_Sequence=1 # member sequence start of the split file
				Split_prefix="$TransFileId"_"$Transetid"_"$Submitterid"_"$Hipaa_Version"
				Split_postfix="$FName"
				for file in *
				do
					Split_Counter_Info="$i"_"$Total_Split_Files"_"$Member_Sequence"
					Split_File="$Split_prefix"_"$Split_Counter_Info"_"$Split_postfix"
					echo " The $i file is $file" >> $LOG
					#mv $file test.$3
					mv $file $Split_File
					echo "moving $file to $Split_File" >> $LOG
					#START - Commented out below vim command to fix the prod issue with large HIPAA files for which 
					#record count exceeds the #threshold value
					
					#Encoding of file check for large files
					#encoding=`file --mime-encoding  test.$3`
					#echo "Encoding of $Split_File: $encoding" >> $LOG
					#vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name  test.$3)
					
					#END
					#mv test.$3 $Split_File
					if [[ $DestinationSystem = "GPS" ]]
					then
						mv $Split_File "$Split_File"gps.temp
						mv "$Split_File"gps.temp $LRGSUBIDDIR/	
					elif [[ $DestinationSystem = "CDB" ]]
					then
						mv $Split_File "$Split_File".temp
						mv "$Split_File".temp $LRGSUBIDDIR/
					else
						echo "Invalid DestinationSystem" >> $LOG
					fi
					#newencoding=`file --mime-encoding  $Split_File`
					#echo "After encoding change of HIPAA: $newencoding" >> $LOG
					#rm -rf test.$3
								
					Member_Seq_Start=`expr $i \* $threshold`
					Member_Sequence=`expr $Member_Seq_Start + 1`
					i=`expr $i + 1`
					echo "`date`" >> $LOG
				done
				#***defect 4481*** adding extra check if the folders present then only start removing them			
				if [ -f $INTDIR/$Submitter_Split_File ]
				then
					rm -f $INTDIR/$Submitter_Split_File
					echo "Removed the file $INTDIR/$Submitter_Split_File" >> $LOG
				else
					echo "Error: Directory $INTDIR/$Submitter_Split_File does not exist. " >> $LOG
				fi
				echo " --------------------------------------------------------------------" >> $LOG
			else
				echo " NO splitting is required for $INTDIR/$Submitter_Split_File " >> $LOG
				cp $INTDIR/$Submitter_Split_File $SUBIDDIR/
				cd $SUBIDDIR
				i=1
				Member_Sequence=1
				Total_Split_Files=1
				Split_prefix="$TransFileId"_"$Transetid"_"$Submitterid"_"$Hipaa_Version"
				Split_postfix="$FName"
				Split_Counter_Info="$i"_"$Total_Split_Files"_"$Member_Sequence"
				if [[ $DestinationSystem = "GPS" ]]
				then
					Split_File="$Split_prefix"_"$Split_Counter_Info"_"$Split_postfix"gps.temp
				elif [[ $DestinationSystem = "CDB" ]]	
				then
					Split_File="$Split_prefix"_"$Split_Counter_Info"_"$Split_postfix".temp
				else
					echo "Invalid DestinationSystem" >> $LOG
				fi
				echo "Splitted no. of files for submitter $Submitterid is : $Total_Split_Files" >> $LOG
				mv $Submitter_Split_File $Split_File
				#***defect 4481*** adding extra check if the folders present then only start removing them			
				if [ -f $INTDIR/$Submitter_Split_File ]
				then
					rm -f $INTDIR/$Submitter_Split_File
					echo "Removed the file $INTDIR/$Submitter_Split_File" >> $LOG
				else
					echo "Error: File $INTDIR/$Submitter_Split_File does not exist. " >> $LOG
				fi
				echo " --------------------------------------------------------------------" >> $LOG			
			fi #end of threshold check
			
		#fi #end of IF condition check
		#done < $INTDIR/Submitterlist."$TransFileId"
		done < $ST_Submitter_list
		echo "End of function call :: generateEEIdPlusSplitFiles() " >> $LOG
		echo "*****************************************************************************" >> $LOG
	} #End of function generateEEIdPlusSplitFiles()
	
	#Pure GPS scenario for HIPAA file having GPS (.hipaagps) only members
	if [[ "$eligSysCd" = "G" ]]
	then
		Destination="GPS"
		echo "Destination System is: $Destination" >> $LOG
		ls $INTDIR/SUB_GPS_*_"$TransFileId" > $INTDIR/Submitterlist.GPS."$TransFileId"
		#function generateEEIdPlusSplitFiles() call :: passing three params
		generateEEIdPlusSplitFiles $INTDIR/Submitterlist.GPS."$TransFileId" $Destination $TransFileId
	#COMBO scenario for HIPAA file having both GPS (.hipaagps) and CDB (.hipaa) members
	elif [[ "$eligSysCd" = "C" ]]
	then
		ls $INTDIR/SUB_GPS_*_"$TransFileId" > $INTDIR/Submitterlist.GPS."$TransFileId"
		ls $INTDIR/SUB_CDB_*_"$TransFileId" > $INTDIR/Submitterlist.CDB."$TransFileId"
		ls $INTDIR/Submitterlist.*."$TransFileId" > $INTDIR/Submitterlist."$TransFileId"
	
		while read Submitterlist_line
		do
			Destination=`echo $Submitterlist_line | cut -d "/" -f7 | cut -d "." -f2`
			echo "Destination System is: $Destination" >> $LOG
			if [[ $Destination = "GPS" ]]
			then
				#function generateEEIdPlusSplitFiles() call :: passing three params
				generateEEIdPlusSplitFiles $Submitterlist_line $Destination $TransFileId				
			fi
			if [[ $Destination = "CDB" ]]
			then
				#function generateEEIdPlusSplitFiles() call :: passing three params 
				generateEEIdPlusSplitFiles $Submitterlist_line $Destination $TransFileId				
			fi
		done < $INTDIR/Submitterlist."$TransFileId"
	else
		echo "eligSysCd is not valid; please enter a valid value" >> $LOG
	fi
	
	#START of Code changes added to fix prod issue (HIPAA format: Seebeyond Wave 2.1) in prod
	#Start of encoding logic for large files where number of records count in file exceeds threshold value
	
	if [ -f $LRGSUBIDDIR/*.hipaagps.temp ]
	then
		echo "File exists and moving to larger directory" >> $LOG
		#Encoding file check for larger files of HIPAA 
		echo "Encoding part for larger files" >> $LOG
		
		cd $LRGSUBIDDIR
		i=1
		for file in *
		do
			echo "`date`" >> $LOG
			echo "$i is $file" >> $LOG
			encoding=`file --mime-encoding $file`
			#echo "before encoding of $i: $encoding" >> $LOG
			vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name $file)
			newencoding=`file --mime-encoding $file`
			#echo "After encoding of $i: $newencoding" >> $LOG
	        i=`expr $i + 1`
		done
		
		if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ] || [ "`grep "_"$TransFileId"_"$TransSetId"_" $INFLGT_PRRTY_FILE | wc -l`" -gt 0 ]; then # If it is priority input/inflight priority file move to priority destination directory		
			echo "priority moving to inbound psmall directory" >> $LOG
			mv $LRGSUBIDDIR/*.hipaagps.temp $PSUBSMALLDIR/
			echo "$LRGSUBIDDIR/*.hipaagps.temp moved to $PSUBSMALLDIR/" >> $LOG
			ls -lrt $PSUBSMALLDIR/*.hipaagps.temp | awk '{print $9}' >> $LOG
			du -ch $PSUBSMALLDIR/ | grep total >> $LOG
			InboundDir=$PSUBSMALLDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
			
		elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
			echo "FFM moving to inbound FFM directory" >> $LOG
			mv $LRGSUBIDDIR/*.hipaagps.temp $FFMDIR/
			echo "$LRGSUBIDDIR/*.hipaagps.temp moved to $FFMDIR/" >> $LOG
			ls -lrt $FFMDIR/*.hipaagps.temp | awk '{print $9}' >> $LOG
			du -ch $FFMDIR/ | grep total >> $LOG
			InboundDir=$FFMDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		
		elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
			echo "Normal files to normal directory" >> $LOG
			mv $LRGSUBIDDIR/*.hipaagps.temp $SUBBIGDIR/
			echo "$LRGSUBIDDIR/*.hipaagps.temp moved to $SUBBIGDIR/" >> $LOG
			ls -lrt $SUBBIGDIR/*.hipaagps.temp | awk '{print $9}' >> $LOG
			du -ch $SUBBIGDIR/ | grep total >> $LOG
			InboundDir=$SUBBIGDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		else
			echo "please pass the priority flag as Y or N" >> $LOG
			
		fi		
		#***defect 4481*** adding extra check if the folders present then only start removing them
		if [ -f $INTDIR/$Submitter_Split_File ]
		then
			rm -f $INTDIR/$Submitter_Split_File
			echo "Removed the file $INTDIR/$Submitter_Split_File" >> $LOG
		else
			echo "Error: File $INTDIR/$Submitter_Split_File does not exist. " >> $LOG
		fi		
		echo "rename from .temp to actual file-name for large/plarge/largeffm started at `date`" >> $LOG
		echo "InboundDir is $InboundDir" >> $LOG
		cd $InboundDir
		ls -ltr $InboundDir/*.hipaagps.temp | awk '{print $9}' > renameTemp
		i=1
		# extension = "gps"
		while read line
		 do  
			 echo "$i is $line" >> $LOG 
			 mv "$line" "${line%%.temp}"
			 i=`expr $i + 1`
		done < renameTemp
		echo "rename from .temp to .hipaagps has ended at `date`" >> $LOG
		
	fi
	#End of encoding logic for large files where number of records count in file exceeds threshold value  
	#End of Prod Issue (HIPAA format: Seebeyond Wave 2.1) code fix
	
	#COMBO scenario for CDB members - files with .hipaa extention
	if [ -f $LRGSUBIDDIR/*.hipaa.temp ]
	then
		echo "File exists and moving to larger directory" >> $LOG
		#Encoding file check for larger files of HIPAA 
		echo "Encoding part for larger files" >> $LOG
		
		cd $LRGSUBIDDIR
		i=1
		for file in *
		do
			echo "`date`" >> $LOG
			echo "$i is $file" >> $LOG
			encoding=`file --mime-encoding $file`
			#echo "before encoding of $i: $encoding" >> $LOG
			vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name $file)
			newencoding=`file --mime-encoding $file`
			#echo "After encoding of $i: $newencoding" >> $LOG
	        i=`expr $i + 1`
		done
		
		if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ] || [ "`grep "_"$TransFileId"_"$TransSetId"_" $INFLGT_PRRTY_FILE | wc -l`" -gt 0 ]; then # If it is priority input/inflight priority file move to priority destination directory		
			echo "priority moving to inbound psmall directory" >> $LOG
			mv $LRGSUBIDDIR/*.hipaa.temp $PSUBSMALLDIR/
			echo "$LRGSUBIDDIR/*.hipaagps.temp moved to $PSUBSMALLDIR/" >> $LOG
			ls -lrt $PSUBSMALLDIR/*.hipaa.temp | awk '{print $9}' >> $LOG
			du -ch $PSUBSMALLDIR/ | grep total >> $LOG
			InboundDir=$PSUBSMALLDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
			
		elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
			echo "FFM moving to inbound FFM directory" >> $LOG
			mv $LRGSUBIDDIR/*.hipaa.temp $FFMDIR/
			echo "$LRGSUBIDDIR/*.hipaagps.temp moved to $FFMDIR/" >> $LOG
			ls -lrt $FFMDIR/*.hipaa.temp | awk '{print $9}' >> $LOG
			du -ch $FFMDIR/ | grep total >> $LOG
			InboundDir=$FFMDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		
		elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
			echo "Normal files to normal directory" >> $LOG
			mv $LRGSUBIDDIR/*.hipaa.temp $SUBBIGDIR/
			echo "$LRGSUBIDDIR/*.hipaagps.temp moved to $SUBBIGDIR/" >> $LOG
			ls -lrt $SUBBIGDIR/*.hipaa.temp | awk '{print $9}' >> $LOG
			du -ch $SUBBIGDIR/ | grep total >> $LOG
			InboundDir=$SUBBIGDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		else
			echo "please pass the priority flag as Y or N" >> $LOG
			
		fi
		
		#***defect 4481*** adding extra check if the folders present then only start removing them
		if [ -f $INTDIR/$Submitter_Split_File ]
		then
			rm -f $INTDIR/$Submitter_Split_File
			echo "Removed the file $INTDIR/$Submitter_Split_File" >> $LOG
		else
			echo "Error: File $INTDIR/$Submitter_Split_File does not exist. " >> $LOG
		fi
		
		echo "rename from .temp to actual file-name for large/plarge/largeffm started at `date`" >> $LOG
		echo "InboundDir is $InboundDir" >> $LOG
		cd $InboundDir
		ls -ltr $InboundDir/*.hipaa.temp | awk '{print $9}' > renameTemp
		i=1
		# extension = "gps"
		while read line
		 do  
			 echo "$i is $line" >> $LOG 
			 mv "$line" "${line%%.temp}"
			 i=`expr $i + 1`
		done < renameTemp
		echo "rename from .temp to .hipaagps has ended at `date`" >> $LOG
		
	fi #End of COMBO HIPAA scenario for CDB members
	
	#For Small files
	if [ -f $SUBIDDIR/*.hipaagps.temp ]
	then
		echo "File exists and moving to smaller directory" >> $LOG
		#Encoding file check for smaller files of HIPAA 
		echo "Start of Encoding part for smaller files" >> $LOG
		cd $SUBIDDIR
		i=1
		for file in *.hipaagps.temp
		do
			echo "`date`" >> $LOG
			echo "$i is $file" >> $LOG
			encoding=`file --mime-encoding $file`
			#echo "before encoding of $i: $encoding" >> $LOG
			vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name $file)
			newencoding=`file --mime-encoding $file`
			#echo "After encoding of $i: $newencoding" >> $LOG
	        i=`expr $i + 1`
		done
		
		echo "End of Encoding part for smaller files" >> $LOG
		
		if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ] || [ "`grep "_"$TransFileId"_"$TransSetId"_" $INFLGT_PRRTY_FILE | wc -l`" -gt 0 ]; then # If it is priority input/inflight priority file move to priority destination directory		
			echo "priority moving to inbound psmall directory" >> $LOG
			mv $SUBIDDIR/*.hipaagps.temp $PSUBSMALLDIR/
			echo "$SUBIDDIR/ moved to $PSUBSMALLDIR/" >> $LOG
			ls -lrt $PSUBSMALLDIR/*.hipaagps.temp | awk '{print $9}' >> $LOG
			du -ch $PSUBSMALLDIR/ | grep total >> $LOG
			InboundDir=$PSUBSMALLDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
			echo "FFM moving to inbound FFM directory" >> $LOG
			mv $SUBIDDIR/*.hipaagps.temp $FFMDIR/
			echo "$SUBIDDIR/ moved to $FFMDIR/" >> $LOG
			ls -lrt $FFMDIR/*.hipaagps.temp | awk '{print $9}' >> $LOG
			du -ch $FFMDIR/ | grep total >> $LOG
			InboundDir=$FFMDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
			echo "Normal files to normal directory" >> $LOG
			mv $SUBIDDIR/*.hipaagps.temp $SUBSMALLDIR/
			echo "$SUBIDDIR/ moved to $SUBSMALLDIR/" >> $LOG
			ls -lrt $SUBSMALLDIR/*.hipaagps.temp | awk '{print $9}' >> $LOG
			du -ch $SUBSMALLDIR/ | grep total >> $LOG
			InboundDir=$SUBSMALLDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		else
			echo "please pass the priority flag as Y or N" >> $LOG
			$InboundDir="NONE"
		fi
		
		echo "rename from .temp to actual file-name started at `date`" >> $LOG
		echo "Inbound directory path is $InboundDir" >> $LOG
		
		cd $InboundDir
		ls -ltr $InboundDir/*.hipaagps.temp | awk '{print $9}' > renameTemp
		i=1
		# extension = "gps"
		while read line
		 do  
			  echo "$i is $line" >> $LOG 
			  mv "$line" "${line%%.temp}"
			  i=`expr $i + 1`
	      done < renameTemp
		echo "rename from .temp to .hipaa end at `date`" >> $LOG
		
	else
		echo "Files are already moved to larger directory" >> $LOG
	fi #End --For Small files
	
	#COMBO scenario for CDB members - Small files
	if [ -f $SUBIDDIR/*.hipaa.temp ]
	then
		echo "File exists and moving to smaller directory" >> $LOG
		#Encoding file check for smaller files of HIPAA 
		echo "Start of Encoding part for smaller files" >> $LOG
		cd $SUBIDDIR
		i=1
		for file in *.hipaa.temp
		do
			echo "`date`" >> $LOG
			echo "$i is $file" >> $LOG
			encoding=`file --mime-encoding $file`
			#echo "before encoding of $i: $encoding" >> $LOG
			vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name $file)
			newencoding=`file --mime-encoding $file`
			#echo "After encoding of $i: $newencoding" >> $LOG
	        i=`expr $i + 1`
		done
		
		echo "End of Encoding part for smaller files" >> $LOG
		
		if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ] || [ "`grep "_"$TransFileId"_"$TransSetId"_" $INFLGT_PRRTY_FILE | wc -l`" -gt 0 ]; then # If it is priority input/inflight priority file move to priority destination directory		
			echo "priority moving to inbound psmall directory" >> $LOG
			mv $SUBIDDIR/*.hipaa.temp $PSUBSMALLDIR/
			echo "$SUBIDDIR/ moved to $PSUBSMALLDIR/" >> $LOG
			ls -lrt $PSUBSMALLDIR/*.hipaa.temp | awk '{print $9}' >> $LOG
			du -ch $PSUBSMALLDIR/ | grep total >> $LOG
			InboundDir=$PSUBSMALLDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
			echo "FFM moving to inbound FFM directory" >> $LOG
			mv $SUBIDDIR/*.hipaa.temp $FFMDIR/
			echo "$SUBIDDIR/ moved to $FFMDIR/" >> $LOG
			ls -lrt $FFMDIR/*.hipaa.temp | awk '{print $9}' >> $LOG
			du -ch $FFMDIR/ | grep total >> $LOG
			InboundDir=$FFMDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
			echo "Normal files to normal directory" >> $LOG
			mv $SUBIDDIR/*.hipaa.temp $SUBSMALLDIR/
			echo "$SUBIDDIR/ moved to $SUBSMALLDIR/" >> $LOG
			ls -lrt $SUBSMALLDIR/*.hipaa.temp | awk '{print $9}' >> $LOG
			du -ch $SUBSMALLDIR/ | grep total >> $LOG
			InboundDir=$SUBSMALLDIR  # Adding this line to change the .temp file to .hipaa files at the end
			echo "`date`" >> $LOG
		else
			echo "please pass the priority flag as Y or N" >> $LOG
			$InboundDir="NONE"
		fi
		
		echo "rename from .temp to actual file-name started at `date`" >> $LOG
		echo "Inbound directory path is $InboundDir" >> $LOG
		
		cd $InboundDir
		ls -ltr $InboundDir/*.hipaa.temp | awk '{print $9}' > renameTemp
		i=1
		# extension = "gps"
		while read line
		 do  
			  echo "$i is $line" >> $LOG 
			  mv "$line" "${line%%.temp}"
			  i=`expr $i + 1`
	      done < renameTemp
		echo "rename from .temp to .hipaa end at `date`" >> $LOG		
	else
		echo "Files are already moved to larger directory" >> $LOG
	fi #End -- COMBO scenario for CDB members - Small files
	
	#***defect 4481*** adding extra check if the folders present then only start removing them
	if [ -f $INTDIR/*.* ]
	then
		rm -f $INTDIR/ST_$TransFileId $INTDIR/"SUB"_"$Submitterid"_"$TransFileId" $INTDIR/Submitterlist."$TransFileId" $INTDIR/"INS"_"line"_"$Submitter_Split_File" $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName" $INTDIR/$Submitter_Split_File $SUBIDDIR/$Submitter_Split_File $SUBIDDIR/split"$Submitterid".$3
		#rm -f $INTDIR/"INS"_"line"_"$Submitter_Split_File"
		rm -f $INTDIR/"*"."$TransFileId" 		
		echo "The removed files are $INTDIR/ST_$TransFileId $INTDIR/"SUB"_"$Submitterid"_"$TransFileId" $INTDIR/Submitterlist."$TransFileId" $INTDIR/"EEID"_"$TransFileId"_"$Transetid"_"$Submitterid"_"$FName" $SUBIDDIR/$Submitter_Split_File $SUBIDDIR/split"$Submitterid".$3" >> $LOG
		echo "The removed files are $INTDIR/"*"."$TransFileId" " >> $LOG
		echo "Hipaa End `date`" >> $LOG	
	fi
else
	echo "Encountered a File other than HIPAA" >> $LOG
fi
rm -f $INTDIR/file.txt.$3 $INTDIR/file1.txt.$3 $INTDIR/subBigDIRfiles.$3 $INTDIR/submitterids.txt.$3 $INTDIR/submitters.txt.$3 $INTDIR/test.$3 $INTDIR/transsetids.txt.$3 $INTDIR/transSubDestIds.txt.$3 $INTDIR/subsplit$s.txt.$3 $SUBIDDIR/"$s".$3 $SUBIDDIR/split"$s".$3
rm -rf $BaseFile $INBDIR/$INPUTFILE.$3 $INBDIR/$FName $INBDIR/$FName.$3 $INBDIR/payeessn.$3 $INBDIR/employeeid.$3 $INBDIR/eeid.$3 $INTDIR/subid.$3 $INTDIR/lrgfldir.$3 $INTDIR/splitSubmitters.$3
echo " The removed files are $INTDIR/file.txt.$3 $INTDIR/file1.txt.$3 $INTDIR/subBigDIRfiles.$3 $INTDIR/submitterids.txt.$3 $INTDIR/submitters.txt.$3 $INTDIR/test.$3 $INTDIR/transsetids.txt.$3 $INTDIR/transSubDestIds.txt.$3 $INTDIR/subsplit$s.txt.$3 $SUBIDDIR/"$s".$3 $SUBIDDIR/split"$s".$3 $BaseFile $INBDIR/$INPUTFILE.$3 $INBDIR/$FName $INBDIR/$FName.$3 $INBDIR/payeessn.$3 $INBDIR/employeeid.$3 $INBDIR/eeid.$3 $INTDIR/subid.$3 $INTDIR/lrgfldir.$3 $INTDIR/splitSubmitters.$3" >> $LOG

echo "**************************************************************************" >> $LOG
echo "* initProc_SplitFile_HIPAAGPS.sh ended on `date`" >> $LOG
echo "**************************************************************************" >> $LOG
return 1

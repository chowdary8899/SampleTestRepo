#!/bin/ksh
###################################################################
# Module:		initProc_SubmtCnt_GPS.sh
# Script Path:	/iib/scripts/InitialProcessing/initProc_SubmtCnt_GPS.sh
# 
# Purpose:     	
#			1. 	Using inbound file it creates a file containing Submitter ID counts against each Submitter ID.
#			2. 	Script accepts the file in the format like <GPSTESTING>.U.<TIMESTAMP>.gps and 
#		   		rename it to a format like GPSTESTING>.U.<TIMESTAMP>.<transFileID>.gps
#			3. 	Next, it creates a new file with format as like <TransFileID>_GPSTESTING>.U.<TIMESTAMP>.gps; which contains 
#		   		list of <Submitter ID><subCntDelim><rec_count><subCntDelim><Destination_System> against each Submitter ID
# 
# Parameters: 	
#			$1 - InputFile Name	
#	       	$2 - TransfileID 			                 
#  
# How to execute: 
#			./initProc_SubmtCnt_GPS.sh $1 $2
# Example: 	  	
#			./initProc_SubmtCnt_GPS.sh </iib/scripts/InitialProcessing/SCRIPT/INPDIR/GPSTESTING.U.201610181001.gps> <1111>
# 
# ***************
# Maintenance:
# ***************
#
# Date        	Programmer          	Description
# =====		===========		===============
# 02/14/2017  	Cognizant Offshore	New script which creates a file containing the list of submitter IDs 
# 02/15/2017  	Cognizant Offshore	Modified script to create a new file containing list of Submitter ID, counts, against each Submitter ID
# 02/16/2017	Cognizant Offshore	Modified script to create a new file containing Submitter ID, record counts, DESTINATION SYSTEM with <subCntDelim> delimited
# 02/17/2017	Cognizant Offshore  Modified script to accept 2nd timestamp
############################################################################
GPS_LOG="/iib/scripts/logs/GPS_SubmtCnt.$2.log"
echo "**************************************************************************" >> $GPS_LOG
echo "* initProc_SubmtCnt.sh started on `date`" >> $GPS_LOG
echo "**************************************************************************" >> $GPS_LOG
# Get the parameters and make sure we have all of them
if [[ $# -ne 2 ]] then
  print "Usage: $0  <InputFile Name> <TransFileID> " >> $GPS_LOG
  exit 9
else
  BaseFile="$1"
  TransFileID="$2"
fi
echo "The inputs for this script are: Filename:$BaseFile TransFileID:$TransFileID" >> $GPS_LOG 
FileName=`basename $BaseFile`
SubmitterId=`echo $BaseFile | awk '{split($0,a,"."); print a[1]}'`
FileU=`echo $BaseFile| awk '{split($0,a,"."); print a[2]}'` 
FileDT=`echo $BaseFile| awk '{split($0,a,"."); print a[3]}'` 
IBTimeStamp=`echo $BaseFile | awk '{split($0,a,"."); print a[4]}'`
FileFormat=`echo $BaseFile| awk '{split($0,a,"."); print a[5]}'` 
RenameBaseFile=`echo $SubmitterId.$FileU.$FileDT.$2.$FileFormat`
Actual_Submitterid=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
SubmitCountFileName=`echo $Actual_Submitterid.$FileU.$FileDT.$FileFormat`

INB_DIR="/iib/scripts/InitialProcessing/SCRIPT/INPDIR"
TEMP_DIR="/iib/scripts/InitialProcessing/SCRIPT/TEMPDIR"
CNT_FILE="$TEMP_DIR/$TransFileID"_"$SubmitCountFileName"
OutFieldDelim="<subCntDelim>"

#Converting file extensions to Lowercase 
lowerCaseFileFormat=`echo $FileFormat | tr '[:upper:]' '[:lower:]'`

destSystem=`echo $lowerCaseFileFormat | tr '[:lower:]' '[:upper:]'`

#echo $SubmitCountFileName >> $GPS_LOG
if [[ $lowerCaseFileFormat == 'gps' ]]
then
	#recCnt=`wc -l < $BaseFile`
	recCnt=`cat $BaseFile | wc -l`
	echo "Input file record count - including header: $recCnt" >> $GPS_LOG
	subCnt=`expr $recCnt - 1` #Record count of the input file excluding Header
	echo "Input file record count: $subCnt" >> $GPS_LOG
	
	# totLnCnt=`cat $BaseFile | wc -l` #Line count of input file
    # lnCnt=`expr $totLnCnt - 1`
	# echo "Input file line count: $lnCnt" >> $GPS_LOG
	
	# if [ $subCnt -eq $lnCnt ] || [ $recCnt -eq $totLnCnt ]
	# then
            # echo "Data is line by line in $BaseFile" >> $GPS_LOG
        # else
            # echo "Data is not in correct format" >> $GPS_LOG
	# fi
	
	echo "The input file type is of GPS format and its srecord count is: $subCnt" >> $GPS_LOG
	sed -i '1d;1q' $BaseFile #removes header record
	#sed -i '1d' $BaseFile #removes header record
	SubmitCnt=`cat $BaseFile | wc -l`
	echo "Submit Count:$SubmitCnt" >> $GPS_LOG
	cat $BaseFile | cut -c 6-25 | sort | uniq | awk 'NF > 0' > $INB_DIR/Submitters.$2	
	
InputDirPath=`dirname $BaseFile`
echo "The Input file is splitted into parts: SubmitterId:$SubmitterId FileU:$FileU FileDT:$FileDT IBTimeStamp: $IBTimeStamp FileFormat:$lowerCaseFileFormat" >> $GPS_LOG
echo "The Input File and the Renamed File are: $BaseFile $RenameBaseFile" >> $GPS_LOG
`mv $BaseFile $RenameBaseFile`

 while read line
 do
	 Submitter=`echo $line`
	 echo "The Submitter is :$Submitter" >> $GPS_LOG		
	 echo "`date`" >> $GPS_LOG			
	 echo "$Submitter$OutFieldDelim$subCnt$OutFieldDelim$destSystem" >> $INB_DIR/tempfile.$2
 done < $INB_DIR/Submitters.$2
 cat $INB_DIR/tempfile.$2 > $CNT_FILE

#cat $INB_DIR/Submitters.$2 > $SUBMTR_ID
#echo "$SUBMTR_ID$OutFieldDelim$subCnt$OutFieldDelim$upperCaseFileFormat" > $CNT_FILE
#rm -rf $INB_DIR/tempfile.$2 $INB_DIR/$fileIn $INB_DIR/IndividualSubmitters.$2 $INB_DIR/Submitters.$2 $TEMP_INB_CNT_FILE
rm -rf $INB_DIR/tempfile.$2
rm -f $INB_DIR/Submitters.$2 || { exit 10; }
else
	echo "INVALID input file!!!... please try again with an appropriate file or format" >> $GPS_LOG
fi
echo "**************************************************************************" >> $GPS_LOG
echo "* initProc_SubmtCnt_GPS.ksh ended on `date`" >> $GPS_LOG
echo "**************************************************************************" >> $GPS_LOG
return 1

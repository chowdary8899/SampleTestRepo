#!/bin/ksh
###################################################################
# Module:      initProc_Split_GPS.sh
# Purpose:     Using inbound file and priority Submitter ID, it will split the file into n number of files based on the threshold value
# Parameters : 
#              $1 - InputFile path	
#			   $2 - Priority Submitter ID seperated by colon(:)
#			   $3 - TransfileID
#			   $4 - Priority flag 			                 
# How to execute:      nohup ./initProc_Split.sh $1 $2 $3 $4
# Example:	       nohup ./initProc_Split_GPS.sh /iib/be128/initialprocess/input MASTESTA,2222,Y  6666 N
# Example 2: 	./initProc_SplitFile_GPS_v1.sh /eems/iib/be128/initialprocess/input/PFIZERC.U.201706130913.234126.gps PFIZERC,124003, 234126 N
#  	
# ****************************
# Maintenance:
# ****************************
# Date        	Programmer              Description
# ==========	===================		============================
# 04/20/2017  	Cognizant Offshore      Meka V Swamy:New script for GPS only members to split large file into small files according to the threshold value
# 05/30/2017  	Cognizant Offshore      Meka V Swamy:Modified script to fix an adoption (wmbm0007 server) issue due to broker's default directory.
#									  	Code has chnaged to use $INTDIR directory in place of broker's default directory
# 07/07/2017	Cognizant Offshore		PRB0226021: problem ticket related HIC Number issue has fixed for .GPS only file....... 
# 08/01/2017	Veerabadra Lokesh		Modified script for Inflight Priority Changes as part of "PRJ108989 - GPS EEMS SeeBeyond Replacement 2017" project.
###################################################################
#set -n
#set -x
LOG="/iib/scripts/logs/split.GPS.$3.log"
echo "**************************************************************************" >> $LOG
echo "* initProc_Split_GPS.sh started on `date`" >> $LOG
echo "**************************************************************************" >> $LOG

BaseFile="$1" # Reading the first parameter inbound file location
SubId="$2"
TransFileId="$3" # Reading the Third parameter transfileID
PFlag="$4" # Reading the fourth parameter transsetID
. /iib/scripts/InitialProcessing/split.cfg

echo "Input File size : `du -ch $BaseFile | grep total`" >> $LOG
echo "Input File: $BaseFile" >> $LOG
echo "Submitter Ids: $SubId" >> $LOG
echo "TransFileId: $TransFileId" >> $LOG
echo "Priority Flag: $PFlag" >> $LOG
echo "Threshold Value: $threshold" >> $LOG

version="V1.10"
INBDIR="/iib/scripts/InitialProcessing/split/files" #input file directory path
INTDIR="/iib/scripts/InitialProcessing/split/intermediate_files" # intermediate files directory path
mkdir $INTDIR/subid.$3
SUBIDDIR="$INTDIR/subid.$3"
mkdir $INTDIR/lrgfldir.$3
LRGSUBIDDIR="$INTDIR/lrgfldir.$3"
#Destination Directories
EEIDDIR="/eems/iib/be128/initialprocess/eeid"
SUBBIGDIR="/eems/iib/be128/inbound/small"
SUBSMALLDIR="/eems/iib/be128/inbound/small"
PSUBBIGDIR="/eems/iib/be128/inbound/small"
PSUBSMALLDIR="/eems/iib/be128/inbound/psmall"
FFMDIR="/eems/iib/be128/inbound/ffm"
INFLGT_PRRTY_FILE="/iib/scripts/InflightList.priority"
bold=$(tput bold)

# Get the parameters and make sure all the parameters are passed correctly
if [[ $# -ne 4 ]] 
then
	print "Usage: $0  <input file location> <submitter1,transetid1,surviverIndicator1:submitter2,transetid2,surviverIndicator2> <transfileid> <PFlag>" >> $LOG
	exit 10
fi
du -ch $BaseFile | grep total >> $LOG


COUNTBF=`head -1 $BaseFile | cut -c 1-8` #Audit count of the input file
REC_BF=`wc -l < $BaseFile`  #Count of lines in file

REC_BF1=`expr $REC_BF - 1` # Actual Record count of the input file excluding the header record)
if [ $COUNTBF -eq $REC_BF1 ]
then
        print "count in the $BaseFile file $COUNTBF and number of records in input file $REC_BF1,$REC_BF  are equal" >> $LOG
else
        print "count in the $BaseFile file $COUNTBF and number of records in input file $REC_BF1,$REC_BF are not equal ..But this doesnt fail the GPS file" >> $LOG
        echo $BaseFile >> $LOG
fi

FileName=`basename $BaseFile` # getting the exact input file
SubmitterId=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
FileU=`echo $FileName | awk '{split($0,a,"."); print a[2]}'`
FileDT=`echo $FileName | awk '{split($0,a,"."); print a[3]}'`
TransFileID=`echo $FileName | awk '{split($0,a,"."); print a[4]}'`
FileFormat=`echo $FileName | awk '{split($0,a,"."); print a[5]}'`
FName=`echo $SubmitterId.$FileU.$FileDT.$FileFormat`
Actual_Submitterid=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
echo " The actual file name is $FName " >> $LOG

#Below for single submission case, yet to code for multi
echo " `date` " >> $LOG
#TransSetID=`echo $2 |cut -f2 -d','`
TransSetID=`echo $2 | cut -d ',' -f2`
#currentSubmitterID=`echo $2 |cut -f1 -d','`
currentSubmitterID=`echo $2 | cut -d ',' -f1`
echo "TransSetID:$TransSetID :: currentSubmitterID:$currentSubmitterID" >> $LOG
tempEEIdFileName=$EEIDDIR/"EEID"_"$TransFileId"_"$TransSetID"_"$currentSubmitterID"_"$FName".tmp

#sed -i '1d' $BaseFile
#deleting the header count in basefile as it should not move for inbound
#sed '1d' $BaseFile > $SUBIDDIR/"$currentSubmitterID".$TransFileId
# DO NOT delete the header record as it already being deleted in SubmitCnt Script.
cp $BaseFile $SUBIDDIR/"$currentSubmitterID".$TransFileId 

#delete substitute character if found at the end
lastLineSize=`tail -1 $SUBIDDIR/"$currentSubmitterID".$TransFileId|wc -c`
if [[ $lastLineSize -lt 3  ]] then
	sed -ie '$d' $SUBIDDIR/"$currentSubmitterID".$TransFileId
fi

cut -c6-20 $SUBIDDIR/"$currentSubmitterID".$TransFileId | sed "s/[[:blank:]]*$//" | uniq > $INBDIR/submitterId.$3
version=`cat $SUBIDDIR/"$currentSubmitterID".$TransFileId | cut -c1-5 | uniq | grep -i "V"`
echo "GPS file vesrion:$version " >> $LOG
echo "Not generating EEIDs in this script for GPS alone as it is extracted by cascading inbound transformation and source flows directly" >> $LOG
#while read line
#do
	###########EEID file creation(hic nbr(Medicare_Number 111-122), emplr grpid(41-60), mbr brch(61-63) positions)###########
#	if [ $version = "V1.10" ]; then
#				echo "hic nbr, emplr grpid, mbr brch for $line " >> $LOG
#				echo "EEID file creation started at `date`" >> $LOG
#				if [ $line == $currentSubmitterID ]; then
#					echo "SubmitterID is:$line" >> $LOG					
#					cut -c41-60 $SUBIDDIR/"$currentSubmitterID".$TransFileId | sed -e "s/^[ \t]*//;s/[ \t]*$//" > $INBDIR/grpId.$3
#					cut -c61-63 $SUBIDDIR/"$currentSubmitterID".$TransFileId | sed -e "s/^[ \t]*//;s/[ \t]*$//" > $INBDIR/branch.$3
#					cut -c111-122 $SUBIDDIR/"$currentSubmitterID".$TransFileId | sed -e "s/^[ \t]*//;s/[ \t]*$//" > $INBDIR/hicNbr.$3					
#					#paste $INBDIR/hicNbr.$3 $INBDIR/grpId.$3 $INBDIR/branch.$3 | column -s $',' -t > $INBDIR/eeid.$3
#					#paste file1 file2 | sed 's/\t/\0\t/g' | column -s $'\t' -t
#					#[a-zA-Z0-9] or sed '/^.*$/!d' 
#					#paste -d"," $INBDIR/hicNbr.$3 $INBDIR/grpId.$3 $INBDIR/branch.$3 | awk '1 { print $1 ; next } { print $2 ; next } { print $3 }' > $INBDIR/eeid.$3
#					#PRB0226021- Added fix for problem ticket
#					paste -d"," $INBDIR/hicNbr.$3 $INBDIR/grpId.$3 $INBDIR/branch.$3 > $INBDIR/eeid.$3
#					#PRB0226021 - End of fix
#					cat $INBDIR/eeid.$3 | sort | uniq | awk 'NF > 0' > $EEIDDIR/"EEID"_"$TransFileId"_"$TransSetID"_"$currentSubmitterID"_"$FName"
#					MemberCnt=`cat $EEIDDIR/"EEID"_"$TransFileId"_"$TransSetID"_"$currentSubmitterID"_"$FName" | wc -l`
#					echo member count of EEID:$MemberCnt >> $LOG
#					du -ch $EEIDDIR/"EEID"_"$TransFileId"_"$TransSetID"_"$currentSubmitterID"_"$FName" | grep total >> $LOG
#					echo "EEID file creation completed at `date`" >> $LOG
#					#echo "`date`" >> $LOG
#				fi
#	fi
#done < $INBDIR/submitterId.$3

# while read line
# do	
	# if [[ $line == V1.10* ]]
	# then			
		# sbmtIDinLine=`echo "$line" | cut -c6-20 | tr -d ' '`
		# #echo "SubmitterID: $sbmtIDinLine " >> $LOG
		# if [[ $sbmtIDinLine == $currentSubmitterID ]]
		# then
			# #echo "found the specific submitter id line" >> $LOG
			# #hicNbr=`echo "$line" | cut -c111-122 | tr -d ' '`
			# grpId=`echo "$line" | cut -c41-60 | tr -d ' '`
			# branch=`echo "$line" | cut -c61-63 | tr -d ' '`
			# hicNbr=`echo "$line" | cut -c111-122 | tr -d ' '`
			# #print "$hicNbr,$grpId,$branch " >> $tempEEIdFileName
			# printf '%s\n' "$hicNbr,$grpId,$branch" >> $tempEEIdFileName
		# fi
	# fi
# done < $BaseFile
# cat $tempEEIdFileName | sort | uniq | awk 'NF > 0' > $EEIDDIR/"EEID"_"$TransFileId"_"$TransSetID"_"$currentSubmitterID"_"$FName"
# rm -rf $tempEEIdFileName

###########Split file creation###########
	
	if [[ $REC_BF1 -gt $threshold ]]
	then
		echo "Creating multiple split files started at `date` " >> $LOG
		cd $INTDIR #Using intermediate directory in-place of broker's default directory to fix permission issue in Adoption (wmbm0007)
          #Split first
          	#create a temp directory
          	mkdir split"$currentSubmitterID"."$TransFileId"
          	chmod 777 split"$currentSubmitterID"."$TransFileId"
          	
          	grep "V1.10" $BaseFile > split"$currentSubmitterID"."$TransFileId"/actualRecords."$FileName"
			
          	split -l $threshold split"$currentSubmitterID".$3/actualRecords.$FileName split"$currentSubmitterID".$3/
			fileRC=$?
			if [[ $filerc -eq 0 ]]
			then
				echo "Splitting is done: `date`" >> $LOG
				rm -rf split"$currentSubmitterID".$3/actualRecords."$FileName"
			else
				echo "Error in splitting file" >> $LOG
				exit 2
			fi
          	
			#Rename next
          	cd split"$currentSubmitterID".$3
          	totalSplitCnt=`ls -l | awk '{print $9}' | awk 'NF > 0' | wc -l`          	
			i=1
			MS=1 # member sequence start of the split file
			for file in *
			do
				echo $file >> $LOG
				cat $file | sed -e "s/.\{1391\}/&|/g" > test.$3
			
				tr -d '\b\r\n' < test.$3 > ${TransFileId}_${TransSetID}_${currentSubmitterID}_${version}_${i}_${totalSplitCnt}_${MS}_${FName}.temp
				rm -rf $file
				rm -rf test.$3
				mv ${TransFileId}_${TransSetID}_${currentSubmitterID}_${version}_${i}_${totalSplitCnt}_${MS}_${FName}.temp $LRGSUBIDDIR/
				#echo ${TransFileId}_${TransSetID}_${currentSubmitterID}_${version}_${i}_${totalSplitCnt}_${MS}_${FName} moved to $LRGSUBIDDIR/ >> $LOG
				du -ch  $LRGSUBIDDIR/${TransFileId}_${TransSetID}_${currentSubmitterID}_${version}_${i}_${totalSplitCnt}_${MS}_${FName}.temp | grep total >> $LOG
				#echo "`date`" >> $LOG
				
				mss=`expr $i \* $threshold`
				MS=`expr $mss + 1`
				i=`expr $i + 1`
          	done
          	cd ../
			#echo "All split files are moved to $LRGSUBIDDIR" >> $LOG
			echo "Split creation for large files completed :: `date` " >> $LOG
	else
		cd $INTDIR #Using intermediate directory in-place of broker's default directory to fix permisson issue in Adoption (wmbm0007)
		echo "Creating single split file..same as the original file started :: `date` " >> $LOG
		cur_dir=`pwd`
		echo "Current DIR: $cur_dir" >> $LOG
		
		mkdir split"$currentSubmitterID"."$TransFileId"		
    	chmod 777 split"$currentSubmitterID"."$TransFileId"
		
		grep "V1.10" $BaseFile > split"$currentSubmitterID"."$TransFileId"/actualRecords."$FileName"
		cd split"$currentSubmitterID".$3
		#cd split"$currentSubmitterID"."$TransFileId"		
		fileRC=$?		
		if [[ $fileRC -eq 0 ]] 
		then
        	echo "Change in directory `date`" >> $LOG
			cur_dir=`pwd`
			echo "Current DIR: $cur_dir" >> $LOG
        else
		    echo "Error while changing directory" >> $LOG
			exit 2
        fi
		
		cat actualRecords."$FileName" | sed -e "s/.\{1391\}/&|/g" > test.$3
    	#tr -d '\b\r\n' < test.$3 > actualRecords."$FileName"
		tr -d '\b\r\n' < test.$3 > ${TransFileId}_${TransSetID}_${currentSubmitterID}_${version}_1_1_1_${FName}.temp
		#mv actualRecords."$FileName" $SUBIDDIR/${TransFileId}_${TransSetID}_${currentSubmitterID}_${version}_1_1_1_${FName}.temp
		mv ${TransFileId}_${TransSetID}_${currentSubmitterID}_${version}_1_1_1_${FName}.temp $SUBIDDIR/
		
		rm -f test.$3
		#rm -f actualRecords."$FileName"
		rm -rf split"$currentSubmitterID"."$TransFileId"/actualRecords."$FileName"
		echo "Small file is moved to $SUBIDDIR directory" >> $LOG
		cd ../
		cur_dir=`pwd`
		echo "Current DIR: $cur_dir" >> $LOG
		#echo "Small file is moved to $SUBIDDIR " >> $LOG
		echo "Single split file creation completed :: `date`" >> $LOG
	fi
	#rm -rf $INTDIR/subid.$3 split"$currentSubmitterID"."$3"
	
	#START of Code changes added to fix performance issue as part of parallel testing (defect# 5472)
	#Start of encoding logic for large files where number of records count in file exceeds threshold value
	#NOTE1: This large file processing step may not require for GPS today; because, GPS files are <100 per day; and single path (/eems/iib/be128/inbound/small) is fine for GPS
	#NOTE2: In furture if GPS also has requirement to separate files among large/small directories, then below code for large file will be used.
	if [ -f $LRGSUBIDDIR/*.gps.temp ] # start of IF
	then
		echo "File exists and moving to larger directory" >> $LOG
		#Encoding file check for larger files
		echo "Encoding part for larger files" >> $LOG
		cd $LRGSUBIDDIR
		ls -ltr $LRGSUBIDDIR/*.gps.temp | awk '{print $9}' > encodelrgfiles
		i=1
		while read line
		do
			echo "`date`" >> $LOG
			echo "$i is $line" >> $LOG
			encoding=`file --mime-encoding $line`
			echo "before encoding of $i: $encoding" >> $LOG
			find . -type f -name "$line" -exec vim -S script.vim {} \;
			newencoding=`file --mime-encoding $line`
			echo "After encoding of $i: $newencoding" >> $LOG
			i=`expr $i + 1`
		done < encodelrgfiles
			
			#Handle other scenarios as well like priority, FFM and non-priority -
				#If it is priority input/inflight priority file move to priority destination directory
				if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ] || [ "`grep "_"$TransFileId"_"$TransSetID"_" $INFLGT_PRRTY_FILE | wc -l`" -gt 0 ]; then
					mv $LRGSUBIDDIR/*.gps.temp $PSUBSMALLDIR/
					echo $LRGSUBIDDIR/*.gps.temp moved to $PSUBSMALLDIR/ >> $LOG
					ls -lrt $PSUBSMALLDIR/*.gps.temp | awk '{print $9}' >> $LOG
					du -ch  $PSUBSMALLDIR/ | grep total >> $LOG
					InboundDir=$PSUBSMALLDIR  # Adding this line to change the .temp file to .gps files at the end
					echo "`date`" >> $LOG
					
				#If it is non-priority input file move to non-priority destination directory
				elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then
					mv $LRGSUBIDDIR/*.gps.temp $SUBBIGDIR/
					echo $LRGSUBIDDIR moved to $SUBBIGDIR/ >> $LOG
					ls -lrt $SUBBIGDIR/*.gps.temp | awk '{print $9}' >> $LOG
					du -ch $SUBBIGDIR/ | grep total >> $LOG
					InboundDir=$SUBBIGDIR		# Adding this line to change the .temp file to .gps files at the end
					echo "`date`" >> $LOG
				else
					echo "please pass the priority flag as Y or N" >> $LOG
				fi

				echo "rename from .temp to actual file-name for large/plarge/largeffm started at `date`" >> $LOG
				echo "finalInboundDir is $InboundDir" >> $LOG
				cd $InboundDir
				ls -ltr $InboundDir/*.gps.temp | awk '{print $9}' > renameTemp
				i=1
				while read line
				do
					echo "$i is $line" >> $LOG
					mv "$line" "${line%%.temp}"
					i=`expr $i + 1`
				done < renameTemp

				echo "rename from .temp to .gps end at `date`" >> $LOG

	fi #end of IF
	
	# Small files
	if [ -f $SUBIDDIR/*.gps.temp ]
	then
		echo "File exists and moving to smaller directory" >> $LOG
		#Encoding file check for smaller files
		echo "Encoding part for smaller files" >> $LOG
		cd $SUBIDDIR
		ls -ltr $SUBIDDIR/*.gps.temp | awk '{print $9}' > encodefiles
		i=1
		while read line
		do
			echo "`date`" >> $LOG
			echo "$i is $line" >> $LOG
			encoding=`file --mime-encoding $line`
			echo "before encoding of $i: $encoding" >> $LOG
			find . -type f -name "$line" -exec vim -S script.vim {} \;
			newencoding=`file --mime-encoding $line`
			echo "After encoding of $i: $newencoding" >> $LOG
			i=`expr $i + 1`

		done < encodefiles
		if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ] || [ "`grep "_"$TransFileId"_"$TransSetID"_" $INFLGT_PRRTY_FILE | wc -l`" -gt 0 ]; then # If it is priority input/inflight priority file move to priority destination directory
			echo "priority moving to inbound psmall directory" >> $LOG
			mv $SUBIDDIR/*.gps.temp $PSUBSMALLDIR/
			echo "$SUBIDDIR/ moved to $PSUBSMALLDIR/" >> $LOG
			ls -lrt $PSUBSMALLDIR/*.gps.temp | awk '{print $9}' >> $LOG
			du -ch $PSUBSMALLDIR/ | grep total >> $LOG
			echo "`date`" >> $LOG
			finalInboundDir=$PSUBSMALLDIR
		elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
			echo "Normal files to normal directory" >> $LOG
			mv $SUBIDDIR/*.gps.temp $SUBSMALLDIR/
			echo "$SUBIDDIR/ moved to $SUBSMALLDIR/" >> $LOG
			ls -lrt $SUBSMALLDIR/*.gps.temp | awk '{print $9}' >> $LOG
			du -ch $SUBSMALLDIR/ | grep total >> $LOG
			echo "`date`" >> $LOG
			finalInboundDir=$SUBSMALLDIR
		else
			echo "please pass the priority flag as Y or N" >> $LOG
			finalInboundDir="NONE"
		fi
		
		echo "rename from .temp to actual file-name started at `date`" >> $LOG
		echo "finalInboundDir is $finalInboundDir" >> $LOG
		cd $finalInboundDir
		ls -ltr $finalInboundDir/*.gps.temp | awk '{print $9}' > renameTemp
		i=1
		while read line
		do  
			echo "$i is $line" >> $LOG
			mv "$line" "${line%%.temp}"
			i=`expr $i + 1`
		done < renameTemp
		echo "rename from .temp to .gps end at `date`" >> $LOG

	else
		echo "Files are already moved to larger directory" >> $LOG
		#finalInboundDir=$InboundDir
	fi
	
	rm -rf $INBDIR/grpId.$3 $INBDIR/branch.$3 $INBDIR/hicNbr.$3
	rm -rf $INTDIR/split"$currentSubmitterID"."$TransFileId" $LRGSUBIDDIR/encodelrgfiles $SUBIDDIR/encodefiles $INTDIR/subid.$3 $INTDIR/lrgfldir.$3
	rm -rf $BaseFile
	echo " The removed files/directories are $INBDIR/grpId.$3 $INBDIR/branch.$3 $INBDIR/hicNbr.$3 $INTDIR/split"$currentSubmitterID"."$TransFileId" $LRGSUBIDDIR/encodelrgfiles $SUBIDDIR/encodefiles $INTDIR/subid.$3 $INTDIR/lrgfldir.$3 $BaseFile" >> $LOG
	
echo "**************************************************************************" >> $LOG
echo "* initProc_Split_workingpflag.sh ended on `date`" >> $LOG
echo "**************************************************************************" >> $LOG
return 1
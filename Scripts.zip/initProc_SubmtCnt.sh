#!/bin/ksh
###################################################################
# Module:      initProc_SubmtCntGSF.ksh
# Purpose:     Using inbound file it creates a file containing the list of submitter IDs against each Submitter ID. 
# Parameters : $1 - InputFile Name	
#	       $2 - TransfileID 			                 
# How to execute:      nohup ./initProc_SubmtCnt.ksh $1 $2 
#
# Maintenance:
# Date        Programmer              Description
# 5/28/2015  Cognizant Offshore       new script To creates a file containing the list of submitter IDs 
# 5/10/2016  Amresh Kosuru            addition of HIPAA 5010 to the functionality 
#									 
###################################################################
LOG="/iib/scripts/logs/submitcount.$2.log"

echo "**************************************************************************" >> $LOG
echo "* initProc_SubmtCnt.sh started on `date`" >> $LOG
echo "**************************************************************************" >> $LOG


# Get the parameters and make sure we have all of them
if [[ $# -ne 2 ]] then
  print "Usage: $0  <InputFile Name> <TransFileID> " >> $LOG
  exit 9
else
  BaseFile="$1"
  TransFileID="$2"
fi
echo "The input arguments for this script are :  Filename - $BaseFile :::: TransFileID - $TransFileID" >> $LOG 

## file format tr 'a-z' 'A-Z' $FileFormat - include in getting the file format #Reveiw comment

# Declare variables#
FileName=`basename $BaseFile`
SubmitterId=`echo $BaseFile | awk '{split($0,a,"."); print a[1]}'`
FileU=`echo $BaseFile| awk '{split($0,a,"."); print a[2]}'`
FileDT=`echo $BaseFile| awk '{split($0,a,"."); print a[3]}'`
IBTimeStamp=`echo $BaseFile | awk '{split($0,a,"."); print a[4]}'`
FileFormat=`echo $BaseFile| awk '{split($0,a,"."); print a[5]}'`
RenameBaseFile=`echo $SubmitterId.$FileU.$FileDT.$2.$FileFormat`
Actual_Submitterid=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
SubmitCountFileName=`echo $Actual_Submitterid.$FileU.$FileDT.$FileFormat`
echo $SubmitCountFileName >> $LOG
InputDirPath=`dirname $BaseFile`
OutFieldDelim="<subCntDelim>"
echo "The Input file is splitted into parts: SubmitterId:$SubmitterId FileU:$FileU FileDT:$FileDT IBTimeStamp:$IBTimeStamp FileFormat:$FileFormat" >> $LOG
echo "The Input File and the Renamed File are: $BaseFile $RenameBaseFile" >> $LOG


mv $BaseFile $RenameBaseFile
BaseFile=`echo $RenameBaseFile`
fileIn=`basename $BaseFile`

echo $fileIn >> $LOG
INB_DIR="/iib/scripts/InitialProcessing/SCRIPT/INPDIR"
TEMP_DIR="/iib/scripts/InitialProcessing/SCRIPT/TEMPDIR"

touch $INB_DIR/tempfile.$2


tr -d \"\\r\\n\" < $BaseFile > $TEMP_DIR/$fileIn || { exit 6; }
TEMP_FILENAME=`basename $fileIn`
TEMP_FILEIN="$TEMP_DIR/$fileIn"

##########
#       #converting ANSI to UTF-8
#        cd $TEMP_DIR
#        encodefile=$fileIn
#        encoding=`file --mime-encoding  $encodefile`
#        echo "Encoding of $encodefile: $encoding" >> $LOG
#        vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name  $encodefile)
#       newencoding=`file --mime-encoding  $fileIn`
#        echo "New Encoding of $encodefile: $newencoding" >> $LOG
#        cd -
###########

TEMP_INB_CNT_FILE="$TEMP_DIR/$TransFileID"_"$TEMP_FILENAME"
CNT_FILE="$TEMP_DIR/$TransFileID"_"$SubmitCountFileName"

#SubmitCount capture based on file types
lowerCaseFileFormat=`echo $FileFormat | tr '[:upper:]' '[:lower:]'`

case $lowerCaseFileFormat in 

	gsf)
	
		awk 'BEGIN {RS="|"; ctr=0; cnt=0; currSubId="";} 
		{ 
			if (ctr >= 1) {
		
				gsfVer=substr($0,1,5)
				if (gsfVer == "V1.50") {
				tmpSubId=substr($0,6,15);
				}else{
				if (gsfVer == "V5.10") {
				tmpSubId=substr($0,6,15);
				}else{
				tmpSubId=substr($0,6,20);
				}
				}
				gsub(/[ \t]+$/, "", tmpSubId);
				if (tmpSubId==currSubId){
					cnt++;
				}else {
					if (ctr == 1) {
					}else {
						print currSubId "," cnt;
					}
					currSubId=tmpSubId;
					cnt=1;
				}
			}
			ctr++;
		} END {print currSubId "," cnt;}' $TEMP_FILEIN > $TEMP_INB_CNT_FILE
	cat $TEMP_INB_CNT_FILE | cut -d "," -f1 | sort | uniq | awk 'NF > 0' > $INB_DIR/Submitters.$2

	while read line
	do
        	Submitter=`echo $line`
        	echo "The Submitter is :$Submitter" >> $LOG
        	grep -w "$Submitter" $TEMP_INB_CNT_FILE | cut -d "," -f2 > $INB_DIR/IndividualSubmitters.$2
        	SUM=0
        	while read NUM
        	do
                	echo "SUM: $SUM" >> $LOG
                	SUM=`expr $SUM + $NUM`
                	echo "+ $NUM: $SUM" >> $LOG
				echo "`date`" >> $LOG
        	done < $INB_DIR/IndividualSubmitters.$2
	echo "$Submitter$OutFieldDelim$SUM" >> $INB_DIR/tempfile.$2
	done < $INB_DIR/Submitters.$2
	cat $INB_DIR/tempfile.$2 > $CNT_FILE 
	rm -rf $INB_DIR/tempfile.$2 $INB_DIR/$fileIn $INB_DIR/IndividualSubmitters.$2 $INB_DIR/Submitters.$2 $TEMP_INB_CNT_FILE
	rm -f $TEMP_FILEIN || { exit 10; }
		
		;;
	
	hipaa)
	
	##########
       #converting ANSI to UTF-8
        cd $TEMP_DIR
        encodefile=$fileIn
        encoding=`file --mime-encoding  $encodefile`
        echo "Encoding of $encodefile: $encoding" >> $LOG
        vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name  $encodefile)
       newencoding=`file --mime-encoding  $fileIn`
        echo "New Encoding of $encodefile: $newencoding" >> $LOG
        cd -
	###########

	
	InboundCount=0

	delim=`cut -c 106 $TEMP_FILEIN`
	delimFS=`cut -c 4 $TEMP_FILEIN`
	FileHeader=`cut -d "$delim" -f1,2 $TEMP_FILEIN`$delim
	FileTrailer=`rev $TEMP_FILEIN |cut -d "$delim" -f1-3|rev`
	TEMP_SUBMIT_WRAPPERFILE=$TEMP_FILEIN.submitterWrappers
	
	#Get SubmitterList	
	awk -v delim="$delim" -v delimFS="$delimFS" 'BEGIN {RS=delim; FS=delimFS} {
		if ($1 == "REF" && $2 == "38") {
	   	subGrpId=$3;
	   	recCtr=0;
		}
		else if ($1 == "INS") {
	  	recCtr++;	   
		}
		else if ($1 == "SE") {
	   	print subGrpId","recCtr;	   
		}
	} ' $TEMP_FILEIN > $TEMP_INB_CNT_FILE
	cat $TEMP_INB_CNT_FILE | cut -d "," -f1 | sort | uniq | awk 'NF > 0' > $INB_DIR/Submitters.$2

	
	
	#Get Segments for submitter level headers and trailers
	TEMPFILEINVAR=`cat $TEMP_FILEIN`
  segmentTrackVar="OFF"
        IFS=$delim
        for segment in $TEMPFILEINVAR
        do
                if [[ "$segment" == ST* ]] then
                        #echo In ST Case
                        segmentTrackVar="ON"
                        #echo $segmentTrackVar is segment start
                        echo $segment"$delim" | tr -d '\n' >> $TEMP_SUBMIT_WRAPPERFILE
                else
                        if [[  "$segment" == INS*  ]] then
                                #echo do nothing for INS
                                segmentTrackVar="OFF"
                        else
                                if [[  "$segment" == SE*  ]] then
                                        print $OutFieldDelim$segment"$delim" >> $TEMP_SUBMIT_WRAPPERFILE
                                        #echo In SE Case
                                else
                                        if [[ "$segmentTrackVar" == ON ]] then
                                                #echo Other segment
                                                echo $segment"$delim" | tr -d '\n' >> $TEMP_SUBMIT_WRAPPERFILE
                                        fi
                                fi
                        fi
                fi
        done

	while read line
	do
        	Submitter=`echo $line`
        	echo "The Submitter is :$Submitter" >> $LOG
        	grep -w "$Submitter" $TEMP_INB_CNT_FILE | cut -d "," -f2 > $INB_DIR/IndividualSubmitters.$2
        	SUM=0
        	while read NUM
        	do
                	echo "SUM: $SUM" >> $LOG
                	SUM=`expr $SUM + $NUM`
                	echo "+ $NUM: $SUM" >> $LOG
									echo "`date`" >> $LOG
  				done < $INB_DIR/IndividualSubmitters.$2
  HIPAA_Header=$FileHeader
  HIPAA_Trailer=$FileTrailer
  #generate rows to the Submitter Count file
  echo "$Submitter$OutFieldDelim$SUM$OutFieldDelim$HIPAA_Header`grep -F 'REF'$delimFS'38'$delimFS$Submitter"$delim" $TEMP_SUBMIT_WRAPPERFILE | head -1`$HIPAA_Trailer" >> $INB_DIR/tempfile.$2
	
	done < $INB_DIR/Submitters.$2
	
	#converting ANSI to UTF-8
	cd $INB_DIR
	encodefile=tempfile.$2
	encoding=`file --mime-encoding  $encodefile`                                        
	echo "Encoding of $encodefile: $encoding" >> $LOG                              
	vim +"set nobomb | set fileencoding=utf-8 | wq" $(find . -type f -name  $encodefile)
	mv $encodefile $CNT_FILE
	#$encodefile > $CNT_FILE                                          
	newencoding=`file --mime-encoding  $CNT_FILE`
	echo "New Encoding of $encodefile: $newencoding" >> $LOG                             

	#cat $INB_DIR/tempfile.$2 > $CNT_FILE 
	rm -rf $INB_DIR/tempfile.$2 $INB_DIR/$fileIn $INB_DIR/IndividualSubmitters.$2 $INB_DIR/Submitters.$2 $TEMP_INB_CNT_FILE $TEMP_SUBMIT_WRAPPERFILE $encodefile
	rm -f $TEMP_FILEIN || { exit 10; }
		
		;;	
esac	

echo "**************************************************************************" >> $LOG
echo "* initProc_SubmtCnt.sh ended on `date`" >> $LOG
echo "**************************************************************************" >> $LOG
return 1

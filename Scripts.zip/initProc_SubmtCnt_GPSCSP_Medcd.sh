#!/bin/ksh
###################################################################
# Module:      initProc_SubmtCnt_GPSCSP_Medcd.ksh
# Purpose:     Using inbound file it creates a file containing the list of submitter IDs against each Submitter ID. 
# Parameters : $1 - InputFile Name	
#	       $2 - TransfileID 			                 
# How to execute:      nohup ./initProc_SubmtCntGPSCSP.ksh $1 $2 
#
# Maintenance:
# Date        Programmer              	Description
# 10/14/2016  Cognizant Offshore       	New script creates a file containing the list of submitter IDs 
#									 
###################################################################
CSP_LOG="/iib/scripts/logs/Medcd_SubmtCnt.$2.log"
echo "**************************************************************************" >> $CSP_LOG
echo "* initProc_SubmtCnt.sh started on `date`" >> $CSP_LOG
echo "**************************************************************************" >> $CSP_LOG
# Get the parameters and make sure we have all of them
if [[ $# -ne 2 ]] then
  print "Usage: $0  <InputFile Name> <TransFileID> " >> $CSP_LOG
  exit 9
else
  BaseFile="$1"
  TransFileID="$2"
fi
echo "The inputs for this script are: Filename:$BaseFile TransFileID:$TransFileID" >> $CSP_LOG 
FileName=`basename $BaseFile`
SubmitterId=`echo $BaseFile | awk '{split($0,a,"."); print a[1]}'`
FileU=`echo $BaseFile| awk '{split($0,a,"."); print a[2]}'` 
FileDT=`echo $BaseFile| awk '{split($0,a,"."); print a[3]}'` 
IBTimeStamp=`echo $BaseFile | awk '{split($0,a,"."); print a[4]}'`
FileFormat=`echo $BaseFile| awk '{split($0,a,"."); print a[5]}'` 
RenameBaseFile=`echo $SubmitterId.$FileU.$FileDT.$2.$FileFormat`
Actual_Submitterid=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
SubmitCountFileName=`echo $Actual_Submitterid.$FileU.$FileDT.$FileFormat`

#Converting file extensions to Lowercase 
LC_FileFormat=`echo $FileFormat | tr '[:upper:]' '[:lower:]'`

#echo $SubmitCountFileName >> $CSP_LOG
if [[$LC_FileFormat == 'gcf']] 
then
	CNT=`tail -1 $BaseFile | cut -c 2-7`
	echo "The input file type is of GCF format and its submitter count is: $CNT" $CSP_LOG
else
	HDT=`head -1 $BaseFile |cut -c2-11|tr -d '-'`"0000"
	CNT=`sed -n '1p;1q' $BaseFile | cut -c 17-27`
  GRPID=`sed -n '2p' $BaseFile | cut -c 2-9`
	echo "The input file type is of ECF format and its submitter count is: $CNT and groupID : $GRPID" >> $CSP_LOG
fi

InputDirPath=`dirname $BaseFile`
echo "The Input file is splitted into parts: SubmitterId:$SubmitterId FileU:$FileU FileDT:$FileDT FileFormat:$LC_FileFormat" >> $CSP_LOG
echo "The Input File and the Renamed File are: $BaseFile $RenameBaseFile" >> $CSP_LOG
`mv $BaseFile $RenameBaseFile`
#BaseFile=`echo $RenameBaseFile`
#fileIn=`basename $BaseFile`
#sed -i '/^\s*$/d' $BaseFile
echo $fileIn >> $CSP_LOG
INB_DIR="/iib/scripts/CSP/InitialProcessing/TempDir"
TEMP_DIR="/iib/scripts/CSP/InitialProcessing/TempDir"
#rm -rf $TEMP_DIR/*
#rm -rf $INB_DIR/tempfile
#rm -rf $INB_DIR/*.gsf
#touch $INB_DIR/tempfile.$2
#chmod 777 $INB_DIR/tempfile.$2
#cp -f $BaseFile $INB_DIR/
#filerc=$?
#if [[ $filerc -eq 0 ]]
#then
#	echo "Inbound File Moved Successfully to $INB_DIR" >> $CSP_LOG
#else
#	echo "Error Moving Inbound file from $BaseFile to $INB_DIR" >> $CSP_LOG
	#REMOVE_LOCK
#	exit 99
#fi
#tr -d \"\\r\\n\" < $INB_DIR/$fileIn > $TEMP_DIR/$fileIn || { exit 6; }
#tr -d \"\\r\\n\" < $BaseFile > $TEMP_DIR/$fileIn || { exit 6; }
#TEMP_FILENAME=`basename $fileIn`
#TEMP_FILEIN="$TEMP_DIR/$fileIn"
#TEMP_COUNT_FILE="$TEMP_DIR/
#TEMP_INB_CNT_FILE="$TEMP_DIR/$TransFileID"_"$TEMP_FILENAME"

CNT_FILE="$TEMP_DIR/$TransFileID"_"$SubmitCountFileName"
echo "$Actual_Submitterid,$CNT,$GRPID,$HDT" > $CNT_FILE
#	awk 'BEGIN {RS="|"; ctr=0; cnt=0; currSubId="";}
#	{
#		if (ctr >= 1) {
#		
#			gsfVer=substr($0,1,5)
#			if (gsfVer == "V1.50") {
#			tmpSubId=substr($0,6,15);
#			}else{
#			if (gsfVer == "V5.10") {
#			tmpSubId=substr($0,6,15);
#			}else{
#			tmpSubId=substr($0,6,20);
#			}
#			}
#			gsub(/[ \t]+$/, "", tmpSubId);
#			if (tmpSubId==currSubId){
#				cnt++;
##			}else {
#			if (ctr == 1) {
#				}else {
#					print currSubId "," cnt;
#				}
#				currSubId=tmpSubId;
#				cnt=1;
#			}
#		}
#		ctr++;
#	} END {print currSubId "," cnt;}' $TEMP_FILEIN > $TEMP_INB_CNT_FILE
#cat $TEMP_INB_CNT_FILE | cut -d "," -f1 | sort | uniq | awk 'NF > 0' > $INB_DIR/Submitters.$2
#while read line
#do
#        Submitter=`echo $line`
#        echo "The Submitter is :$Submitter" >> $CSP_LOG
#        grep -w "$Submitter" $TEMP_INB_CNT_FILE | cut -d "," -f2 > $INB_DIR/IndividualSubmitters.$2
#        SUM=0
#        while read NUM
#        do
#                echo "SUM: $SUM" >> $CSP_LOG
#                SUM=`expr $SUM + $NUM`
#                echo "+ $NUM: $SUM" >> $CSP_LOG
#		echo "`date`" >> $CSP_LOG
#        done < $INB_DIR/IndividualSubmitters.$2
#echo "$Submitter,$SUM" >> $INB_DIR/tempfile.$2
#done < $INB_DIR/Submitters.$2
#cat $INB_DIR/tempfile.$2 > $CNT_FILE 
#rm -rf $INB_DIR/tempfile.$2 $INB_DIR/$fileIn $INB_DIR/IndividualSubmitters.$2 $INB_DIR/Submitters.$2 $TEMP_INB_CNT_FILE
#rm -f $TEMP_FILEIN || { exit 10; }
#fi
echo "**************************************************************************" >> $CSP_LOG
echo "* initProc_SubmtCnt_GPSCSP_Medcd.ksh ended on `date`" >> $CSP_LOG
echo "**************************************************************************" >> $CSP_LOG
return 1

#!/bin/ksh

###################################################################################################################
##      NAME:           gw_BE085_SFTP_archive_done_files.sh
##      PURPOSE:        This script is called by Autosys to archive gateway .done files to different archive directory
## Maintenance:
## Date        Programmer              Description
## 8/5/2015  Cognizant Offshore        This script is called by Autosys to archive gateway .done files to different archive directory
##
###################################################################################################################

SuccessCode=1
FailureCode=10
RC=$SuccessCode
CUR_DATE="`date '+%Y%m%d%H%M%S'`"
. /ebb2bpdapp/scripts/gw_to_iib_env.ksh
cd $GWDIR
for file_to_archive in `ls -l *.done | awk '{print $9}'`
do
  LOG_FILENAME=$CUR_DATE$file_to_archive
  file_to_archive=$GWDIR/$file_to_archive
  if mv $file_to_archive $GWARCHIVEDIR/$LOG_FILENAME
  then
      print "* $file_to_archive moved from $GWDIR= to $GWARCHIVEDIR" >> /ebb2bpdapp/logs/gw_to_iib_be085_xfer.log
  else
      print "* mv of $file_to_archive from $GWDIR= to $GWARCHIVEDIR failed" >> /ebb2bpdapp/logs/gw_to_iib_be085_xfer.log
      RC=$FailureCode
  fi
done


#!/bin/ksh
###################################################################
# Module:      initProc_SplitFile_GPSCSP_Medcd.sh
# Purpose:     Using inbound file and priority Submitter ID, it will split the file into n number of files based on the threshold value
# Parameters : 
#              		   $1 - InputFile path	
#			   $2 - Priority Submitter ID seperated by colon(:)
#			   $3 - TransfileID
#			   $4 - Priority flag 			                 
# 
# How to execute:      nohup ./initProc_SplitFile_GPSCSP_Medcd.sh $1 $2 $3 $4
# Example:	       nohup ./initProc_SplitFile_GPSCSP_Medcd.sh /iib/scripts/CSP/InitialProcessing/split/files/NESHADF.M.201610200724.8888.ecf NESHADF 2222 N
# 
# Maintenance:
# Date        	Programmer              Description
# ------------------------------------------------
# 10/18/2016  	Cognizant Offshore      New script to split large file into small files according to the threshold value
# 10/20/2016  	Cognizant Offshore	• Modified to Extract Group ID value from position: 2 to 9;
#					• Modified to Extract Version value from Position:  12 to 17;
#					• Modified to have each Detail Record within split file is terminated with NL (New Line) Character
###################################################################
CSP_MEDCD_LOG="/iib/scripts/logs/medcd_split.$3.log"
echo "**************************************************************************" >> $CSP_MEDCD_LOG
echo "* initProc_SplitFile_GPSCSP_Medcd.sh started on `date`" >> $CSP_MEDCD_LOG
echo "**************************************************************************" >> $CSP_MEDCD_LOG
BaseFile="$1" # Reading the first parameter inbound file location
SubId="$2"
TransFileId="$3" # Reading the Third parameter transfileID
PFlag="$4" # Reading the fourth parameter transsetID
. /iib/scripts/CSP/split.cfg
#threshold=6000 # by default assuming the threshold value as 6000
#FName=`basename $MainBaseFile` # getting the exact input file 
#echo "`date`" >> $CSP_MEDCD_LOG
#echo "The original input file name is: $MainBaseFile" >> $CSP_MEDCD_LOG
#mv $MainBaseFile $MainBaseFile.$3
#echo "`date`" >> $CSP_MEDCD_LOG
#BaseFile=$MainBaseFile.$3
du -ch $BaseFile | grep total >> $CSP_MEDCD_LOG
echo "Input File: $BaseFile" >> $CSP_MEDCD_LOG 
echo "Submitter Ids: $SubId" >> $CSP_MEDCD_LOG
echo "TransFileId: $TransFileId" >> $CSP_MEDCD_LOG
echo "Priority Flag: $PFlag" >> $CSP_MEDCD_LOG
echo "Threshold Value: $threshold" >> $CSP_MEDCD_LOG
#sed -i '/^\s*$/d' $BaseFile
INBDIR="/iib/scripts/CSP/InitialProcessing/split/files" #input file directory path
INTDIR="/iib/scripts/CSP/InitialProcessing/split/intermediate_files" # intermediate files directory path
mkdir $INTDIR/subid.$3
SUBIDDIR="$INTDIR/subid.$3"
#Destination Directories
EEIDDIR="/eems/iib/CSP/initialprocess/eeid"
SUBBIGDIR="/eems/iib/CSP/inbound/small"
SUBSMALLDIR="/eems/iib/CSP/inbound/small"
PSUBBIGDIR="/eems/iib/CSP/inbound/small"
PSUBSMALLDIR="/eems/iib/CSP/inbound/small"
FFMDIR="/eems/iib/be128/inbound/ffm"
bold=$(tput bold)
# Get the parameters and make sure all the parameters are passed correctly
if [[ $# -ne 4 ]] 
then
	print "Usage: $0  <input file location> <submitter1,transetid1,surviverIndicator1:submitter2,transetid2,surviverIndicator2> <transfileid> <PFlag>"
	exit 10
fi

du -ch $BaseFile | grep total >> $CSP_MEDCD_LOG

#FileName=`basename $BaseFile` #getting the exact input file
#FileFormat=`echo $FileName | awk '{split($0,a,"."); print a[5]}'`
#echo "File format is of $FileFormat type" >> $CSP_MEDCD_LOG

#Converting file extensions to Lowercase 
#LC_FileFormat=`echo $FileFormat | tr '[:upper:]' '[:lower:]'`

#if [[ $LC_FileFormat == 'gcf' ]] 
#then
#	COUNTBF=`tail -1 $BaseFile | cut -c 2-7` #The input file record count from Trailer
#else
	#COUNTBF=`head -1 $BaseFile | cut -c 17-27` #The input file record count from Header
#	COUNTBF=`sed -n '1p;1q' $BaseFile | cut -c 17-27` #The input file record count from Header
#fi
#echo "Count in the $BaseFile file of LC_FileFormat type is $COUNTBF" >> $CSP_MEDCD_LOG

COUNTBF=`sed -n '1p;1q' $BaseFile | cut -c 17-27` #The input file record count from Header
REC_BF=`wc -l < $BaseFile` 

REC_BF1=`expr $REC_BF - 1` # Record count of the input file excluding Header

if [ $COUNTBF -eq $REC_BF1 ] || [ $COUNTBF -eq $REC_BF ]
then
        print "Count in the $BaseFile file $COUNTBF and number of records in input file $REC_BF1 are equal" >> $CSP_MEDCD_LOG 
        LINE_BF=`cat $BaseFile | wc -l` #Line count of input file
        LINE1_BF=`expr $LINE_BF - 1` 
        echo $LINE_BF $LINE1_BF >> $CSP_MEDCD_LOG
        if [ $REC_BF1 -eq $LINE1_BF ] || [ $COUNTBF -eq $LINE_BF ]
        then
                echo "Data is line by line in $BaseFile" >> $CSP_MEDCD_LOG
        else
                echo "Data is not in correct format" >> $CSP_MEDCD_LOG
        fi 
else
        print "Count in the $BaseFile file $COUNTBF and number of records in input file $REC_BF1 are not equal" >> $CSP_MEDCD_LOG
        echo $BaseFile >> $CSP_MEDCD_LOG
      	exit 9
fi
FileName=`basename $BaseFile` # getting the exact input file 
SubmitterId=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
FileU=`echo $FileName | awk '{split($0,a,"."); print a[2]}'` 
FileDT=`echo $FileName | awk '{split($0,a,"."); print a[3]}'` 
TransFileID=`echo $FileName | awk '{split($0,a,"."); print a[4]}'`
FileFormat=`echo $FileName | awk '{split($0,a,"."); print a[5]}'` 
FName=`echo $SubmitterId.$FileU.$FileDT.$FileFormat`
Actual_Submitterid=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
echo " The actual file name is $FName " >> $CSP_MEDCD_LOG
$Actual_Submitterid  > $INTDIR/file.txt.$3 # Taking the submitter ids from input file
awk 'NF > 0' $INTDIR/file.txt.$3 > $INTDIR/file1.txt.$3 # Submitter ids 
CSub=`cat $INTDIR/file1.txt.$3 | wc -l` #count the number of submitters
echo $SubId > $INTDIR/submitters.txt.$3 # storing the 2nd input parameter submitterid,transsetid,surviver indicator into a file
SubCount1=`grep -o ":" $INTDIR/submitters.txt.$3 | wc -l` # counting the number of submitters from the input parameter
SubCount=`expr $SubCount1 + 1`
for i in {1..$SubCount}
do
	SubmiterId=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f1` # submitter id from input parameter
	SurviverIndicator=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f3` # surviver indicator from input parameter
	CombSubSurInd="$SubmiterId""|""$SurviverIndicator" # surviver indicator and submitter id
	echo "$CombSubSurInd" >> $INTDIR/submitterids.txt.$3 #submitter id and surviver indicator 
	TransSetId=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f2`	# extracting the transet id from input file
	echo $TransSetId >> $CSP_MEDCD_LOG
	echo $TransSetId >> $INTDIR/transsetids.txt.$3
	echo $i is $SubmiterId, $TransSetId >> $CSP_MEDCD_LOG
done	

#splitting the files if the file is having lines more than the thrshold value at submitter level
#InputFileName=$BaseFile

Counter1=1
#cd $INBDIR
#ipfilename=`ls -la *.gsf | awk '{print $9}'`
while read line
	do  
	    echo "`date`" >> $CSP_MEDCD_LOG
		echo $line >> $CSP_MEDCD_LOG 
		s=`echo $line | cut -f1 -d"|"` # submitter id from the file $INTDIR/"submitterids.txt".$3
		SurviverIndicator=`echo $line | cut -f2 -d"|"` #TBD need to take from $2
		echo $s $SurviverIndicator >> $CSP_MEDCD_LOG
		TId=`awk NR==$Counter1 $INTDIR/transsetids.txt.$3`
		echo "transset id of $Counter1 is $TId" >> $CSP_MEDCD_LOG
		version=`head -1 "$BaseFile" | cut -c 12-17`
		echo $version $s >> $CSP_MEDCD_LOG
		versub=`echo $version$s`
		echo $versub >> $CSP_MEDCD_LOG
#       sed '1d;$d' $BaseFile > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
		sed '1d' $BaseFile > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#		grep "$versub" $BaseFile > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#		#grep "$versub" $INBDIR/$FName > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#		#grep -w "\<$versub\>" $INBDIR/$FName > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#extracting EEId for version V2.1
#if [ $version = "V1.00" ] || [ $version = "v1.00" ]; then
	echo "Payee SSN for $version and $SurviverIndicator" >> $CSP_MEDCD_LOG
	echo "`date`" >> $CSP_MEDCD_LOG
#	if [ "$SurviverIndicator" = "Y" ] || [ "$SurviverIndicator" = "y" ]; then
#		echo "surviver indicator is true loop" >> $CSP_MEDCD_LOG
	#	cut -c1296-1343 $SUBIDDIR/"$s".$3 | sed "s/[[:blank:]]*$//" > $INBDIR/payeessn.$3
#		cut -c1-9 $SUBIDDIR/"$s".$3 | sed "s/[[:blank:]]*$//" > $INBDIR/employeeid.$3
#		#paste $INBDIR/payeessn.$3 $INBDIR/employeeid.$3 | awk -F '\t' '$1 { print $1 ; next } { print $2 }' > $INBDIR/eeid.$3
#		cat $INBDIR/employeeid.$3 | awk '1 { print $1 ; next } { print $2 }' > $INBDIR/eeid.$3
##		cat $INBDIR/eeid.$3 | sort | uniq > $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName"
#		MemCnt=`cat $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | wc -l`
#		MemberCnt=`echo $s\_$MemCnt`
#		echo member count of EEID:$MemberCnt >> $CSP_MEDCD_LOG
##		du -ch $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | grep total >> $CSP_MEDCD_LOG
#		echo "EEID completed `date`" >> $CSP_MEDCD_LOG
#	elif [ "$SurviverIndicator" = "N" ] || [ "$SurviverIndicator" = "n" ]; then
		echo "Employee ID for $version and $SurviverIndicator" >> $CSP_MEDCD_LOG
		cut -c2-9 $SUBIDDIR/"$s".$3 | sed "s/[[:blank:]]*$//" | sort | uniq > $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName"
		MemCnt=`cat $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | wc -l`
		MemberCnt=`echo $s\_$MemCnt`
		echo member count of EEID id:$MemberCnt >> $CSP_MEDCD_LOG
		du -ch $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | grep total >> $CSP_MEDCD_LOG
		echo "EEID completed `date`" >> $CSP_MEDCD_LOG
#	else 
#		echo "please pass valid suriviver indicator"
#	fi
	echo "`date`" >> $CSP_MEDCD_LOG
#fi


#if [ "$version" = "2.10" ]; then
#Splitting the files and sending to inbound 
		Lines1=`tr -d -C "\n" < $SUBIDDIR/"$s".$3 | wc -c`
		echo "lines are total : "$Lines1 >> $CSP_MEDCD_LOG
		basefilelines=`tr -d -C "\n" < $BaseFile | wc -c`
		echo $basefilelines >> $CSP_MEDCD_LOG
		echo " $BaseFile total lines : $basefilelines" >> $CSP_MEDCD_LOG
		if [ "$Lines1" -gt "$threshold" ] 
		then
		#if input files records are more than threshold value then it will enter this loop
			cd $SUBIDDIR
			mkdir split"$s".$3
			chmod 777 split"$s".$3
			split -l $threshold $s.$3 split"$s".$3/ # splittng the files based on the threshold value
			filerc=$?
			if [[ $filerc -eq 0 ]] 
			then
        			echo "split is done `date`" >> $CSP_MEDCD_LOG
        		else
		                echo "Error in splitting file" >> $CSP_MEDCD_LOG
				exit 2
        		fi
			cd split"$s".$3
			ls -l | awk '{print $9}' | awk 'NF > 0' >> $INTDIR/subsplit$s.txt.$3
			SSN=`cat $INTDIR/subsplit$s.txt.$3 | wc -l` # count of the number of split files
			echo "Splitted no. of files for submitter $s is : $SSN" >> $CSP_MEDCD_LOG
			cd $SUBIDDIR/split"$s".$3
			i=1
			MS=1 # member sequence start of the split file
			for file in *
			do
				echo $file >> $CSP_MEDCD_LOG
        version="V1.00"
        echo "$version"
				mv $file ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp
				if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ]; then # If it is priority input file move to priority destination directory
					mv ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $PSUBSMALLDIR/
					echo ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp moved to $PSUBSMALLDIR/ >> $CSP_MEDCD_LOG
					du -ch  $PSUBSMALLDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp | grep total >> $CSP_MEDCD_LOG
					mv $PSUBSMALLDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $PSUBSMALLDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}
					echo "Split renamed back to actual Name" >> $CSP_MEDCD_LOG
					echo "`date`" >> $CSP_MEDCD_LOG
				elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
					mv ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $FFMDIR/
					echo ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp moved to $FFMDIR/ >> $CSP_MEDCD_LOG
					du -ch $FFMDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp | grep total >> $CSP_MEDCD_LOG
					mv $FFMDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $FFMDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}
					echo "Split renamed back to actual Name" >> $CSP_MEDCD_LOG
				echo "`date`" >> $CSP_MEDCD_LOG
				elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
					mv ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $SUBBIGDIR/
					echo ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp moved to $SUBBIGDIR/ >> $CSP_MEDCD_LOG
					du -ch $SUBBIGDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp | grep total >> $CSP_MEDCD_LOG
					mv $SUBBIGDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $SUBBIGDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}
					echo "Split renamed back to actual Name" >> $CSP_MEDCD_LOG
					echo "`date`" >> $CSP_MEDCD_LOG
				else
					echo "please pass the priority flag as Y or N" >> $CSP_MEDCD_LOG
				fi
				mss=`expr $i \* $threshold`
				MS=`expr $mss + 1`
				i=`expr $i + 1`
				echo "`date`" >> $CSP_MEDCD_LOG
		done
		else
# if total records are less than the thrshold value it will be coming into this loop
			i=1
			MS=1
			SSN=1
			echo "no splitting" >> $CSP_MEDCD_LOG
			#sed -i '1d' $BaseFile
			version=`head -1 "$BaseFile" | cut -c 12-17`
			Destfilename=`echo ${TransFileId}"_"${TId}"_"${s}"_"${version}"_"${i}"_"${SSN}"_"${MS}"_"${FName} | tr -d ' '`
#			`cat $SUBIDDIR/"$s".$3 | sed -e "s/.\{15863\}/&|/g" > $SUBIDDIR/Pipe_"$s".$3`
			`cat $SUBIDDIR/"$s".$3 | sed -e "s/.\$//g" > $SUBSMALLDIR/$Destfilename.temp`
#			tr -d '\b\r\n' < $SUBIDDIR/Pipe_"$s".$3 > $SUBSMALLDIR/$Destfilename
			echo "non priority moving to inbound directory `date`" >> $CSP_MEDCD_LOG
			if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ]; then # If it is priority input file move to priority destination directory
				echo "priority moving to inbound psmall directory as a .temp file" >> $CSP_MEDCD_LOG
				mv $SUBSMALLDIR/$Destfilename.temp $PSUBSMALLDIR/$Destfilename.temp
				echo "$SUBSMALLDIR/$Destfilename.temp moved to $PSUBSMALLDIR/$Destfilename.temp" >> $CSP_MEDCD_LOG
				du -ch $PSUBSMALLDIR/$Destfilename.temp | grep total >> $CSP_MEDCD_LOG
				mv $PSUBSMALLDIR/$Destfilename.temp $PSUBSMALLDIR/$Destfilename
				echo "temp file renamed back to actual Name" >> $CSP_MEDCD_LOG
				echo "`date`" >> $CSP_MEDCD_LOG
			elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
        echo "FFM moving to inbound FFM directory as a .temp" >> $CSP_MEDCD_LOG
				mv $SUBSMALLDIR/$Destfilename.temp $FFMDIR/$Destfilename.temp
				echo "$SUBSMALLDIR/$Destfilename.temp moved to $FFMDIR/$Destfilename.temp" >> $CSP_MEDCD_LOG
				du -ch $FFMDIR/$Destfilename.temp | grep total >> $CSP_MEDCD_LOG
				mv $FFMDIR/$Destfilename.temp $FFMDIR/$Destfilename
				echo "temp file renamed back to actual Name" >> $CSP_MEDCD_LOG
				echo "`date`" >> $CSP_MEDCD_LOG
			elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
        echo "already in small directory" >> $CSP_MEDCD_LOG
				echo "$SUBIDDIR/$s moved to $SUBSMALLDIR/$Destfilename.temp" >> $CSP_MEDCD_LOG
				du -ch $SUBSMALLDIR/$Destfilename.temp | grep total >> $CSP_MEDCD_LOG
				mv $SUBSMALLDIR/$Destfilename.temp $SUBSMALLDIR/$Destfilename
				echo "`date`" >> $CSP_MEDCD_LOG
			else
				echo "please pass the priority flag as Y or N" >> $CSP_MEDCD_LOG
			fi
		fi 
		Counter1=`expr $Counter1 + 1`
done < $INTDIR/"submitterids.txt".$3
rm -rf $BaseFile $INBDIR/$INPUTFILE.$3 $INBDIR/$FName $INBDIR/$FName.$3 $SUBIDDIR/Pipe_"$s".$3 $INBDIR/payeessn.$3 $INBDIR/employeeid.$3 $INBDIR/eeid.$3 $INTDIR/file.txt.$3 $INTDIR/file1.txt.$3 $INTDIR/subBigDIRfiles.$3 $INTDIR/submitterids.txt.$3 $INTDIR/submitters.txt.$3 $INTDIR/test.$3 $INTDIR/transsetids.txt.$3 $INTDIR/subsplit$s.txt.$3 $SUBIDDIR/"$s".$3 $SUBIDDIR/split"$s".$3 $INTDIR/subid.$3 $SUBIDDIR
echo "**************************************************************************" >> $CSP_MEDCD_LOG
echo "* initProc_SplitFile_GPSCSP_Medcd ended on `date`" >> $CSP_MEDCD_LOG
echo "**************************************************************************" >> $CSP_MEDCD_LOG
return 1

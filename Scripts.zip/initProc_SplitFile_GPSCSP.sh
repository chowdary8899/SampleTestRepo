#!/bin/ksh
###################################################################
# Module:      initProc_Split.sh
# Purpose:     Using inbound file and priority Submitter ID, it will split the file into n number of files based on the threshold value
# Parameters : 
#              		   $1 - InputFile path	
#			   $2 - Priority Submitter ID seperated by colon(:)
#			   $3 - TransfileID
#			   $4 - Priority flag 			                 
# How to execute:      nohup ./initProc_Split.sh $1 $2 $3 $4
# Example:	       nohup ./initProc_Split.sh /iib/be128/initialprocess/input MASTESTA,2222,Y  6666 N
# Maintenance:
# Date        Programmer              Description
# 06/16/2015  Cognizant Offshore       new script To split large file into small files according to the threshold value
###################################################################
LOG="/iib/scripts/logs/split.$3.log"
echo "**************************************************************************" >> $LOG
echo "* initProc_Split_workingpflag.sh started on `date`" >> $LOG
echo "**************************************************************************" >> $LOG
BaseFile="$1" # Reading the first parameter inbound file location
SubId="$2"
TransFileId="$3" # Reading the Third parameter transfileID
PFlag="$4" # Reading the fourth parameter transsetID
. /iib/scripts/CSP/split.cfg
#threshold=6000 # by default assuming the threshold value as 6000
#FName=`basename $MainBaseFile` # getting the exact input file 
#echo "`date`" >> $LOG
#echo "The original input file name is: $MainBaseFile" >> $LOG
#mv $MainBaseFile $MainBaseFile.$3
#echo "`date`" >> $LOG
#BaseFile=$MainBaseFile.$3
du -ch $BaseFile | grep total >> $LOG
echo "Input File: $BaseFile" >> $LOG 
echo "Submitter Ids: $SubId" >> $LOG
echo "TransFileId: $TransFileId" >> $LOG
echo "Priority Flag: $PFlag" >> $LOG
echo "Threshold Value: $threshold" >> $LOG
#sed -i '/^\s*$/d' $BaseFile
INBDIR="/iib/scripts/InitialProcessing/split/files" #input dile directory path
INTDIR="/iib/scripts/InitialProcessing/split/intermediate_files" # intermediate files directory path
mkdir $INTDIR/subid.$3
SUBIDDIR="$INTDIR/subid.$3"
#Destination Directories
EEIDDIR="/eems/iib/CSP/initialprocess/eeid"
SUBBIGDIR="/eems/iib/CSP/inbound/small"
SUBSMALLDIR="/eems/iib/CSP/inbound/small"
PSUBBIGDIR="/eems/iib/CSP/inbound/small"
PSUBSMALLDIR="/eems/iib/CSP/inbound/small"
FFMDIR="/eems/iib/be128/inbound/ffm"
bold=$(tput bold)
# Get the parameters and make sure all the parameters are passed correctly
if [[ $# -ne 4 ]] 
then
	print "Usage: $0  <input file location> <submitter1,transetid1,surviverIndicator1:submitter2,transetid2,surviverIndicator2> <transfileid> <PFlag>"
	exit 10
fi
du -ch $BaseFile | grep total >> $LOG

COUNTBF=`tail -1 $BaseFile | cut -c 2-7` #Trailer count of the input file
REC_BF=`wc -l < $BaseFile` 

REC_BF1=`expr $REC_BF - 2` # Record count of the input file
if [ $COUNTBF -eq $REC_BF1 ] || [ $COUNTBF -eq $REC_BF ]
then
        print "count in the $BaseFile file $COUNTBF and number of records in input file $REC_BF1,$REC_BF  are equal" >> $LOG 
        LINE_BF=`cat $BaseFile | wc -l` # Line count of input file
        LINE1_BF=`expr $LINE_BF - 2` 
        echo $LINE_BF $LINE1_BF >> $LOG
        if [ $COUNTBF -eq $LINE1_BF ] || [ $COUNTBF -eq $LINE_BF ]
        then
                echo "Data is line by line in $BaseFile" >> $LOG
        else
                echo "Data is not in correct format" >> $LOG
        fi 
else
        print "count in the $BaseFile file $COUNTBF and number of records in input file $REC_BF1,$REC_BF are not equal" >> $LOG
        echo $BaseFile >> $LOG
      	exit 9
fi
FileName=`basename $BaseFile` # getting the exact input file 
SubmitterId=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
FileU=`echo $FileName | awk '{split($0,a,"."); print a[2]}'` 
FileDT=`echo $FileName | awk '{split($0,a,"."); print a[3]}'` 
TransFileID=`echo $FileName | awk '{split($0,a,"."); print a[4]}'`
FileFormat=`echo $FileName | awk '{split($0,a,"."); print a[5]}'` 
FName=`echo $SubmitterId.$FileU.$FileDT.$FileFormat`
Actual_Submitterid=`echo $FileName | awk '{split($0,a,"."); print a[1]}'`
echo " The actual file name is $FName " >> $LOG

$Actual_Submitterid  > $INTDIR/file.txt.$3 # Taking the submitter ids from input file
awk 'NF > 0' $INTDIR/file.txt.$3 > $INTDIR/file1.txt.$3 # Submitter ids 
CSub=`cat $INTDIR/file1.txt.$3 | wc -l` #count the number of submitters
echo $SubId > $INTDIR/submitters.txt.$3 # storing the 2nd input parameter submitterid,transsetid,surviver indicator into a file
SubCount1=`grep -o ":" $INTDIR/submitters.txt.$3 | wc -l` # counting the number of submitters from the input parameter
SubCount=`expr $SubCount1 + 1`
for i in {1..$SubCount}
do
	SubmiterId=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f1` # submitter id from input parameter
	SurviverIndicator=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f3` # surviver indicator from input parameter
	CombSubSurInd="$SubmiterId""|""$SurviverIndicator" # surviver indicator and submitter id
	echo "$CombSubSurInd" >> $INTDIR/submitterids.txt.$3 #submitter id and surviver indicator 
	TransSetId=`cut -d ':' -f$i $INTDIR/submitters.txt.$3 | cut -d ',' -f2`	# extracting the transet id from input file
	echo $TransSetId >> $LOG
	echo $TransSetId >> $INTDIR/transsetids.txt.$3
	echo $i is $SubmiterId, $TransSetId >> $LOG
done	

#splitting the files if the file is having lines more than the thrshold value at submitter level
#InputFileName=$BaseFile

Counter1=1
#cd $INBDIR
#ipfilename=`ls -la *.gsf | awk '{print $9}'`
while read line
	do  
	    echo "`date`" >> $LOG
		echo $line >> $LOG 
		s=`echo $line | cut -f1 -d"|"` # submitter id from the file $INTDIR/"submitterids.txt".$3
		SurviverIndicator=`echo $line | cut -f2 -d"|"` --TBD need to take from $2
		echo $s $SurviverIndicator >> $LOG
		TId=`awk NR==$Counter1 $INTDIR/transsetids.txt.$3`
		echo "transset id of $Counter1 is $TId" >> $LOG
		version=`head -1 "$BaseFile" | cut -c 18-22`
		echo $version $s >> $LOG
		versub=`echo $version$s`
		echo $versub >> $LOG
                sed '1d;$d' $BaseFile > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#		grep "$versub" $BaseFile > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#		#grep "$versub" $INBDIR/$FName > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#		#grep -w "\<$versub\>" $INBDIR/$FName > $SUBIDDIR/"$s".$3 # spilitting the file at submitter level
#extracting EEId for version V2.1
#if [ $version = "V1.00" ] || [ $version = "v1.00" ]; then
	echo "Payee SSN for $version and $SurviverIndicator" >> $LOG
	echo "`date`" >> $LOG
#	if [ "$SurviverIndicator" = "Y" ] || [ "$SurviverIndicator" = "y" ]; then
#		echo "surviver indicator is true loop" >> $LOG
	#	cut -c1296-1343 $SUBIDDIR/"$s".$3 | sed "s/[[:blank:]]*$//" > $INBDIR/payeessn.$3
#		cut -c1-9 $SUBIDDIR/"$s".$3 | sed "s/[[:blank:]]*$//" > $INBDIR/employeeid.$3
#		#paste $INBDIR/payeessn.$3 $INBDIR/employeeid.$3 | awk -F '\t' '$1 { print $1 ; next } { print $2 }' > $INBDIR/eeid.$3
#		cat $INBDIR/employeeid.$3 | awk '1 { print $1 ; next } { print $2 }' > $INBDIR/eeid.$3
##		cat $INBDIR/eeid.$3 | sort | uniq > $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName"
#		MemCnt=`cat $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | wc -l`
#		MemberCnt=`echo $s\_$MemCnt`
#		echo member count of EEID:$MemberCnt >> $LOG
##		du -ch $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | grep total >> $LOG
#		echo "EEID completed `date`" >> $LOG
#	elif [ "$SurviverIndicator" = "N" ] || [ "$SurviverIndicator" = "n" ]; then
		echo "Employee ID for $version and $SurviverIndicator" >> $LOG
		cut -c3206-3218 $SUBIDDIR/"$s".$3 | sed "s/[[:blank:]]*$//" | sort | uniq > $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName"
		MemCnt=`cat $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | wc -l`
		MemberCnt=`echo $s\_$MemCnt`
		echo member count of EEID id:$MemberCnt >> $LOG
		du -ch $EEIDDIR/"EEID"_"$TransFileId"_"$TId"_"$s"_"$FName" | grep total >> $LOG
		echo "EEID completed `date`" >> $LOG
#	else 
#		echo "please pass valid suriviver indicator"
#	fi
	echo "`date`" >> $LOG
#fi


#if [ "$version" = "2.10" ]; then
#Splitting the files and sending to inbound 
		Lines1=`tr -d -C "\n" < $SUBIDDIR/"$s".$3 | wc -c`
		echo "lines are total : "$Lines1 >> $LOG
		basefilelines=`tr -d -C "\n" < $BaseFile | wc -c`
		echo $basefilelines >> $LOG
		echo " $BaseFile total lines : $basefilelines" >> $LOG
		if [ "$Lines1" -gt "$threshold" ] 
		then
		#if input files records are more than threshold value then it will enter this loop
			cd $SUBIDDIR
			mkdir split"$s".$3
			chmod 777 split"$s".$3
			split -l $threshold $s.$3 split"$s".$3/ # splittng the files based on the threshold value
			filerc=$?
			if [[ $filerc -eq 0 ]] 
			then
        			echo "split is done `date`" >> $LOG
        		else
		                echo "Error in splitting file" >> $LOG
				exit 2
        		fi
			cd split"$s".$3
			ls -l | awk '{print $9}' | awk 'NF > 0' >> $INTDIR/subsplit$s.txt.$3
			SSN=`cat $INTDIR/subsplit$s.txt.$3 | wc -l` # count of the number of split files
			echo "Splitted no. of files for submitter $s is : $SSN" >> $LOG
			cd $SUBIDDIR/split"$s".$3
			i=1
			MS=1 # member sequence start of the split file
			for file in *
			do
				echo $file >> $LOG
				`cat $file | sed -e "s/.\{15863\}/&|/g" > test.$3`
#				mv $file test.$3
#				cat $file | sed -e "s/.\{5\}/&|/g" > test.$3
                                version="V1.00"
                                echo "$version"
				tr -d '\b\r\n' < test.$3 > ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}
				rm -rf test.$3
				if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ]; then # If it is priority input file move to priority destination directory
					mv ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName} $PSUBSMALLDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp
					echo ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp moved to $PSUBSMALLDIR/ >> $LOG
					du -ch  $PSUBSMALLDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp | grep total >> $LOG
					mv $PSUBSMALLDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $PSUBSMALLDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}
					echo "temp file renamed to actual file name" >> $LOG
					echo "`date`" >> $LOG
				elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
					mv ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName} $FFMDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp
					echo ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp moved to $FFMDIR/ >> $LOG
					du -ch $FFMDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp | grep total >> $LOG
					mv $FFMDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $FFMDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}
					echo "temp file renamed to actual file name" >> $LOG
				echo "`date`" >> $LOG
				elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
					mv ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName} $SUBBIGDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp
					echo ${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp moved to $SUBBIGDIR/ >> $LOG
					du -ch $SUBBIGDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp | grep total >> $LOG
					mv $SUBBIGDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}.temp $SUBBIGDIR/${TransFileId}_${TId}_${s}_${version}_${i}_${SSN}_${MS}_${FName}
					echo "temp file renamed to actual file name" >> $LOG
					echo "`date`" >> $LOG
				else
					echo "please pass the priority flag as Y or N" >> $LOG
				fi
				mss=`expr $i \* $threshold`
				MS=`expr $mss + 1`
				i=`expr $i + 1`
				echo "`date`" >> $LOG
		done
		else
# if total records are less than the thrshold value it will be coming into this loop
			i=1
			MS=1
			SSN=1
			echo "no splitting" >> $LOG
			#sed -i '1d' $BaseFile
			version=`head -1 "$BaseFile" | cut -c 18-22`
			Destfilename=`echo ${TransFileId}"_"${TId}"_"${s}"_"${version}"_"${i}"_"${SSN}"_"${MS}"_"${FName} | tr -d ' '`
			`cat $SUBIDDIR/"$s".$3 | sed -e "s/.\{15863\}/&|/g" > $SUBIDDIR/Pipe_"$s".$3`
			tr -d '\b\r\n' < $SUBIDDIR/Pipe_"$s".$3 > $SUBSMALLDIR/$Destfilename.temp
			echo "non priority moving to inbound directory `date`" >> $LOG
			if [ "$PFlag" = "Y" ] || [ "$PFlag" = "y" ]; then # If it is priority input file move to priority destination directory
				echo "priority moving to inbound psmall directory as .temp" >> $LOG
				mv $SUBSMALLDIR/$Destfilename.temp $PSUBSMALLDIR/$Destfilename.temp
				echo "$SUBSMALLDIR/$Destfilename.temp moved to $PSUBSMALLDIR/$Destfilename.temp" >> $LOG
				du -ch $PSUBSMALLDIR/$Destfilename.temp | grep total >> $LOG
				mv $PSUBSMALLDIR/$Destfilename.temp $PSUBSMALLDIR/$Destfilename
				echo "temp file renamed to actual file name" >> $LOG
				echo "`date`" >> $LOG
			elif [ "$PFlag" = "Z" ] || [ "$PFlag" = "z" ]; then # If it is FFM input file move to FFM destination directory
                echo "FFM moving to inbound FFM directory as .temp" >> $LOG
				mv $SUBSMALLDIR/$Destfilename.temp $FFMDIR/$Destfilename.temp
				echo "$SUBSMALLDIR/$s moved to $FFMDIR/$Destfilename.temp" >> $LOG
				du -ch $FFMDIR/$Destfilename.temp | grep total >> $LOG
				mv $FFMDIR/$Destfilename.temp $FFMDIR/$Destfilename
				echo "temp file renamed to actual file name" >> $LOG
				echo "`date`" >> $LOG
			elif [ "$PFlag" = "N" ] || [ "$PFlag" = "n" ]; then # If it is non priority input file move to non priority destination directory
                echo "already in small directory" >> $LOG
				echo "$SUBIDDIR/$s moved to $SUBSMALLDIR/$Destfilename.temp" >> $LOG
				du -ch $SUBSMALLDIR/$Destfilename.temp | grep total >> $LOG
				mv $SUBSMALLDIR/$Destfilename.temp $SUBSMALLDIR/$Destfilename
				echo "temp file renamed to actual file name" >> $LOG
				echo "`date`" >> $LOG
			else
				echo "please pass the priority flag as Y or N" >> $LOG
			fi
		fi 
		Counter1=`expr $Counter1 + 1`
done < $INTDIR/"submitterids.txt".$3
rm -rf $BaseFile $INBDIR/$INPUTFILE.$3 $INBDIR/$FName $INBDIR/$FName.$3 $SUBIDDIR/Pipe_"$s".$3 $INBDIR/payeessn.$3 $INBDIR/employeeid.$3 $INBDIR/eeid.$3 $INTDIR/file.txt.$3 $INTDIR/file1.txt.$3 $INTDIR/subBigDIRfiles.$3 $INTDIR/submitterids.txt.$3 $INTDIR/submitters.txt.$3 $INTDIR/test.$3 $INTDIR/transsetids.txt.$3 $INTDIR/subsplit$s.txt.$3 $SUBIDDIR/"$s".$3 $SUBIDDIR/split"$s".$3 $INTDIR/subid.$3 $SUBIDDIR
echo "**************************************************************************" >> $LOG
echo "* initProc_Split_workingpflag.sh ended on `date`" >> $LOG
echo "**************************************************************************" >> $LOG
return 1

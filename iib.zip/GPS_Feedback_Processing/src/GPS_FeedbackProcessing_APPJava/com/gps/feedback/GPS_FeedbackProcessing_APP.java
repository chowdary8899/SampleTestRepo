package com.gps.feedback;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import com.be128.globalcache.GlobalCache;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbUserException;
//import common.java.util.CommonUtil;

import java.util.Date;


/*********************************************Modification History*************************************************
*
*	  Date 					Author				Version 	 Description
*	1st March 2017		   Srikanth S			  0.1		 The main functionality of this module  is to Run based on
*															 timer at 6am CST every day and find for ZIP file. If found 
*															 unzip and Archieve the file else send E-mail notification.
*	25th May  2017		   Srikanth Yekollu		  0.2		 Changed the logic to fetch Broker loglevel and log switch values from BRK_CONFIG table
******************************************************************************************************************/
public class GPS_FeedbackProcessing_APP extends MbJavaComputeNode {

	@SuppressWarnings("unchecked")
	// Method to call the oldest file from the Path
	private File getOldestFileFromFiles(File[] fileArray) {
	      
        @SuppressWarnings("rawtypes")
		ArrayList Dl = new ArrayList();
        	for (int i = 0; i < fileArray.length; i++) {
        			if(fileArray[i].isFile()
        						&& fileArray[i].getName().startsWith("GPS2EEMS_EMP_ENR_CHG") 
        						&& fileArray[i].getName().endsWith(".ZIP")
        						&& (fileArray[i].getName().length()==38)){
        				// EGate.collabInfo("File : " + fileArray[i].getName());
        					Dl.add(fileArray[i]);
        				}	
        				}
        		if(Dl.size() == 0){
        				return null;     
        						}
        			File lastModifiedFile = (File)Dl.get(0);
        			for (int i = 1; i < Dl.size(); i++) {
        					if (lastModifiedFile.lastModified() > fileArray[i].lastModified()) {
        							lastModifiedFile = fileArray[i];
        						}
        				}
return lastModifiedFile;
}
	//@SuppressWarnings("unused")
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		
			String inputLocation  =	(String)getUserDefinedAttribute("inputLocation");
			String archiveLocation = (String)getUserDefinedAttribute("archiveLocation");
			String ApplicationName = (String) getUserDefinedAttribute("UDP_ApplicationName"); 
			//String BrkConfigKey = (String) getUserDefinedAttribute("BrkConfigKey"); 
			//String varGCMapName = (String) getUserDefinedAttribute("varGCMapName");
			String SCHEMA_NAME = (String) getUserDefinedAttribute("SCHEMA_NAME");
			String sDSN = (String) getUserDefinedAttribute("DSN");
			String commonMap = (String) getUserDefinedAttribute("commonMap");
			String Brk_LogLevel = "";
			String Brk_LogSwitch = ""; 
			String dbQuery = "";
			String EMAIL_TO = (String) getUserDefinedAttribute("EMAIL_TO");
			String EMAIL_FROM = (String) getUserDefinedAttribute("EMAIL_FROM");
			String EMAIL_CC = (String) getUserDefinedAttribute("EMAIL_CC");
			String SMTPHost = (String) getUserDefinedAttribute("SMTPHost");
			String Region = (String) getUserDefinedAttribute("Region1");
			Date d = new Date(); 
			SimpleDateFormat s= new SimpleDateFormat("yyyyMMddHHmmssSSS");
			String BusProcId = s.format(d); 
		 	MbRoute label = getRoute("AUDIT");   
			Connection conn = null;
			Statement stmt = null;
			ResultSet resultset;
			MbElement globRoot = inAssembly.getGlobalEnvironment().getRootElement();
			MbElement mVar = globRoot.getFirstElementByPath("Variables");
			
			if (mVar == null) {
				mVar = globRoot.createElementAsLastChild(MbElement.TYPE_NAME,"Variables", null);
			}
			MbElement mbAuditData = mVar.createElementAsLastChild(MbElement.TYPE_NAME, "AuditData", "");
		
			//caling common utilities jar to find log level and log switch status, incase of any exception set the values to default.
			try{
				//CommonUtil.readBkrConfigCacheXML(BrkConfigKey,varGCMapName,mbAuditData,SCHEMA_NAME);
				//String Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,getBroker().getName(),mbAuditData);
				//Brk_LogLevel = Brk_LogLevel_LogSwitch.substring(0,Brk_LogLevel_LogSwitch.indexOf(",")-1); 
				//Brk_LogSwitch = Brk_LogLevel_LogSwitch.substring(Brk_LogLevel_LogSwitch.indexOf(",")+1); 
				conn = getJDBCType4Connection(sDSN,JDBC_TransactionType.MB_TRANSACTION_AUTO);
				stmt = conn.createStatement();
				dbQuery = "SELECT LOG_LEVEL,LOG_SWITCH FROM " + SCHEMA_NAME + ".BRK_CONFIG WHERE APP_NM = '" +ApplicationName +"'";
				resultset = stmt.executeQuery(dbQuery);
				if (resultset.next()) {
					Brk_LogLevel = resultset.getString(1);
					Brk_LogSwitch = resultset.getString(2);
				}
			}catch(Exception e){
				 Brk_LogLevel = "DEBUG";
				 Brk_LogSwitch = "ON"; 
				
			}finally{
				
			}
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");
		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		
		DateFormat dateFormat = new SimpleDateFormat("HH:mm");
		dateFormat.setTimeZone(TimeZone.getTimeZone("CST"));
		Calendar cal = Calendar.getInstance();
		
		int Hour = cal.get(Calendar.HOUR_OF_DAY);
		int Minute = cal.get(Calendar.MINUTE);
	     
	//String currenttimestamp = dateFormat.format(cal.getTime());
	 if(Hour == 06 && Minute >=0 && Minute <= 30 ){
		try {
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			SimpleDateFormat sDate= new SimpleDateFormat("yyyyMMdd");
			String key = sDate.format(d);
			String mapContent = null;
			mapContent = GlobalCache.readCache(commonMap,key);
			if (mapContent == null) {
				GlobalCache.insertCache(commonMap, key, "true");
				File currentFileName = null;
				File InboundDir = new File(inputLocation);
		        File[] fileArray = InboundDir.listFiles();
		        currentFileName = getOldestFileFromFiles(fileArray);
		        
		        if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("GPS_FEEDBACK_START","FALSE",
							"Start of GPS Feedback process", inAssembly,mbAuditData, label, "INFO", Brk_LogLevel, ApplicationName,BusProcId);
				} 
		        if(currentFileName == null){
	            	
	              MbElement root = outMessage.getRootElement();
	          	  MbElement SMTPOutput = root.createElementAsLastChild("EmailOutputHeader");
	          	  MbElement localEnv = outAssembly.getLocalEnvironment().getRootElement();
	          	  SMTPOutput.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "To", EMAIL_TO);
	          	  SMTPOutput.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Cc", EMAIL_CC );
	          	  SMTPOutput.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "From", EMAIL_FROM );
	         	  SMTPOutput.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Subject", Region+ " GPS Script FeedBack Error");

	        	  MbElement MIME = root.createElementAsLastChild("MIME");
	        	  MIME.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Content-Type", "multipart/related;boundary=myBoundary");
	        	  MIME.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Content-ID", "new MIME document");
	        	  MbElement parts = MIME.createElementAsLastChild(MbElement.TYPE_NAME, "Parts", null);
	        	  MbElement part, data, blob;
	        	  String text;
 
	        	  MbElement Destination = localEnv.createElementAsLastChild(MbElement.TYPE_NAME, "Destination", null);
	        	  MbElement destinationEmail = Destination.createElementAsLastChild(MbElement.TYPE_NAME, "Email", null);
	        	  destinationEmail.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "SMTPServer", SMTPHost);
	        	  part = parts.createElementAsLastChild(MbElement.TYPE_NAME, "Part", null);
	        	  part.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Content-Type", "text/plain; charset=us-ascii;name=attachment.txt");
	        	  part.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Content-Transfer-Encoding", "8bit");
	        	  data = part.createElementAsLastChild(MbElement.TYPE_NAME, "Data", null);
	        	  blob = data.createElementAsLastChild("BLOB");
	        	  //Calendar localCalendar = Calendar.getInstance(TimeZone.getTimeZone("CST"));
	              //Date currentTimeing = localCalendar.getTime();
	        	  Date Dates =new Date();
	        	  text = "No .ZIP file recieved Today "+Dates+".";
	        	  
	        	  blob.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", text.getBytes("UTF8"));
	        		  
	        	  out.propagate(outAssembly);
	        	  
	        	  if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
	      			AuditLog("GPS_FEEDBACK_NOZIPFILE_END","FALSE","GPS Feedback processing as:"+text,inAssembly, 
	      						mbAuditData, label, "INFO",Brk_LogLevel, ApplicationName, BusProcId);
	        	  }
	            }	
	            	
	            else{
	            	if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog("GPS_FEEDBACK_UNZIP_START","FALSE",
								"GPS Feedback unzip process started", inAssembly,mbAuditData, label, "INFO", Brk_LogLevel, ApplicationName,BusProcId);
					}
	            	String currentFile =currentFileName.getName();
	            	FileInputStream fis = null; 
	            	ZipInputStream zipIs = null;
	            	ZipEntry zEntry = null; 
	            	try { 
		            	fis = new FileInputStream(currentFileName); 
		            	zipIs = new ZipInputStream(new BufferedInputStream(fis)); 
		            	while((zEntry = zipIs.getNextEntry()) != null){ 
		            		try{ 
		            		  byte[] tmp = new byte[4*1024]; 
		            		  FileOutputStream fos = null; 
		            		  String opFilePath = 	inputLocation+"/"+zEntry.getName();		
		            		  fos = new FileOutputStream(opFilePath); int size = 0; 
		            		  while((size = zipIs.read(tmp)) != -1){ 
		            			fos.write(tmp, 0 , size);
		            			} 
		            			fos.flush();
		            			fos.close(); 
		            			} 
		            		catch(Exception ex)
		            			{
		            			 } 
		            	} 
		            	if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
		    				AuditLog("GPS_FEEDBACK_UNZIP_END","FALSE",
		    						"Found Oldest GPS Feedback file has been Unzipped : "+currentFileName, inAssembly,mbAuditData, label, "INFO", Brk_LogLevel, ApplicationName,BusProcId);
		    				}
		            	zipIs.close(); 
	            	} catch (FileNotFoundException e) {
	            			 //  Auto-generated catch block 
	            			 e.printStackTrace(); 
	            			} 
	            //	Path sourceFile = Paths.get(inputLocation+"/"+currentFile);
	            	Path sourceFile = Paths.get(inputLocation+"/"+currentFile);
	                Path targetFile = Paths.get(archiveLocation);
	                Path symLinkPath = Paths.get(targetFile.toRealPath().toString()+"/"+currentFile);
	                Files.move(sourceFile, symLinkPath);
	            }
			}else{
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("GPS_FEEDBACK_DUPLICATE","FALSE",
							"GPS Feedback unzip process started on other broker, so exit from current thread ", inAssembly,mbAuditData, label, "INFO", Brk_LogLevel, ApplicationName,BusProcId);
				} 
				GlobalCache.deleteCache(commonMap, key);
			}
	            
		} catch (MbException e) {
		// Re-throw to allow Broker handling of MbException
		throw e;
		} 
		catch (RuntimeException e) {
		// Re-throw to allow Broker handling of RuntimeException
		throw e;
		} catch (Exception e) {
		// Consider replacing Exception with type(s) thrown by user code
		// Example handling ensures all exceptions are re-thrown to be handled in the flow
		throw new MbUserException(this, "evaluate()", "", "", e.toString(),
			null);
		
	}
	}
	}
	/*********************************************************************************************************************************************
	******************************** local audit method instead of common-framework code**********************************************************	
	**********************************************************************************************************************************************/
		public void AuditLog(String TransactionLevel,String PayloadFlag, String AuditMessage, MbMessageAssembly outAssembly, MbElement mbAuditData,MbRoute labelAudit, 
					String appLogLevel,String Brk_LogLevel,String ApplicationName,String busProcId)throws MbException{
				if (Brk_LogLevel.equalsIgnoreCase("DEBUG")
							|| (Brk_LogLevel.equalsIgnoreCase("ERROR") && appLogLevel.equalsIgnoreCase("ERROR"))
							|| (Brk_LogLevel.equalsIgnoreCase("WARN") && (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR")))
							|| (Brk_LogLevel.equalsIgnoreCase("INFO") && (appLogLevel.equalsIgnoreCase("INFO") || (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR"))))) {
						if (mbAuditData.getFirstElementByPath("TransactionLevel") == null) {
							mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,"loggerAppender", ApplicationName);
							mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"uniqueID", busProcId);
							mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"Payload", PayloadFlag);
							mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"TransactionLevel", TransactionLevel);
							mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AuditMessage", AuditMessage);
							mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AppLogLevel", appLogLevel);
						} else {

							mbAuditData.getFirstElementByPath("TransactionLevel").setValue(TransactionLevel);
							mbAuditData.getFirstElementByPath("Payload").setValue(PayloadFlag);
							mbAuditData.getFirstElementByPath("AuditMessage").setValue(AuditMessage);
							mbAuditData.getFirstElementByPath("AppLogLevel").setValue(appLogLevel) ;
						}
						labelAudit.propagate(outAssembly);
					}
				
		}
	}

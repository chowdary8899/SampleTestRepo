Different GlobalCache Access methods and usage:
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
NOTE: For each Cache_*.xml files, prepend destination system name, EX: for CDB - CDBCache*.xml , GPS - GPSCache*.xml, CSP - GPSCSPCache*.xml, PRIME - PRIMECache*.xml
---------------------------------------------------------------------------------------------------------------------------------------------------------------------

1) To CANCEL current file processing:
	in ..\FrameworkComponents\src\EEMS_GlobalCacheAccess_APP\target checked in the sample input files to be placed. Use "<>Cache_UPDATETAG.xml" file and update the mapname,key  with the current file processing.
	Place the file in the FIleInput node input location: /eems/iib/common/globalcache with proper permission to the file
	GlobalCache for that TransSetId will be set as "FailureStatus = 'Y' which will cause the current processing file to be failed.
	-- When file is in last stage of processing for inbound/source(like only DB load is pending) then please use DELETE functionality with with below details.
		Inbound: Mapname-BE128_Inbound_Map, key-- <TransSetId of the current file in interest>_<brokerName>  
		Source: Mapname-BE128_Source_Map ; key -- <TransSetId of the current file in interest>_<1/2/3/4>_<brokerName>  ; 1-transactional inquiry, 2-source debatcher, 3-source auto-cancel,4source dbload
	{use files : Cache_DELETE.xml, Cache_DELETE_InboundMap.xml, Cache_DELETE_SourceMap.xml }
	Sample Common global-cache xml is :
	Mapname: BE128_Common_Map
	Key: TransfileId_TransSetID
	Value: <CachingLayout><InFileName>TESTHIPPA.U.201606201905.hipaa</InFileName><DestinationSystem>CDB</DestinationSystem><ReceivedTime>2016-06-22T07:47:31.541848-05:00</ReceivedTime><TranSetId>109011</TranSetId><TransFileId>103448</TransFileId><InboundMemberCount>2</InboundMemberCount><SourceFamilyCount></SourceFamilyCount><FailureStatus>N</FailureStatus><SetStatus></SetStatus><SubmitterId>TESTHIPPA</SubmitterId><sbmtGrpNm>HIPPA TESTING</sbmtGrpNm><eligSysCd>8</eligSysCd><SubmitterFileType></SubmitterFileType><AssignedSubmitterName></AssignedSubmitterName><AutoCancelInd>N</AutoCancelInd><SurviverIndicator>N</SurviverIndicator><IsExchange>N</IsExchange><CustomerNumber>0069846</CustomerNumber><PriorityFlag>N</PriorityFlag><ReprIndicator>N</ReprIndicator><BusProcId>20164722074724652488431</BusProcId><RRIndicator></RRIndicator><HipaaHeader>ISA*00*          *00*          *30*720550127      *30*411289245      *160407*0112*!*00501*000000017*1*P*:~GS*BE*DIOBATONROUGE*CES*20160407*0112*1016*X*005010X220A1~ST*834*1016*005010X220A1~BGN*00*Benefit Allocation Systems*20160407*0112*ES***4~REF*38*TESTHIPPA~N1*P5*Roman Catholic Church of the Diocese of Baton Rouge*FI*720550127~N1*IN*UnitedHealth Group*FI*411289245~</HipaaHeader><HipaaTrailer>SE*58*0001~GE*1*1016~IEA*1*000000017~</HipaaTrailer><b2bFlId></b2bFlId><dashBoardXmlFlag>N</dashBoardXmlFlag><asignSbmtCnt>1</asignSbmtCnt><FileType>C</FileType></CachingLayout>
	
	NOTE: If we update the tag FailureStatus = 'Y'-- then file operation is failed. App is created in generic way to update any other tag also with required value if necessary. 
	
2) To READ the cache:
    in ..\FrameworkComponents\src\EEMS_GlobalCacheAccess_APP\target checked in the sample input files to be placed. Use "<>Cache_READ.xml" file and update the mapname,key  with the current file processing.
	Place the file in the FIleInput node input location: /eems/iib/common/globalcache with proper permission to the file
	Global Cache Read status and value will be written to the log file under : /eems/iib/logs/

3) To INSERT/UPDATE cache:
    in ..\FrameworkComponents\src\EEMS_GlobalCacheAccess_APP\target checked in the sample input files to be placed. Use "<>Cache_INSERT.xml" file and update the mapname,key and value with the current file processing.
	Place the file in the FIleInput node input location: /eems/iib/common/globalcache with proper permission to the file
	Global Cache insert status and value will be written to the log file under : /eems/iib/logs/
	
4) To DELETE the cache:
    in ..\FrameworkComponents\src\EEMS_GlobalCacheAccess_APP\target checked in the sample input files to be placed. Use "<>Cache_DELETE.xml" file and update the mapname,key  with the current file processing.
	Place the file in the FIleInput node input location: /eems/iib/common/globalcache with proper permission to the file
	Global Cache delete status will be written to the log file under : /eems/iib/logs/


	
	
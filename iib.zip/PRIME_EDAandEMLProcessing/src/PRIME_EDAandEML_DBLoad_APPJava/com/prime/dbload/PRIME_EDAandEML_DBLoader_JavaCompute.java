package com.prime.dbload;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.be128.globalcache.GlobalCache;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.ibm.broker.plugin.MbNode.JDBC_TransactionType;
import common.java.util.CommonUtil;

/*-------------------------------------------------------
 * Module 	   : PRIME_EDA&EML_DBLoader_JavaCompute

 * Description : This module does following operations:
 1.	Makes connection to database and executes the INSERT queries for batch of members.
 2.	This invokes IsReadyToProcess only when processed EML or EDA load.
 3.  Sets the Required parameters in Environment for Audit Logging and Exception Handling.
 4.	�START� and �END� tags are checked in MQRFH2 header to do Entry and Exit of Status code logging for DBLoader for the currently processing TransSetId. 

 * Modification History:
 * * Date 				Author 			       Version 		    Description
 * 15 july, 2017 	Nirusha Divyakolu		     1.1 			Initial version
 * 
 * ----------------------------------------------------*/

public class PRIME_EDAandEML_DBLoader_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();
		MbElement mEnv = null;
		MbElement root = inMessage.getRootElement();
		//MbElement mbBatchMemQueries = root.getFirstElementByPath("XMLNSC/BatchQueries").getFirstChild();
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);;
		copyMessageHeaders(inMessage, outMessage);
		
		mEnv = inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables");
		if(mEnv == null)
		{
			mEnv = inAssembly.getGlobalEnvironment().getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Variables", null);
		}
		

		MbRoute labelAudit 					= 		getRoute ("AUDIT");     
		String sDSN 						= 		(String)getUserDefinedAttribute("DSN");
		//String udpCmnMapName 				= 		(String)getUserDefinedAttribute("cmnMapName");
		//String udpSrcMapName 				= 		(String)getUserDefinedAttribute("srcMapName");
		//String payload						=  		(String)getUserDefinedAttribute("payload");
		//int dbRetryLimit					=		(int)getUserDefinedAttribute("dbRetryLimit");
		String BrkConfigKey 				= 		(String) getUserDefinedAttribute("BrkConfigKey");
		//String varGCMapName 				= 		(String) getUserDefinedAttribute("varGCMapName");
		String ApplicationName 				= 		(String) getUserDefinedAttribute("ApplicationName");
		String sSchema 						= 		(String) getUserDefinedAttribute("sSchema");
		//boolean BATCH_FAIL_MODE				=		(boolean)getUserDefinedAttribute("BATCH_FAIL_MODE");
		String Brk_LogLevel_LogSwitch 		= 		"";
		String Brk_LogLevel					= 		"";
		String Brk_LogSwitch				= 		"";
		//String brkrList						=		(String)getUserDefinedAttribute("brkrList");
		//int sleepTime 						= 		(int) getUserDefinedAttribute("sleepTime");
		boolean fail = false;
	//	Random randomGenerator = new Random();
	//	int randomInt = randomGenerator.nextInt(100000);

		Connection conn = null;
		Statement stmt = null;
		ResultSet rsx = null;
		
		String transSetId = root.getFirstElementByPath("MQRFH2/usr/TransSetId").getValueAsString();	
		String transFileId = root.getFirstElementByPath("MQRFH2/usr/TransFileId").getValueAsString();	
		String busProcId = root.getFirstElementByPath("MQRFH2/usr/BusProcId").getValueAsString();	
		String eligSysCd = root.getFirstElementByPath("MQRFH2/usr/eligSysCd").getValueAsString();
		String MsgFlag = root.getFirstElementByPath("MQRFH2/usr/MsgFlag").getValueAsString();
		String ActualMemberCount = root.getFirstElementByPath("MQRFH2/usr/ActualMemberCount").getValueAsString();
		String SubmitterId = root.getFirstElementByPath("MQRFH2/usr/SubmitterId").getValueAsString();
		String InFileName = root.getFirstElementByPath("MQRFH2/usr/InputFileNM").getValueAsString();
		String PolicyNum = root.getFirstElementByPath("MQRFH2/usr/PolicyNum").getValueAsString();
		String reprInd = root.getFirstElementByPath("MQRFH2/usr/reprInd").getValueAsString();
	//	String autoCanInd = root.getFirstElementByPath("MQRFH2/usr/AutoCancelIndicator").getFirstChild().getValueAsString();
	//	String FileType = root.getFirstElementByPath("MQRFH2/usr/FileType").getFirstChild().getValueAsString();
	//	String TBAIndicator = root.getFirstElementByPath("MQRFH2/usr/tba_Indicator").getFirstChild().getValueAsString();
	//	String TBA_Done = root.getFirstElementByPath("MQRFH2/usr/TBA_Done").getFirstChild().getValueAsString();
	try{	
		

// Setting Environment Variables for Exception Handler

	/*	MbElement mEnvExc = mEnv.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ExceptionData", null);
		//mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Custnumber", custNum);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BusinessProcessID", busProcId);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TransSetId", transSetId);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TransFileId", transFileId);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "SubmitterId", SubmitterId);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "InFileName", InFileName);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BusProcId", busProcId);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "InboundFilename", InFileName);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "PolicyNum", PolicyNum);
/*
* Setting Environment Variables for Audit Logging */

		MbElement mbAuditData =mEnv.createElementAsLastChild(MbElement.TYPE_NAME, "AuditData", "");
		MbElement envConfig = mEnv.createElementAsLastChild( MbElement.TYPE_NAME, "ConfigCacheXML", null);
		MbElement mbTransSetId = root.getFirstElementByPath("MQRFH2/usr/TransSetId");
		MbElement mbTransFileId = root.getFirstElementByPath("MQRFH2/usr/TransFileId");
		Brk_LogLevel = root.getFirstElementByPath("MQRFH2/usr/Brk_LogLevel").getValueAsString();
		Brk_LogSwitch = root.getFirstElementByPath("MQRFH2/usr/Brk_LogSwitch").getValueAsString();
		
				//Investigate why the headers are not properly populated and fix the issue. Below line is a temporary code fix
		if (Brk_LogLevel == null) {
				Brk_LogLevel = "DEBUG";
		}

		if (Brk_LogSwitch == null) {
				Brk_LogSwitch = "ON";
		}
		//CommonUtil.readBkrConfigCacheXML(BrkConfigKey, varGCMapName, envConfig, sSchema);
	/*	MbElement mVarCacheConfig = envConfig.getFirstElementByPath("XMLNSC/BRK_CONFIG");
		Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,getBroker().getName(), mVarCacheConfig);
		Brk_LogLevel = Brk_LogLevel_LogSwitch.substring(0,Brk_LogLevel_LogSwitch.indexOf(","));
		Brk_LogSwitch = Brk_LogLevel_LogSwitch.substring(Brk_LogLevel_LogSwitch.indexOf(",") + 1);*/
		mEnv.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Brk_LogLevel", Brk_LogLevel);
		mEnv.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Brk_LogSwitch", Brk_LogSwitch); 
/**
* File Proc Status

		ProcFlSts(inAssembly,outAssembly,outMessage,mEnvExc,"START","SRC_DBLOAD");
		
		//AuditLog("FILESTATUSEVENT:START","FALSE", "PROC_FL_STS START for TransSetId:" +transSetId, outAssembly,mbAuditData,labelAudit);
   		
 */  	
/** 
* Database Insertion as Batch
*/ 
		
		boolean batchFailMode = false;
		boolean isRetry = false;  
		//Indices that will hold the insert query index/number for the failed ones incase of a retry 
        ArrayList<Integer> errInsrtQryIndices = new ArrayList<Integer>(); 
		List list1 = null;
		if (root.getFirstElementByPath("XMLNSC") != null) {
			list1 = (List) root.getFirstElementByPath("XMLNSC").evaluateXPath("PrimeBatchQueries");
		}
		
		for (int i = 1; i <= 3; i++) {
			try {
				if (batchFailMode) {
					break;
				}
				conn = getJDBCType4Connection(sDSN,JDBC_TransactionType.MB_TRANSACTION_AUTO);
				//conn.setAutoCommit(false); 
				stmt = conn.createStatement();
				
				int batchQryIdx=0;
				stmt.clearBatch();
				for (int k = 0; k < list1.size(); k++) {
					Boolean isMbrErred=false; 
					MbElement mbBatchMemQueries = (MbElement) list1.get(k);
					List mbTbQueryList = (List) mbBatchMemQueries.evaluateXPath("TableQuery");
					int size = mbTbQueryList.size();
					String strEligSys = "";
					String eligSysTrans = "";
					if (isRetry){
						for(int j = 0; j < size; j++){
							strEligSys = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
							if(strEligSys.contains("ELECELIG.ELIG_SYS_TRANS")){
								eligSysTrans = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
							}
							
							if (errInsrtQryIndices.contains(j+batchQryIdx) && !isMbrErred) {/*
								isMbrErred = true;
								batchFailMode = true;
								String updateEligSys ;
								String insertEligSys;
								String transId = "" ;
								String failedquery = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
								
								AuditLog("FAILED_MEMBER",
										"FALSE",
										"Query failed while Loading to Database for TransSetId = " 
										+ transSetId + " first failed query in this member is : " +failedquery,
										inAssembly, mbAuditData, labelAudit, "ERROR",
										Brk_LogLevel, Brk_LogSwitch, ApplicationName, busProcId);
								
						/*
						 *  Check for ELECELIG.ELIG_SYS_TRANS table, if row already present then make ELIG_TRANS_TYP_CD field to 'R'
						 *  If no row, then insert a row with ELIG_TRANS_TYP_CD field to 'R'
						 *  Two different ways of extraction of transId is followed because quiries generated from transformation flow
						 *  has different scenario's.
						 
								if (!eligSysTrans.equals("")){
									eligSysTrans = eligSysTrans.substring(eligSysTrans.lastIndexOf("(")+1);
									transId = eligSysTrans.substring(0,eligSysTrans.indexOf(","));
									
								}else{
									String firstQuery = ((MbElement) mbTbQueryList.get(0)).getValueAsString();
									firstQuery = firstQuery.substring(firstQuery.lastIndexOf("(")+1);
									transId = firstQuery.substring(firstQuery.indexOf(",")+1).substring(0,firstQuery.substring(firstQuery.indexOf(",")+1).indexOf(","));
								}
								Statement stmt1 = conn.createStatement();
								String sql = "SELECT TRANS_ID FROM ELECELIG.ELIG_SYS_TRANS " 
												+ "WHERE TRANS_ID = "
												+ transId 
												+ " AND TRANS_SET_ID = "
												+ transSetId;
								rsx = stmt1.executeQuery(sql);
								if(rsx.next()){
									updateEligSys = "UPDATE ELECELIG.ELIG_SYS_TRANS "
														+ "SET ELIG_TRANS_TYP_CD = 'S'"
														+ " WHERE TRANS_ID="
														+ transId 
														+ " AND TRANS_SET_ID = "
														+ transSetId;
									stmt.addBatch(updateEligSys);
								}else{
									String SubscriberID = "";
									if (root.getFirstElementByPath("MQRFH2/usr/SubscriberID") != null) {
										SubscriberID = root.getFirstElementByPath("MQRFH2/usr/SubscriberID").getFirstChild().getValueAsString();
									}
									
									insertEligSys = "INSERT INTO ELECELIG.ELIG_SYS_TRANS " 
											+ "(TRANS_ID,TRANS_SET_ID,ELIG_TRANS_TYP_CD,ELIG_SYS_CD,RSN_CD,LST_UPDT_DT,"
											+ "LST_UPDT_ID,STS_CD,TRANS_APPL_DT,PROC_CTL_REC_CNT,PROC_CTL_REC_NBR,SBSCR_ID," 
											+ "SBMT_GRP_NM,TRANS_CREAT_DTTM,AUX_ID)"
											+ " VALUES (" 
											+ transId
											+ ","
											+ transSetId
											+ ","
											+ "'S'"
											+ ",'"
											+ eligSysCd
											+ "',"
											+ "''"
											+ ",'"
											+ getDate()
											+ "','"
											+ busProcId
											+ "',"
											+ "'29'"
											+ ",'"
											+ getDate()
											+ "','"
											+ "0"
											+ "','"
											+ "0"
											+ "','"
											+ SubscriberID
											+ "','"
											+ SubmitterId
											+ "','" 
											+ getDateTime()
											+ "'," 
											+ "'MEMBER_FAIL_SRC'"
											+ ")";
									stmt.addBatch(insertEligSys);
									
								}
						/*
						 *  Check for CSPINBOUND.CSP_MBR table, if row already present then make all the fields to NULL
						 *  If no row, then insert a row with NULL values for all the fields
						 
									
									//stmt1 = conn.createStatement();
							 		sql = "SELECT TRANS_ID FROM CSPSOURCE.CSP_MBR WHERE TRANS_ID = "+ transId + " AND TRANS_SET_ID = "+ transSetId;
							 		rsx = stmt1.executeQuery(sql);
							 		stmt1.clearBatch();
							 		if(rsx.next()){
							 		sql = "UPDATE CSPSOURCE.CSP_MBR SET " 
							 				+"TRANS_TYP = NULL "
							 				+",SBSCR_ID = NULL "
							 				+",ETH_CD = NULL "
							 				+",HIRE_DT = NULL "
							 				+",DTH_DT = NULL "
							 				+",CON_DT = NULL "
							 				+",MBR_FI_IND = NULL "
							 				+",CLM_PAY_MTH = NULL "
							 				+",FND_TNF_IND = NULL "
							 				+",SIG_REC_DT = NULL "
							 				+",CLM_PAY_FSA_MTD = NULL "
							 				+",SFX_CD = NULL "
							 				+",REL_CD = NULL "
							 				+",FST_NM = NULL "
							 				+",LST_NM = NULL "
							 				+",MIDL_NM = NULL "
							 				+",MBR_TIL = NULL "
							 				+",ORG_STRT_DT = NULL "
							 				+",MBR_SSN = NULL "
							 				+",GDR_CD = NULL "
							 				+",BTH_DT = NULL "
							 				+",LANG_CD = NULL "
							 				+",REC_NO = NULL "
							 				+",MRTL_STS_CD = NULL "
							 				+",CAS_NBR = NULL "
							 				+",MDCD_NBR = NULL "
							 				+",GRP_ID = NULL "
							 		 		+"WHERE TRANS_ID = "
							 				+transId 
							 				+" AND TRANS_SET_ID = "
							 				+transSetId;
							 		stmt.addBatch(sql);
							 		
							 		}else{
							 		String MBR_TABLE = "INSERT INTO CSPSOURCE.CSP_MBR (TRANS_ID,TRANS_SET_ID) " +
							 				"VALUES("+Integer.parseInt(transId)+","+Integer.parseInt(transSetId)+")";
							 		stmt.addBatch(MBR_TABLE);
							 		}
							 		
							 		if(stmt1 != null){
										stmt1.close();
									}
							 		if (rsx != null) {
										rsx.close();
									}
									
*/							}
						}
						batchQryIdx = batchQryIdx + (size-1) ;
					}else{
						for (int j = 0; j < size; j++) {
							batchQryIdx++;
							String str = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
							if (str != null)
								stmt.addBatch(((MbElement) mbTbQueryList.get(j)).getValueAsString());
							}
					}
				}

	/*			AuditLog("ADD BATCH","FALSE", "All queries are added to Batch for Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit
						,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
 */
				stmt.executeBatch();
				stmt.clearBatch();
	/*			AuditLog("EXECUTE BATCH:SUCCESS","TRUE", "Batch executed successully for Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit
						,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
				*/break;
			} catch (BatchUpdateException bue) {/*
				int[] counts = bue.getUpdateCounts();
				int len = counts.length;
				//Not needed 
				//batchFailMode = true; 
				//isRetry=true; 
				
					AuditLog("FAILED-MESSAGE-FOR-ALL-TABLES-LOAD",
									"FALSE",
									"Logging the Message for which All Tables Load Failure Occured",
									inAssembly, mbAuditData, labelAudit, "ERROR",
									Brk_LogLevel, Brk_LogSwitch, ApplicationName, busProcId);
					
				mbAuditData.getFirstElementByPath("Payload").setValue("FALSE");

				StringBuffer sbTest = new StringBuffer();
				sbTest.append("[");
				for (int k = 0; k < len; k++) {
					sbTest.append(counts[k]).append(",");
					if(counts[k] == Statement.EXECUTE_FAILED){
                        errInsrtQryIndices.add(k);
                  }

				}
				sbTest.append("]");

				SQLException ex = bue.getNextException();
				StringBuffer sbSpecExp = new StringBuffer();
				int k = 1;
				sbSpecExp.append("[");
				while (ex != null) {
					sbSpecExp.append("Specific SQL exception for Query = " + k
							+ "is as === ");
					sbSpecExp.append(" Message: " + ex.getMessage());
					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
					sbSpecExp.append(" Error code: " + ex.getErrorCode());
					sbSpecExp.append(" || ");
					ex = ex.getNextException();
					k++;
				}
				sbSpecExp.append("]");

				AuditLog("ALL-TABLES-LOAD-FAILURE",
									"TRUE",
									"Error Loading All the tables for the Batch...... Batch Response = "
											+ new String(sbTest)
											+ "...... Specific Exception for Every Insert Query = "
											+ new String(sbSpecExp),
									inAssembly, mbAuditData, labelAudit, "ERROR",
									Brk_LogLevel, Brk_LogSwitch,ApplicationName, busProcId);
					
				
				if(BATCH_FAIL_MODE || /*batchFailMode || (sbSpecExp.indexOf("The batch is terminated non-atomically")>0 && i==3)){
					 batchFailMode = true; 
		
					  GlobalCache.updateCache(udpCmnMapName,transFileId + "_" + transSetId,"FailureStatus=Y;");
					 	
					 throw new MbUserException(
						this.getClass().getName(),"GPSCSP_DBLoad_JavaCompute",
						"","","Message : " + bue.getMessage() + "SQLState : "+ bue.getSQLState(),
						new Object[] {"Error Code : 4090","BATCH_FAIL_MODE is set to TRUE (or) Non-recoverable chain-breaking exception occurred during batch processing. The batch is terminated non-atomically." });
				 }
					
				if(sbSpecExp.indexOf("The batch is terminated non-atomically")>0){
					
						AuditLog("[RETRY]BATCH_TERMINATED_NON_ATOMICALLY_RETRY:"+i,
									"FALSE",
									"The batch is terminated non-atomically, batch will be retried 3 times before failing the message",
									inAssembly, mbAuditData, labelAudit, "ERROR",
									Brk_LogLevel, Brk_LogSwitch,ApplicationName, busProcId);
						try {
							Thread.sleep(sleepTime); // retry after 5 sec
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} 
				}else if(BATCH_FAIL_MODE == false){
					isRetry=true;
						AuditLog("MEMBER_MARK_TO_FAIL",
										"FALSE",
										"The batch failed atomically, so will set ELECELIG.ELIG_SYS_TRANS entry to 'S' and continue processing with next batch/member",
										inAssembly, mbAuditData, labelAudit, "ERROR",
										Brk_LogLevel, Brk_LogSwitch,ApplicationName, busProcId);
						
					
				}
				
			*/} catch (SQLException sqlExcep) {
				/*if(i==dbRetryLimit)
				{
					/*AuditLog("SQL-ERROR","FALSE", "Error in Database connection -- retry limit reached -- so failing message", 
							outAssembly,mbAuditData,labelAudit,"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);	
					throw new MbUserException(this.getClass().getName(), "GPSCSP_DBLoad_JavaCompute", "4016", 
							"Error Description : Error in Database connection: Retry reached", 
							"Message : "+ sqlExcep.getMessage() + "SQLState : "+ sqlExcep.getSQLState(), new Object[]{"4016", "USER Error Code:4016  Error Description:Error in Database connection"});
				}
				AuditLog("DB CONNECTION-FAIL-RETRY","FALSE", "DB Connection failed -- retrying", outAssembly,mbAuditData,labelAudit,
						"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);*/
				
			} finally {
				if(stmt != null){
					stmt.close();
				}

			}
		}
		//
		//create new message as a copy of the input for isReadyTrigger
		MbMessage outMessageIsReady = new MbMessage();
		MbElement outRoot1 = outMessageIsReady.getRootElement();
		copyMessageHeaders(inMessage, outMessageIsReady);
		MbElement xmlnsc = outRoot1.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
		MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "ReadyToProcessRequest", null);
		//rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "reprInd", ReprIndicator);
		rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eligSysCd", eligSysCd);
		rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "reprInd", reprInd);
	    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "event",MsgFlag);
		rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transFileId", transFileId);
		rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transSetId", transSetId);
		rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId", busProcId);
		//rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "FileType", FileType);
		//rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "TBA_Done", TBA_Done);
		//rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "tba_Indicator", TBAIndicator);
		outAssembly = new MbMessageAssembly(inAssembly, outMessageIsReady);
		out.propagate(outAssembly);
		
		
		//

		/* commented this code for implementing Retry logic for batch failure
		
		boolean retryBatch = false;
		List<MbElement> mbTbQueryList = new ArrayList<MbElement>();
		for(int i=1; i <= dbRetryLimit; i++)
		{
			try
			{
				if(retryBatch)
				{
					break;
				}
				conn = getJDBCType4Connection(sDSN, JDBC_TransactionType.MB_TRANSACTION_AUTO);
				stmt = conn.createStatement();
			
				if(mbBatchMemQueries!= null){
					do{
					mbTbQueryList.addAll((List)mbBatchMemQueries.evaluateXPath("TableQuery"));
					mbBatchMemQueries = mbBatchMemQueries.getNextSibling();
					}while(mbBatchMemQueries!= null);
				}
				if(mbTbQueryList.isEmpty()){
					AuditLog("ARRAYLIST-EMPTY","FALSE", "NO Queries in the input message", outAssembly,mbAuditData,labelAudit
							,"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
					retryBatch = true;
					throw new MbUserException(this.getClass().getName(), "GPSCSP_DBLoad_JavaCompute", "", 
							"4014", "", new Object[]{"4014", "USER Error Code:4014  Error Description:No Queries in the input message"});
					
				}else{
					for(int j=0; j<mbTbQueryList.size(); j++)
					{
						stmt.addBatch(((MbElement)mbTbQueryList.get(j)).getValueAsString());
					}			
				
					AuditLog("ADD BATCH","FALSE", "All queries are added to Batch for Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit
							,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
					stmt.executeBatch();
					stmt.clearBatch();
					AuditLog("EXECUTE BATCH:SUCCESS","TRUE", "Batch executed successully for Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit
							,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
			
					break;
				}
			}catch(BatchUpdateException bue)
			{
				
				int[] counts = bue.getUpdateCounts();
				int len = counts.length;
				StringBuffer sbTest = new StringBuffer();
				sbTest.append("[");
				for(int k=0; k<len; k++)
				{
					sbTest.append(counts[k]).append(",");
					
				}
				sbTest.append("]");
				
				SQLException ex = bue.getNextException();
				StringBuffer sbSpecExp = new StringBuffer();
				int k =1;
				sbSpecExp.append("[");
				while (ex != null) 
				{
					sbSpecExp.append("Specific SQL exception for Query = " + k + "is as === " );
					sbSpecExp.append(" Message: " + ex.getMessage());
					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
					sbSpecExp.append(" Error code: " + ex.getErrorCode());
					sbSpecExp.append(" || ");
					ex = ex.getNextException();
					k++;
				}
				sbSpecExp.append("]");
				
				AuditLog("FAILED-BATCH","FALSE", "SQL Query status: "+new String(sbTest) + "Queries : "+mbTbQueryList.toString(), outAssembly,mbAuditData,labelAudit,
						"ERROR",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
				AuditLog("NEXT-EXCEPTION","FALSE", "Specific Exception for Every Insert Query = " +new String(sbSpecExp) , outAssembly,mbAuditData,labelAudit,
						"ERROR",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
				retryBatch = true;
				//AuditLog("BATCH EXECUTION-ERROR","FALSE", "Batch execution failed -- failing message ", outAssembly,mbAuditData,labelAudit);
				
				throw new MbUserException(this.getClass().getName(), "GPSCSP_DBLoad_JavaCompute", "", "4015", 
						"Message : "+ bue.getMessage() + "SQLState : "+ bue.getSQLState() + "Next Exception"+ bue.getNextException(), 
						new Object[]{"4015", "USER Error Code:4015  Error Description:Error in execution of batch"});
				
			}
			catch(SQLException sqlExcep)
			{
				if(i==dbRetryLimit)
				{
					AuditLog("SQL-ERROR","FALSE", "Error in Database connection -- retry limit reached -- so failing message", 
							outAssembly,mbAuditData,labelAudit,"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);		
					throw new MbUserException(this.getClass().getName(), "GPSCSP_DBLoad_JavaCompute", "4016", 
							"Error Description : Error in Database connection: Retry reached", 
							"Message : "+ sqlExcep.getMessage() + "SQLState : "+ sqlExcep.getSQLState(), new Object[]{"4016", "USER Error Code:4016  Error Description:Error in Database connection"});
				}
				AuditLog("DB CONNECTION-FAIL-RETRY","FALSE", "DB Connection failed -- retrying", outAssembly,mbAuditData,labelAudit,
						"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
				
			}catch (MbException e) {
				throw e;
			}finally{
				if(stmt != null){
					stmt.close();
				}
			}
		}
	
	*/
		/**
		 * Increment the processed count and if Source EEID count and actual count matched, then generate trigger for iSReadyToProcess
		 */
	/*synchronized (this){	
		  // boolean updCnt = sourceCntUpdate(udpSrcMapName,transSetId,batchNumber);
		String updCheckisReady = GlobalCache.incrementAndIsReadyCheckSrc(udpSrcMapName,transSetId+"_4_"+getBroker().getName(), batchNumber,brkrList,transInqFlag,FileType,autoCanInd);
		if(updCheckisReady.equalsIgnoreCase("false")){
				String key = transFileId + "_" + transSetId;
				String mapContent = GlobalCache.readCache(udpCmnMapName, key);
				mEnv.createElementAsLastChildFromBitstream(mapContent.getBytes(), MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0);
				
				if(mEnv.getFirstElementByPath("XMLNSC/CachingLayout/FailureStatus").getValueAsString().equalsIgnoreCase("Y")){
					fail = true;
				}else{
					AuditLog("SOURCE CACHE:FAIL","FALSE", "GPSCSP_Source_Map value is null for the transet Id:"+transSetId+" also Global cache status is not in Failure. So failing the message and will set the Global cache Failurestatus to Y", 
							outAssembly,mbAuditData,labelAudit,"ERROR",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
					throw new MbUserException(this.getClass().getName(), "GPSCSP_DBLoad_JavaCompute", "", "4018", "", 
							new Object[]{"4018", "USER Error Code:4018  GPSCSP_Source_Map value is null for the transet Id:"+transSetId+"/ also Global cache status is not in Failure. So failing the message and will set the Global cache Failurestatus to 'Y'"});
				}	
		}else if(updCheckisReady.equalsIgnoreCase("Y")){
			//String getVal =  GlobalCache.readCache(udpSrcMapName,transSetId);
			//mEnv.createElementAsLastChildFromBitstream(getVal.getBytes(), MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0);
			//String srcCnt = mEnv.getFirstElementByPath("XMLNSC/SourceCount/SourceActualCnt").getValueAsString();
			String getVal =  GlobalCache.readCache(udpSrcMapName,transSetId+"_4_"+getBroker().getName());
			String srcCnt = getVal.substring(0,getVal.indexOf(","));
			AuditLog("MATCH COUNT","FALSE", "Source eeid count ( "+srcCnt+" ) is matched with actual count for TransSetId:" +transSetId, 
					outAssembly,mbAuditData,labelAudit,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
			
			//create new message as a copy of the input for isReadyTrigger
			MbMessage outMessageIsReady = new MbMessage();
			MbElement outRoot1 = outMessageIsReady.getRootElement();
			copyMessageHeaders(inMessage, outMessageIsReady);
			MbElement xmlnsc = outRoot1.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "ReadyToProcessRequest", null);
			//rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "reprInd", ReprIndicator);
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eligSysCd", eligSysCd);
			//rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eventData", srcCnt);
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "event", "SRC");
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transFileId", transFileId);
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transSetId", transSetId);
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId", busProcId);
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "FileType", FileType);
			//rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "TBA_Done", TBA_Done);
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "tba_Indicator", TBAIndicator);
			outAssembly = new MbMessageAssembly(inAssembly, outMessageIsReady);
			out.propagate(outAssembly);
			
			AuditLog("ISREADYTRIGGER","TRUE", "Trigger message sent for iSReadyToProcess flow for TranSetId:" +transSetId, 
					outAssembly,mbAuditData,labelAudit,"INFO",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
			ProcFlSts(inAssembly,outAssembly,outMessage,mEnvExc,"START","SRC_READYTOPROC");
		
			AuditLog("FILESTATUSEVENT:ISREADY","FALSE", "PROC_FL_STS ISREADY START for TransSetId:"+transSetId, 
					outAssembly,mbAuditData,labelAudit,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
			
			//boolean delCache   = GlobalCache.deleteCache(udpSrcMapName,transSetId);
			//delCache		   = GlobalCache.deleteCache(udpSrcMapName,transSetId+"_4");
			
			/*Remove the code to delete the source maps here and add in ISready Application */
			/*Remove Source Count Maps  */
			/*
			String[] BrokerName 		= 	brkrList.split("_");
			int cnt						= 	0;
			boolean delCache			=	false;
			while(cnt < BrokerName.length ){
				delCache = GlobalCache.deleteCache(udpSrcMapName,transSetId+"_4_"+BrokerName[cnt]);
					
				//In case of Full file,  auto cancel as Y, then delete Source Profile map 
				if(transInqFlag.equalsIgnoreCase("N")){
					delCache = GlobalCache.deleteCache(udpSrcMapName,transSetId+"_2_"+BrokerName[cnt]);
					
					if(autoCanInd.equalsIgnoreCase("Y") && FileType.equalsIgnoreCase("F")){
						boolean delCach	=	GlobalCache.deleteCache(udpSrcMapName,transSetId+"_3_"+BrokerName[cnt]);
						if(cnt == 0) {delCach = GlobalCache.deleteCache(custProfMapName, transSetId);}
						
						if(delCach){
								AuditLog("PROFILE CACHE:DELETE","FALSE","Profile cache deleted for TransSetId: "+transSetId, 
										outAssembly,mbAuditData,labelAudit,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
							}else{
								AuditLog("PROFILE CACHE:DELETE:FAIL","FALSE","Profile cache deletion failed for TransSetId: "+transSetId, 
										outAssembly,mbAuditData,labelAudit,"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
							}
					}
				}else{
					GlobalCache.deleteCache(udpSrcMapName,transSetId+"_1_"+BrokerName[cnt]);
				}
				cnt = cnt + 1;
			}
			if(delCache){
				AuditLog("DELETE CACHE","FALSE", "Source eeid Count cache deleted for TranSetId:" +transSetId, 
						outAssembly,mbAuditData,labelAudit,"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);							
			}else{
				AuditLog("DELETE CACHE-FAIL","FALSE", "Source eeid Count cache deletion failed for TranSetId:" +transSetId, 
						outAssembly,mbAuditData,labelAudit,"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
			}
			
		}else{
			AuditLog("TOTAL COUNT","FALSE", "Total Processed count in All the brokers -- "+ updCheckisReady +" -- for TransSetId:" +transSetId +" TransFileId:" + transFileId +" Batch Unique Id " + randomInt, 
					outAssembly,mbAuditData,labelAudit,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
				  
				 // boolean matchCnt = GlobalCache.checkSourceCnt(udpSrcMapName,transSetId,transInqFlag,FileType,autoCanInd);
					/*
					String getVal =  GlobalCache.readCache(udpSrcMapName,transSetId);
					AuditLog("COUNT NOT MATCHED IN THIS BATCH","FALSE", "Source eeid count not matched with actual count"+getVal+" for TransSetId:" +transSetId + "Batch Unique Id " + randomInt, 
							outAssembly,mbAuditData,labelAudit);
					*/
				/*
					if(transInqFlag.equalsIgnoreCase("Y")){
						String getVal_traInq =  GlobalCache.readCache(udpSrcMapName,transSetId+"_1");
						//AuditLog("COUNT NOT MATCHED-TRANSACTIONAL INQUIRY COUNT","FALSE", "Transactional Inquiry incremented count"+getVal_traInq+" for TransSetId:" +transSetId + "Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit);
						
						String getVal_dbload =  GlobalCache.readCache(udpSrcMapName,transSetId+"_4");
						AuditLog("TOTAL COUNT","FALSE", "Transactional Inquiry incremented count"+getVal_traInq+"  DB_Load Incremented Count"+getVal_dbload+" for TransSetId:" +transSetId + "Batch Unique Id " + randomInt, 
								outAssembly,mbAuditData,labelAudit);
					}else if (autoCanInd.equalsIgnoreCase("Y") && FileType.equalsIgnoreCase("F")){
						String getVal_autoCancel =  GlobalCache.readCache(udpSrcMapName,transSetId+"_3");
						//AuditLog("COUNT NOT MATCHED-AUTO CANCEL COUNT","FALSE", "Autocancel incremented count"+getVal_autoCancel+" for TransSetId:" +transSetId + "Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit);
						
						String getVal_dbload =  GlobalCache.readCache(udpSrcMapName,transSetId+"_4");
						AuditLog("TOTAL COUNT","FALSE","Autocancel incremented count"+getVal_autoCancel+ "    DB_Load Incremented Count"+getVal_dbload+" for TransSetId:" +transSetId + "Batch Unique Id " + randomInt, 
								outAssembly,mbAuditData,labelAudit);
					}else{
						String getVal_debatch =  GlobalCache.readCache(udpSrcMapName,transSetId+"_2");
						//AuditLog("COUNT NOT MATCHED-DEBATCHER COUNT","FALSE", "Debatcher incremented count"+getVal_debatch+" for TransSetId:" +transSetId + "Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit);
						
						String getVal_dbload =  GlobalCache.readCache(udpSrcMapName,transSetId+"_4");
						AuditLog("TOTAL COUNT","FALSE", "Debatcher incremented count"+getVal_debatch+ "    DB_Load Incremented Count"+getVal_dbload+" for TransSetId:" +transSetId + "Batch Unique Id " + randomInt, 
								outAssembly,mbAuditData,labelAudit);
					}
					
					
				}
			}*/
			
			
/**
* File status End/Fail Event
*/
		/*	if(fail){
				ProcFlSts(inAssembly,outAssembly,outMessage,mEnvExc,"FAIL","SRC_DBLOAD");
				AuditLog("FILESTATUSEVENT:FAIL","FALSE","PROC_FL_STS FAIL for TransSetId:" +transSetId+" as global cache FailureStatus is set to true by another process", outAssembly,mbAuditData,labelAudit
						,"WARN",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
		   		
			}else{
				ProcFlSts(inAssembly,outAssembly,outMessage,mEnvExc,"END","SRC_DBLOAD");
				//AuditLog("FILESTATUSEVENT:END","FALSE","PROC_FL_STS END for TransSetId:" +transSetId, outAssembly,mbAuditData,labelAudit);
				AuditLog("END","FALSE","PROC_FL_STS END event sent ; and END of the DB Loader for Batch Unique Id " + randomInt, outAssembly,mbAuditData,labelAudit
						,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
		   		
			}*/
			
	}catch (MbException e) {
		throw e;
	}catch (Exception e) {
		throw new MbUserException(this, "evaluate()", "", "", e.toString(),null);
	} finally{	
		
	}

		}	
	
/**
* Current date in yyyy-MM-dd HH:mm:ss.SSSSSS format		
*/
	private String getDateTime()
	{
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
		return sdf.format(date);
	}

/**
* Current date in yyyy-MM-dd HH:mm:ss format		
*/
	private String getDate() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		return sdf.format(date);
	}
/*
* AUDIT Logging subflow routing		

	public void AuditLog(String TransactionLevel,String PayloadFlag, String AuditMessage, MbMessageAssembly outAssembly, MbElement mbAuditData,MbRoute labelAudit, 
			String appLogLevel, String Brk_LogLevel,  String Brk_LogSwitch, String ApplicationName,String busProcId)throws MbException{
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			CommonUtil.AuditLog(TransactionLevel,	PayloadFlag,AuditMessage, outAssembly,	mbAuditData, labelAudit, appLogLevel, Brk_LogLevel, ApplicationName,busProcId);
		}
	}
/**
* PROC_FL_STS event routing		
*/
/*	public void ProcFlSts(MbMessageAssembly inAssembly,MbMessageAssembly outAssembly,MbMessage outMessage,MbElement mEnvExc,String activityStatusName,String activityName)throws MbException {
		
		outMessage = null;
		outAssembly = null;
		MbRoute labelSts = getRoute ("STSLABEL");
		outMessage = new MbMessage();
		outAssembly = new MbMessageAssembly(inAssembly,outMessage);	
		MbElement outRoot = outMessage.getRootElement();
		MbElement outBody = outRoot.createElementAsLastChild("XMLNSC");
		   		
		MbElement Event = outBody.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE,"StatusEvent",null);
	  		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "addDtlText", "");
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "submitterID", mEnvExc.getFirstElementByPath("SubmitterId").getValueAsString());
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "cesCustNum", mEnvExc.getFirstElementByPath("Custnumber").getValueAsString());
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "fileName", mEnvExc.getFirstElementByPath("InFileName").getValueAsString());
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "transFileID", mEnvExc.getFirstElementByPath("TransFileId").getValueAsString());
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "transetID", mEnvExc.getFirstElementByPath("TransSetId").getValueAsString());
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "busProcID", mEnvExc.getFirstElementByPath("BusinessProcessID").getValueAsString());
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "activityStatusName", activityStatusName);
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "activityDtTime", getDateTime());
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "activityName", activityName);
	   		Event.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "activityGrpName", "SOURCE_PROCESSING");
	   		
	   		labelSts.propagate(outAssembly);
	}	*/	
	

/**
* Copy Message headers to Output   
*/
		public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
				throws MbException {
			MbElement outRoot = outMessage.getRootElement();
			MbElement header = inMessage.getRootElement().getFirstChild();
			while (header != null && header.getNextSibling() != null) 
			{
				outRoot.addAsLastChild(header.copy());
				header = header.getNextSibling();
			}
		}
	
	
}

package com.gpscsp.inboundProc;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.be128.globalcache.GlobalCache;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.ibm.broker.plugin.MbNode.JDBC_TransactionType;

import common.java.util.CommonUtil;

/*-------------------------------------------------------
 * Module 	   : BE128_Inbound_DBLoader_JavaCompute

 * Description : This module does following operations:
 1.	Makes connection to database and executes the INSERT queries for batch of members.
 2.	This also updates the Global cache with the processed count and invokes IsReadyToProcess only when processed and actual inbound count matches in Global cache Map (BE128_Inbound_Map).
 3.  Sets the Required parameters in Environment for Audit Logging and Exception Handling.
 4.	 START  and  END  tags are checked in MQRFH2 header to do Entry and Exit of Status code logging for DBLoader for the currently processing TransSetId. 

 * Modification History:
 * * Date 				Author 			       Version 		    Description
 * 01 June, 2015 		EEMS Team			     1.1 			Initial version
 * 16 May, 2016			Srikanth Yekollu		 1.2			Added changes related to multiBroker scenario 
 * 16 June,2016			Debajit paul             1.3			Logging Enahancment implemented
 * 16 June, 2016		Srikanth Yekollu		 1.3			Updated Audit log to print the queries and result set in same log
 * 24 April, 2017		Srikanth Yekollu		 1.4			Added code for DB Load retry logic incase of any query loading failed.
 * 																If BATCH_FAIL_MODE is set to TRUE when deployed then whole batch will be failed 
 * 																as like the existing design. If it is set to 'FALSE' then, new code will find
 * 																 which query failed and update the ELIG_SYS_TRANS, MBR tables with pend data.
 * 
 *------------------------------------------------------*/

public class GPSCSP_Inbound_DBLoader_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		String ApplicationName = (String) getUserDefinedAttribute("UDP_ApplicationName");
//		String GlobalCacheInsert_DeleteLater = (String) getUserDefinedAttribute("GlobalCacheInsert_DeleteLater"); // delete
																													// this
																													// line
																													// later,
																													// just
																													// for
																													// testing
																													// purpose
																													// added
		String brkrList = (String) getUserDefinedAttribute("brkrList");
		String inboundMap = (String) getUserDefinedAttribute("InboundMap");
		String sDSN = (String) getUserDefinedAttribute("DSN");
		String commonMap = (String) getUserDefinedAttribute("CommonMap");
		boolean BATCH_FAIL_MODE = (boolean)getUserDefinedAttribute("BATCH_FAIL_MODE");
		int sleepTime = (int) getUserDefinedAttribute("sleepTime");
		String Brk_LogLevel = "";
		String Brk_LogSwitch = "";

		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbElement root = inMessage.getRootElement();

		MbMessageAssembly outAssembly = null;

		MbElement globRoot = inAssembly.getGlobalEnvironment().getRootElement();
		MbElement mVar = globRoot.getFirstElementByPath("Variables");

		if (mVar == null) {
			mVar = globRoot.createElementAsLastChild(MbElement.TYPE_NAME,
					"Variables", null);
		}

		/*
		 * Accessing Main map in Global Cache
		 */
		MbElement mbTransSetId = root.getFirstElementByPath("MQRFH2/usr/TransSetId");
		MbElement mbTransFileId = root.getFirstElementByPath("MQRFH2/usr/TransFileId");
		Brk_LogLevel = root.getFirstElementByPath("MQRFH2/usr/Brk_LogLevel").getValueAsString();
		Brk_LogSwitch = root.getFirstElementByPath("MQRFH2/usr/Brk_LogSwitch").getValueAsString();
		if (mbTransFileId == null) {
			throw new MbUserException(this.getClass().getName(),
					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error : ",
							"No TransFileId in the MQRFH2 header" });
		}

		if (mbTransSetId == null) {
			throw new MbUserException(this.getClass().getName(),
					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error : ",
							"No TransSetId in the MQRFH2 header" });
		}

		String mapContent = GlobalCache.readCache(
				commonMap,
				mbTransFileId.getValueAsString() + "_"
						+ mbTransSetId.getValueAsString());
		mVar.createElementAsLastChildFromBitstream(mapContent.getBytes(),
				MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0);

		/*
		 * if(mVar.getFirstElementByPath("XMLNSC/CachingLayout/FailureStatus").
		 * getValueAsString().equalsIgnoreCase("Y")) { return; }
		 */
/*
		List list1 = null;
		if (root.getFirstElementByPath("XMLNSC") != null) {
			list1 = (List) root.getFirstElementByPath("XMLNSC/BatchQueries")
					.evaluateXPath("BatchMemberQueries");
		}
*/
		MbRoute label1 = getRoute("AUDIT");

		Connection conn = null;
		Statement stmt = null;
		ResultSet rsx = null;
		String custNum = mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/CustomerNumber").getValueAsString();
		if(custNum.length()>=7){
			custNum=custNum.substring(0, 7);
        }else{
        	//do nothing
        }
		
		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/BusProcId") == null) {
			throw new MbUserException(
					this.getClass().getName(),
					"BE128_Inbound_DBLoader_JavaCompute",
					"",
					"",
					"",
					new Object[] {
							"Error : ",
							"No BusProcId in the Global Cache, Expected Structure : CachingLayout/BusProcId" });
		}

		String BusProcId = mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/BusProcId").getValueAsString();
		String InFileName = mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/InFileName").getValueAsString();
		String SubmitterID = mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/SubmitterId")
				.getValueAsString();
		String eligSysCd = mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/eligSysCd").getValueAsString();
		String ReprIndicator = mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/ReprIndicator").getValueAsString();
//		String priorityFlag = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/PriorityFlag").getValueAsString();

		/*
		 * Setting Environment Variables for Audit Logging
		 */
		// MbElement mbAuditData
//		 =mVar.createElementAsLastChild(MbElement.TYPE_NAME, "AuditData", "");
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,
		// "loggerAppender", ApplicationName);
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "uniqueID", BusProcId);
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "Payload", "FALSE");

		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "TransactionLevel", "START-INBOUND_DBLOADER");
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "AuditMessage", "Start of DB Loader Transaction for TransSetId = " +
		// mbTransSetId.getValueAsString()+ " TransFileId  = "+
		// mbTransFileId.getValueAsString());
		// //label1.propagate(inAssembly);

		/* Audit FrameWork Changes -- START */

		MbElement mbAuditData = mVar.createElementAsLastChild(
				MbElement.TYPE_NAME, "AuditData", "");
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,
		// "loggerAppender", ApplicationName);
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "uniqueID", BusProcId);

		/* MbElement mVarAudit =
		 root.getFirstElementByPath("MQRFH2/usr/BrkConfig/XMLNSC/BRK_CONFIG");

		if (mVarAudit != null) {
			Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,
					getBroker().getName(), mVarAudit);
		} else {*/
//			MbElement mVarCache = mVar.createElementAsLastChild(
//					MbElement.TYPE_NAME, "ConfigCacheXML", null);
//			CommonUtil.readBkrConfigCacheXML(BrkConfigKey, varGCMapName,
//					mVarCache, SchemaName);
//			MbElement mVarCacheConfig = mVarCache
//					.getFirstElementByPath("XMLNSC/BRK_CONFIG");
//			Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,
//					getBroker().getName(), mVarCacheConfig);

//		}

//		Brk_LogLevel = Brk_LogLevel_LogSwitch.substring(0,
//				Brk_LogLevel_LogSwitch.indexOf(","));
//		Brk_LogSwitch = Brk_LogLevel_LogSwitch.substring(Brk_LogLevel_LogSwitch
//				.indexOf(",") + 1);

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			CommonUtil.AuditLog(
					"INBOUND_DBLOAD_START",
					"FALSE",
					"Start of DB Loader Transaction for TransSetId = "
							+ mbTransSetId.getValueAsString()
							+ " TransFileId  = "
							+ mbTransFileId.getValueAsString(), inAssembly,
					mbAuditData, label1, "INFO", Brk_LogLevel, ApplicationName,
					BusProcId);
			// label1.propagate(inAssembly);
		}

		/* Audit FrameWork Changes -- END */

		/*
		 * File StatusCode Logging
		 */
		MbElement mbUsr = root.getFirstElementByPath("MQRFH2/usr");
		String sMsgFlag = mbUsr.getFirstElementByPath("MsgFlag").getValueAsString();
		if (mbUsr.getFirstElementByPath("SplitFileNumber") == null) {
			throw new MbUserException(this.getClass().getName(),
					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error Code : 5001",
							"Np MiniSplit file count in MQRFH2 header" });
		}

		if (sMsgFlag.equalsIgnoreCase("START")) {
			Connection connProc = null;
			Statement stmtProc = null;
			for (int i = 1; i <= 3; i++) {
				try {
					connProc = getJDBCType4Connection(sDSN,
							JDBC_TransactionType.MB_TRANSACTION_AUTO);
					stmtProc = connProc.createStatement();
					String time = getDateTime();

					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
							+ "VALUES ('INBOUND_DBLOAD','START','"
							+ time
							+ "',"
							+ BusProcId
							+ ",'INBOUND_PROCESSING','IIB',"
							+ mbTransFileId.getValueAsString()
							+ ","
							+ mbTransSetId.getValueAsString()
							+ ",'','"
							+ InFileName
							+ "','"
							+ custNum
							+ "', '',0,'"
							+ SubmitterID
							+ "','"
							+ time
							+ "','MiniFile_"
							+ mbUsr.getFirstElementByPath("SplitFileNumber")
									.getValueAsString() + "')";
					stmtProc.execute(sql);
					break;
				} catch (SQLException sqlExcep) {
					if (i == 3) {
						/*
						 * mbAuditData.getFirstElementByPath("TransactionLevel").
						 * setValue("SQL-ERROR_PROCFILE");
						 * mbAuditData.getFirstElementByPath
						 * ("AuditMessage").setValue(
						 * "Error Loading database even after re-trying 3 times for PROCFILE_START and SQLMsg = "
						 * + sqlExcep.getMessage() + ", SQLState = " +
						 * sqlExcep.getSQLState() + ", SQLErrorCode = " +
						 * sqlExcep.getErrorCode());
						 * //label1.propagate(inAssembly);
						 */
						if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
							CommonUtil
									.AuditLog(
											"SQL-ERROR_PROCFILE",
											"FALSE",
											"Error Loading database even after re-trying 3 times for PROCFILE_START and SQLMsg = "
													+ sqlExcep.getMessage()
													+ ", SQLState = "
													+ sqlExcep.getSQLState()
													+ ", SQLErrorCode = "
													+ sqlExcep.getErrorCode(),
											inAssembly, mbAuditData, label1,
											"ERROR", Brk_LogLevel,
											ApplicationName, BusProcId);
							// //label1.propagate(inAssembly);
						}
						// GlobalCache.updateCache(commonMap,
						// mbTransFileId.getValueAsString() + "_" +
						// mbTransSetId.getValueAsString(), "FailureStatus=Y");

						// throw new MbUserException(this.getClass().getName(),
						// "BE128_Inbound_DBLoader_JavaCompute", "", "",
						// "Message : "+ sqlExcep.getMessage() + "SQLState : "+
						// sqlExcep.getSQLState(), new
						// Object[]{"Error Code : 5001",
						// "Proc File DB exception, even after 3 retries"});
					}
				} finally {
					try {
						if (stmtProc != null) {
							stmtProc.close();
						}
					} catch (SQLException sqlExcepProcStart) {
						// GlobalCache.updateCache(commonMap,
						// mbTransFileId.getValueAsString() + "_" +
						// mbTransSetId.getValueAsString(), "FailureStatus=Y");
						// throw new MbUserException(this.getClass().getName(),
						// "BE128_Inbound_DBLoader_JavaCompute", "", "",
						// "Message : "+ sqlExcepProcStart.getMessage() +
						// "SQLState : "+ sqlExcepProcStart.getSQLState(), new
						// Object[]{"Error Code : 5001",
						// "Error while closing the statment of ProcFile START event"});
					}
				}
			}
		} else if (sMsgFlag.equalsIgnoreCase("END")) {
			Connection connProc = null;
			Statement stmtProc = null;
			for (int i = 1; i <= 3; i++) {
				try {
					connProc = getJDBCType4Connection(sDSN,
							JDBC_TransactionType.MB_TRANSACTION_AUTO);
					stmtProc = connProc.createStatement();
					String time = getDateTime();
					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
							+ "VALUES ('INBOUND_DBLOAD','END','"
							+ time
							+ "',"
							+ BusProcId
							+ ",'INBOUND_PROCESSING','IIB',"
							+ mbTransFileId.getValueAsString()
							+ ","
							+ mbTransSetId.getValueAsString()
							+ ",'','"
							+ InFileName
							+ "','"
							+ custNum
							+ "', '',0,'"
							+ SubmitterID
							+ "','"
							+ time
							+ "','MiniFile_"
							+ mbUsr.getFirstElementByPath("SplitFileNumber")
									.getValueAsString() + "')";

					stmtProc.execute(sql);
					break;
				} catch (SQLException sqlExcep) {
					if (i == 3) {
					
						if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
							CommonUtil
									.AuditLog(
											"SQL-ERROR_PROCFILE",
											"FALSE",
											"Error Loading database even after re-trying 3 times for PROCFILE_END and SQLMsg = "
													+ sqlExcep.getMessage()
													+ ", SQLState = "
													+ sqlExcep.getSQLState()
													+ ", SQLErrorCode = "
													+ sqlExcep.getErrorCode(),
											inAssembly, mbAuditData, label1,
											"ERROR", Brk_LogLevel,
											ApplicationName, BusProcId);
							// //label1.propagate(inAssembly);
						}

					}
				} finally {
					try {
						if (stmtProc != null) {
							stmtProc.close();
						}
					} catch (SQLException sqlExcepProcEnd) {
						// throw new MbUserException(this.getClass().getName(),
						// "BE128_Inbound_DBLoader_JavaCompute", "", "",
						// "Message : "+ sqlExcepProcEnd.getMessage() +
						// "SQLState : "+ sqlExcepProcEnd.getSQLState(), new
						// Object[]{"Error Code : 5001",
						// "Error while closing the statment of ProcFile END event"});
					}
				}
			}
		
			if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
				CommonUtil
						.AuditLog(
								"END-INBOUND_DBLOADER_TRANSETID",
								"FALSE",
								"End of DBLoad Operation for the entire TranSetId = "
										+ mbTransSetId.getValueAsString()
										+ " with MiniFile = "
										+ mbUsr.getFirstElementByPath(
												"SplitFileNumber")
												.getValueAsString(),
								inAssembly, mbAuditData, label1, "DEBUG",
								Brk_LogLevel, ApplicationName, BusProcId);
				// //label1.propagate(inAssembly);
			}
			return;
		}

	
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			CommonUtil.AuditLog("PRE-DBLOAD", "FALSE",
					"Start of Loading Database for TransSetId = "
							+ mbTransSetId.getValueAsString(), inAssembly, mbAuditData,
					label1, "INFO", Brk_LogLevel, ApplicationName, BusProcId);
			// label1.propagate(inAssembly);
		}

		boolean batchFailMode = false;
		boolean isRetry = false;  
		//Indices that will hold the insert query index/number for the failed ones incase of a retry 
        ArrayList<Integer> errInsrtQryIndices = new ArrayList<Integer>(); 
		List list1 = null;
		if (root.getFirstElementByPath("XMLNSC") != null) {
			list1 = (List) root.getFirstElementByPath("XMLNSC/BatchQueries").evaluateXPath("BatchMemberQueries");
		}
		
		for (int i = 1; i <= 3; i++) {
			try {
				if (batchFailMode) {
					break;
				}
				conn = getJDBCType4Connection(sDSN,JDBC_TransactionType.MB_TRANSACTION_AUTO);
				//conn.setAutoCommit(false); 
				stmt = conn.createStatement();
				
				int batchQryIdx=0;
				stmt.clearBatch();
				for (int k = 0; k < list1.size(); k++) {
					Boolean isMbrErred=false; 
					MbElement mbBatchMemQueries = (MbElement) list1.get(k);
					List mbTbQueryList = (List) mbBatchMemQueries.evaluateXPath("TableQuery");
					int size = mbTbQueryList.size();
					if (isRetry){
						for(int j = 0; j < size; j++){
							if (errInsrtQryIndices.contains(j+batchQryIdx) && !isMbrErred) {
									isMbrErred = true;
									batchFailMode = true;
									String updateEligSys ;
									String insertEligSys;
									String transId = "" ;
									String failedquery = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
									
									if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
										CommonUtil.AuditLog("FAILED_MEMBER", "TRUE",
												"Query failed while Loading to Database for TransSetId = "
														+ mbTransSetId.getValueAsString() + " one of the failed query is : " +failedquery, 
														inAssembly, mbAuditData,
												label1, "ERROR", Brk_LogLevel, ApplicationName, BusProcId);
										// label1.propagate(inAssembly);
									}
									
									/*
									 *  Check for ELECELIG.ELIG_SYS_TRANS table, if row already present then make ELIG_TRANS_TYP_CD field to 'R'
									 *  If no row, then insert a row with ELIG_TRANS_TYP_CD field to 'R'
									 */
									
									String firstQuery = ((MbElement) mbTbQueryList.get(0)).getValueAsString();
									firstQuery = firstQuery.substring(firstQuery.lastIndexOf("(")+1);
									transId = firstQuery.substring(firstQuery.indexOf(",")+1).substring(0,firstQuery.substring(firstQuery.indexOf(",")+1).indexOf(","));
									Statement stmt1 = conn.createStatement();
									String sql = "SELECT TRANS_ID FROM ELECELIG.ELIG_SYS_TRANS " 
													+ "WHERE TRANS_ID = "
													+ transId 
													+ " AND TRANS_SET_ID = "
													+ mbTransSetId.getValueAsString();
									rsx = stmt1.executeQuery(sql);
									if(rsx.next()){
										updateEligSys = "UPDATE ELECELIG.ELIG_SYS_TRANS "
															+ "SET ELIG_TRANS_TYP_CD = 'R'"
															+ " WHERE TRANS_ID="
															+ transId 
															+ " AND TRANS_SET_ID = "
															+ mbTransSetId.getValueAsString();
										stmt.addBatch(updateEligSys);
									}else{
										insertEligSys = "INSERT INTO ELECELIG.ELIG_SYS_TRANS " 
												+ "(TRANS_ID,TRANS_SET_ID,ELIG_TRANS_TYP_CD,ELIG_SYS_CD,RSN_CD,LST_UPDT_DT,"
												+ "LST_UPDT_ID,STS_CD,TRANS_APPL_DT,PROC_CTL_REC_CNT,PROC_CTL_REC_NBR,SBSCR_ID," 
												+ "SBMT_GRP_NM,TRANS_CREAT_DTTM,AUX_ID)"
												+ " VALUES (" 
												+ transId
												+ ","
												+ mbTransSetId.getValueAsString()
												+ ","
												+ "'R'"
												+ ",'"
												+ eligSysCd
												+ "',"
												+ "'FL'"
												+ ",'"
												+ getDate()
												+ "','"
												+ BusProcId
												+ "',"
												+ "'11'"
												+ ",'"
												+ getDate()
												+ "','"
												+ "0"
												+ "','"
												+ "0"
												+ "','"
												+ SubmitterID
												+ "','" 
												+ getDateTime()
												+ "'," 
												+ "'MEMBER_FAIL_INB'"
												+ ")";
										stmt.addBatch(insertEligSys);
										
									}
								
									/*
									 *  Check for CSPINBOUND.CSP_MBR table, if row already present then make all the fields to NULL
									 *  If no row, then insert a row with NULL values for all the fields
									 */
									
							 		sql = "SELECT TRANS_ID FROM CSPINBOUND.CSP_MBR WHERE TRANS_ID = "
							 					+ transId + " AND TRANS_SET_ID = "+ mbTransSetId.getValueAsString();
							 		rsx = stmt1.executeQuery(sql);
							 		stmt1.clearBatch();
							 		
							 		if(rsx.next()){
							 			sql = "UPDATE CSPINBOUND.CSP_MBR SET " 
									 				+"MBR_SSN = NULL "
									 				+", TRANS_TYP = NULL "
									 				/*+", SBSCR_ID = NULL "
									 				+", MDCD_NBR = NULL "*/
									 				+", FST_NM = NULL "
									 				+", LST_NM = NULL "
									 				+", MIDL_NM = NULL "
									 				+", BTH_DT = NULL "
									 				+", DTH_DT = NULL "
									 				+", GDR_CD = NULL "
									 				+", MRTL_STS_CD = NULL "
									 				+", LANG_CD = NULL "
									 				+", RATE_CD = NULL "
									 				+", ETH_CD = NULL "
									 				+", RACE_CD = NULL "
									 				+", SFX_CD = NULL "
									 				+", REL_CD = NULL "
									 				+", MBR_FI_IND = NULL "
									 				+", CONF_CD = NULL "
									 				+", SPL_NED_IND = NULL "
									 				+", HND_BGN_DT = NULL "
									 				+", APL_SGN_DT = NULL "
									 				+", CAS_NBR = NULL "
									 				+", RECERT_DT = NULL "
									 				+", INS_TERM_DT = NULL "
													+", REC_NO = NULL "
													+", MBR_TIL = NULL "
													+", MECR_ID = NULL "
													+", GRP_ID = NULL "
													+", MAIN_TYP_CD = NULL "
													+ "WHERE TRANS_ID = "
									 				+ transId 
									 				+ " AND TRANS_SET_ID = "
									 				+ mbTransSetId.getValueAsString();
								 					
							 			stmt.addBatch(sql);

								 	}else{
							 		String MBR_TABLE = "INSERT INTO CSPINBOUND.CSP_MBR (TRANS_ID,TRANS_SET_ID) " 
							 							+ "VALUES("+Integer.parseInt(transId)
							 							+ ","
							 							+ Integer.parseInt(mbTransSetId.getValueAsString())
							 							+ ")";
							 		stmt.addBatch(MBR_TABLE);
									}
							 		if(stmt1 != null){
										stmt1.close();
									}
							 		if (rsx != null) {
										rsx.close();
									}
							}
						}
						batchQryIdx = batchQryIdx + (size-1) ;
					}else{
						for (int j = 0; j < size; j++) {
							batchQryIdx++;
							String str = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
							if (str != null)
								stmt.addBatch(((MbElement) mbTbQueryList.get(j)).getValueAsString());
							}
					}
				}

				stmt.executeBatch();
				stmt.clearBatch();
				break;
			} catch (BatchUpdateException bue) {
				int[] counts = bue.getUpdateCounts();
				int len = counts.length;
				//Not needed 
				//batchFailMode = true; 
				//isRetry=true; 
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil.AuditLog(
									"FAILED-MESSAGE-FOR-ALL-TABLES-LOAD",
									"FALSE",
									"Logging the Message for which All Tables Load Failure Occured",
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
					
				}
				mbAuditData.getFirstElementByPath("Payload").setValue("FALSE");

				StringBuffer sbTest = new StringBuffer();
				sbTest.append("[");
				for (int k = 0; k < len; k++) {
					sbTest.append(counts[k]).append(",");
					if(counts[k] == Statement.EXECUTE_FAILED){
                        errInsrtQryIndices.add(k);
                  }

				}
				sbTest.append("]");

				SQLException ex = bue.getNextException();
				StringBuffer sbSpecExp = new StringBuffer();
				int k = 1;
				sbSpecExp.append("[");
				while (ex != null) {
					sbSpecExp.append("Specific SQL exception for Query = " + k
							+ "is as === ");
					sbSpecExp.append(" Message: " + ex.getMessage());
					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
					sbSpecExp.append(" Error code: " + ex.getErrorCode());
					sbSpecExp.append(" || ");
					ex = ex.getNextException();
					k++;
				}
				sbSpecExp.append("]");

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil.AuditLog(
									"ALL-TABLES-LOAD-FAILURE",
									"TRUE",
									"Error Loading All the tables for the Batch...... Batch Response = "
											+ new String(sbTest)
											+ "...... Specific Exception for Every Insert Query = "
											+ new String(sbSpecExp),
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
					
				}
				
				if(BATCH_FAIL_MODE || /*batchFailMode ||*/ (sbSpecExp.indexOf("The batch is terminated non-atomically")>0 && i==3)){
					 batchFailMode = true; 
	
					GlobalCache.updateCache(commonMap,mbTransFileId.getValueAsString() + "_" + mbTransSetId.getValueAsString(),
												"FailureStatus=Y;");
					 
					 throw new MbUserException(
						this.getClass().getName(),"GPSCSP_Inbound_DBLoader_JavaCompute",
						"","","Message : " + bue.getMessage() + "SQLState : "+ bue.getSQLState(),
						new Object[] {"Error Code : 2090","BATCH_FAIL_MODE is set to TRUE " +
								"/ Non-recoverable chain-breaking exception occurred during batch processing. The batch is terminated non-atomically." });
				 }
				
				 //if(BATCH_FAIL_MODE || batchFailMode){ // add batchFailMode if requirement is to fail the batch if   second time also batch failure happen in case of non-automicaly faield messages
				if(sbSpecExp.indexOf("The batch is terminated non-atomically")>0){
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						CommonUtil.AuditLog(
										"[RETRY]BATCH_TERMINATED_NON_ATOMICALLY_RETRY:"+i,
										"FALSE",
										"The batch is terminated non-atomically, batch will be retried 3 times before failing the message",
										inAssembly, mbAuditData, label1, "ERROR",
										Brk_LogLevel, ApplicationName, BusProcId);
						
					}
					try {
						Thread.sleep(sleepTime); // retry after 5 sec
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				}else if(BATCH_FAIL_MODE == false){
					isRetry=true;
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						CommonUtil.AuditLog(
										"MEMBER_MARK_TO_FAIL",
										"FALSE",
										"The batch failed atomically, so will set ELECELIG.ELIG_SYS_TRANS entry to 'R' and continue processing with next batch/member",
										inAssembly, mbAuditData, label1, "ERROR",
										Brk_LogLevel, ApplicationName, BusProcId);
						
					}
				}
				
				
				
	
			} catch (SQLException sqlExcep) {
				if (i == 3) {

					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						CommonUtil.AuditLog(
										"SQL-ERROR",
										"FALSE",
										"Error Loading database even after retrying 3 times",
										inAssembly, mbAuditData, label1,
										"ERROR", Brk_LogLevel,ApplicationName,
										BusProcId);
						
					}
					GlobalCache.updateCache(commonMap,
							mbTransFileId.getValueAsString() + "_"
									+ mbTransSetId.getValueAsString(),
							"FailureStatus=N"); 
					throw new MbUserException(
							this.getClass().getName(),
							"GPSCSP_Inbound_DBLoader_JavaCompute",
							"",
							"",
							"Message : " + sqlExcep.getMessage()
									+ "SQLState : " + sqlExcep.getSQLState(),
							new Object[] { "Error Code : 2080",
									"Error Connecting to Database even after 3 re-tries" });
				}
			} finally {
				if(stmt != null){
					try {
						stmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				

			}
		}
		
		
/*		
		boolean retryBatch = false;
		for (int i = 1; i <= 3; i++) {
			try {
				if (retryBatch) {
					break;
				}
				conn = getJDBCType4Connection(sDSN,
						JDBC_TransactionType.MB_TRANSACTION_AUTO);

				stmt = conn.createStatement();

				for (int k = 0; k < list1.size(); k++) {
					MbElement mbBatchMemQueries = (MbElement) list1.get(k);
					List mbTbQueryList = (List) mbBatchMemQueries
							.evaluateXPath("TableQuery");
					for (int j = 0; j < mbTbQueryList.size(); j++) {
						String str = ((MbElement) mbTbQueryList.get(j))
								.getValueAsString();
						if (str != null)
							stmt.addBatch(((MbElement) mbTbQueryList.get(j))
									.getValueAsString());
					}
				}

				stmt.executeBatch();
				stmt.clearBatch();

				break;
			} catch (BatchUpdateException bue) {
				int[] counts = bue.getUpdateCounts();
				int len = counts.length;
				retryBatch = true;

				
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil
							.AuditLog(
									"FAILED-MESSAGE-FOR-ALL-TABLES-LOAD",
									"FALSE",
									"Logging the Message for which All Tables Load Failure Occured for TransSetId = "
									+ mbTransSetId.getValueAsString(),
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
					// label1.propagate(inAssembly);
				}
				mbAuditData.getFirstElementByPath("Payload").setValue("FALSE");

				StringBuffer sbTest = new StringBuffer();
				sbTest.append("[");
				for (int k = 0; k < len; k++) {
					sbTest.append(counts[k]).append(",");
				}
				sbTest.append("]");

				SQLException ex = bue.getNextException();
				StringBuffer sbSpecExp = new StringBuffer();
				int k = 1;
				sbSpecExp.append("[");
				while (ex != null) {
					sbSpecExp.append("Specific SQL exception for Query = " + k
							+ "is as === ");
					sbSpecExp.append(" Message: " + ex.getMessage());
					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
					sbSpecExp.append(" Error code: " + ex.getErrorCode());
					sbSpecExp.append(" || ");
					ex = ex.getNextException();
					k++;
				}
				sbSpecExp.append("]");
			
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil
							.AuditLog(
									"ALL-TABLES-LOAD-FAILURE",
									"TRUE",
									"Error Loading All the tables for the Batch...... Batch Response = "
											+ new String(sbTest)
											+ "...... Specific Exception for Every Insert Query = "
											+ new String(sbSpecExp) 
											+ "for TransSetId = "
											+ mbTransSetId.getValueAsString(),
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
					// label1.propagate(inAssembly);
				}
				GlobalCache.updateCache(
						commonMap,
						mbTransFileId.getValueAsString() + "_"
								+ mbTransSetId.getValueAsString(),
						"FailureStatus=Y;");

				throw new MbUserException(
						this.getClass().getName(),
						"BE128_Inbound_DBLoader_JavaCompute",
						"",
						"",
						"Message : " + bue.getMessage() + "SQLState : "
								+ bue.getSQLState(),
						new Object[] {
								"Error Code : 2080",
								"Could not load all the tables, check the logs for indiviudal query specific exception" });
			} catch (SQLException sqlExcep) {
				if (i == 3) {
					
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						CommonUtil
								.AuditLog(
										"SQL-ERROR",
										"FALSE",
										"Error Loading database even after retrying 3 times for TransSetId = "
										+ mbTransSetId.getValueAsString(),
										inAssembly, mbAuditData, label1,
										"ERROR", Brk_LogLevel, ApplicationName,
										BusProcId);
						// label1.propagate(inAssembly);
					}
					GlobalCache.updateCache(commonMap,
							mbTransFileId.getValueAsString() + "_"
									+ mbTransSetId.getValueAsString(),
							"FailureStatus=Y");
					throw new MbUserException(
							this.getClass().getName(),
							"BE128_Inbound_DBLoader_JavaCompute",
							"",
							"",
							"Message : " + sqlExcep.getMessage()
									+ "SQLState : " + sqlExcep.getSQLState(),
							new Object[] { "Error Code : 2080",
									"Error Connecting to Database even after 3 re-tries" });
				}
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
				} catch (SQLException sqlExcepBatStmt) {
					GlobalCache.updateCache(commonMap,
							mbTransFileId.getValueAsString() + "_"
									+ mbTransSetId.getValueAsString(),
							"FailureStatus=Y");
					throw new MbUserException(this.getClass().getName(),
							"BE128_Inbound_DBLoader_JavaCompute", "", "",
							"Message : " + sqlExcepBatStmt.getMessage()
									+ "SQLState : "
									+ sqlExcepBatStmt.getSQLState(),
							new Object[] { "Error Code : 2081",
									"Error while closing the Batch statement" });
				}

			}
		}
		
		*/
		/*
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "POST-DBLOAD");
		 * mbAuditData.getFirstElementByPath("AuditMessage").setValue
		 * ("End of Loading Database"); //label1.propagate(inAssembly);
		 */
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			CommonUtil.AuditLog("POST-DBLOAD", "FALSE",
					"End of Loading Database for TransSetId = "
							+ mbTransSetId.getValueAsString(), inAssembly, mbAuditData, label1,
					"DEBUG", Brk_LogLevel, ApplicationName, BusProcId);
			// label1.propagate(inAssembly);
		}
		/*
		 * 1. Update Processed count in Global cache's inbound map 2. Once the
		 * processed and actual counts are equal, then create XML for
		 * IsReadyToProcess
		 */

		/*
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "PRE-PROCESSEDCHECKCOUNT");
		 * mbAuditData.getFirstElementByPath("AuditMessage"
		 * ).setValue("Start of Checking processed count against the actual inbound"
		 * ); //label1.propagate(inAssembly);
		 */
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			CommonUtil
					.AuditLog(
							"PRE-PROCESSEDCHECKCOUNT",
							"FALSE",
							"Start of Checking processed count against the actual inbound for TransSetId = "
							+ mbTransSetId.getValueAsString(),
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);
			// label1.propagate(inAssembly);
		}
		int MemCnt = Integer.parseInt(mbUsr
				.getFirstElementByPath("MemberCount").getValueAsString());
		// int ActualMemberCount =
		// Integer.parseInt(mbUsr.getFirstElementByPath("ActualMemberCount").getValueAsString());

		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/InboundMemberCount") == null) {
			throw new MbUserException(this.getClass().getName(),
					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error Code : 2010",
							"No InboundMemberCount in the Global Cache" });
		}

		int InboundMemberCount = Integer.parseInt(mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/InboundMemberCount").getValueAsString());

		synchronized (this) {

			/* MultiBroker changes -- START */
			String updCheckisReady = GlobalCache.incrementAndIsReadyCheckInb(
					inboundMap, mbTransSetId.getValueAsString() + "_"
							+ getBroker().getName(), String.valueOf(MemCnt),
					brkrList);
			/*
			 * String sAct_Proc_Inb_Cnt = GlobalCache.readCache(inboundMap,
			 * mbTransSetId.getValueAsString()); if(sAct_Proc_Inb_Cnt == null) {
			 * sAct_Proc_Inb_Cnt = Integer.toString(InboundMemberCount)+ "," +
			 * "0"; } int actCnt =
			 * Integer.parseInt(sAct_Proc_Inb_Cnt.substring(0,
			 * sAct_Proc_Inb_Cnt.indexOf(","))); int procCnt =
			 * Integer.parseInt(sAct_Proc_Inb_Cnt
			 * .substring(sAct_Proc_Inb_Cnt.indexOf(",") + 1));
			 * 
			 * procCnt = procCnt + MemCnt;
			 */
			if (updCheckisReady.equalsIgnoreCase("false")) {

				/*
				 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue
				 * ("INBOUND-COUNT:UPDATE:FAIL");
				 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
				 * "Update inbound count utility failed for transSetId = " +
				 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
				 * mbTransFileId.getValueAsString());
				 * //label1.propagate(inAssembly);
				 */
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil.AuditLog(
							"INBOUND-COUNT:UPDATE:FAIL",
							"FALSE",
							"Update inbound count utility failed for transSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "ERROR",
							Brk_LogLevel, ApplicationName, BusProcId);
					// label1.propagate(inAssembly);
				}

				if (mVar.getFirstElementByPath(
						"XMLNSC/CachingLayout/FailureStatus")
						.getValueAsString().equalsIgnoreCase("Y")) {
					/*
					 * mbAuditData.getFirstElementByPath("TransactionLevel").
					 * setValue("COMMON GLOBAL CACHE STATUS:FAIL");
					 * mbAuditData.getFirstElementByPath
					 * ("AuditMessage").setValue
					 * ("Global cache is in failure status for transSetId = " +
					 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
					 * mbTransFileId.getValueAsString());
					 * //label1.propagate(inAssembly);
					 */
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						CommonUtil.AuditLog(
								"COMMON GLOBAL CACHE STATUS:FAIL",
								"FALSE",
								"Global cache is in failure status for transSetId = "
										+ mbTransSetId.getValueAsString()
										+ " TransFileId  = "
										+ mbTransFileId.getValueAsString(),
								inAssembly, mbAuditData, label1, "ERROR",
								Brk_LogLevel, ApplicationName, BusProcId);
						// label1.propagate(inAssembly);
					}
				} else {
					throw new MbUserException(
							this.getClass().getName(),
							"BE128_Inbound_DBLoader_JavaCompute",
							"",
							"2011",
							"",
							new Object[] {
									"2011",
									"USER Error Code:2011  Error Description:BE128_Inbound_Map value is null for the transet Id:"
											+ mbTransSetId.getValueAsString()
											+ "/ also Global cache status is not in Failure. So failing the message and will set the Global cache Failurestatus to Y" });
				}

			} else if (updCheckisReady.equalsIgnoreCase("Y")) {
				/*
				 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue
				 * ("IN-PROCESSEDCHECKCOUNT");
				 * mbAuditData.getFirstElementByPath(
				 * "AuditMessage").setValue("Processed and Actual count (" +
				 * InboundMemberCount +" )matches for TransSetId = " +
				 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
				 * mbTransFileId.getValueAsString());
				 * //label1.propagate(inAssembly);
				 */
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil.AuditLog(
							"IN-PROCESSEDCHECKCOUNT",
							"FALSE",
							"Processed and Actual count (" + InboundMemberCount
									+ " )matches for TransSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);
					// label1.propagate(inAssembly);
				}
				// create new message as a copy of the input
				MbMessage outMessage = new MbMessage();
				MbElement outRoot = outMessage.getRootElement();
				MbElement mqmd = outRoot.createElementAsFirstChild("MQMD");
				// Prioritizing for FFM files
//				if (priorityFlag.equals("Z")) {
//					mqmd.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE,
//							"Priority", 9);
//				}
				MbElement xmlnsc = outRoot
						.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				MbElement rootEle = xmlnsc.createElementAsLastChild(
						MbElement.TYPE_NAME, "ReadyToProcessRequest", null);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
						"BusProcId", BusProcId);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
						"transFileId", mbTransFileId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
						"transSetId", mbTransSetId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "event",
						"INB");
				// rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
				// "eventData", procCnt);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
						"eventData", InboundMemberCount);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
						"eligSysCd", eligSysCd);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "reprInd",
						ReprIndicator);

				outAssembly = new MbMessageAssembly(inAssembly, outMessage);
				out.propagate(outAssembly);
				outMessage.clearMessage();
				/*
				 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue
				 * ("IS_READY_TO_PROCESS_TRIGGER");
				 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
				 * "IsReadyToProcess is triggered for TransSetId = " +
				 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
				 * mbTransFileId.getValueAsString());
				 * //label1.propagate(inAssembly);
				 */
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil.AuditLog(
							"IS_READY_TO_PROCESS_TRIGGER",
							"FALSE",
							"IsReadyToProcess is triggered for TransSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "INFO",
							Brk_LogLevel, ApplicationName, BusProcId);
					// label1.propagate(inAssembly);
				}
				// GlobalCache.insertCache(inboundMap,
				// mbTransSetId.getValueAsString(), Integer.toString(actCnt)+
				// "," + Integer.toString(procCnt));

			} else {
				/*
				 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue
				 * ("IN-PROCESSEDCHECKCOUNT");
				 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
				 * "Processed and Actual count does not match yet for TransSetId = "
				 * + mbTransSetId.getValueAsString()+ " TransFileId  = "+
				 * mbTransFileId.getValueAsString() +
				 * ", with current counts in all the Brokers as (ActualCount,Processed Count) = ("
				 * + updCheckisReady +")"); //label1.propagate(inAssembly);
				 */
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					CommonUtil
							.AuditLog(
									"IN-PROCESSEDCHECKCOUNT",
									"FALSE",
									"Processed and Actual count does not match yet for TransSetId = "
											+ mbTransSetId.getValueAsString()
											+ " TransFileId  = "
											+ mbTransFileId.getValueAsString()
											+ ", with current counts in all the Brokers as (ActualCount,Processed Count) = ("
											+ updCheckisReady + ")",
									inAssembly, mbAuditData, label1, "INFO",
									Brk_LogLevel, ApplicationName, BusProcId);
					// label1.propagate(inAssembly);
				}
			}

			/* MultiBroker changes -- END */
			/*
			 * if(procCnt != actCnt) { GlobalCache.insertCache(inboundMap,
			 * mbTransSetId.getValueAsString(), Integer.toString(actCnt)+ "," +
			 * Integer.toString(procCnt));
			 * 
			 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
			 * "IN-PROCESSEDCHECKCOUNT");
			 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
			 * "Processed and Actual count does not matche for TransSetId = " +
			 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
			 * mbTransFileId.getValueAsString() +
			 * ", with current counts as (ActualCount,Processed Count) = (" +
			 * Integer.toString(actCnt) + ", " + Integer.toString(procCnt) +
			 * ")"); //label1.propagate(inAssembly); } else {
			 * mbAuditData.getFirstElementByPath
			 * ("TransactionLevel").setValue("IN-PROCESSEDCHECKCOUNT");
			 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
			 * "Processed and Actual count matches for TransSetId = " +
			 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
			 * mbTransFileId.getValueAsString() +
			 * ", with current counts as (ActualCount,Processed Count) = (" +
			 * Integer.toString(actCnt) + ", " + Integer.toString(procCnt) +
			 * ")"); //label1.propagate(inAssembly);
			 * 
			 * //create new message as a copy of the input MbMessage outMessage
			 * = new MbMessage(); MbElement outRoot =
			 * outMessage.getRootElement(); MbElement mqmd =
			 * outRoot.createElementAsFirstChild("MQMD"); //Prioritizing for FFM
			 * files if ( priorityFlag.equals("Z")){
			 * mqmd.createElementAsFirstChild
			 * (MbElement.TYPE_NAME_VALUE,"Priority",9); } MbElement xmlnsc =
			 * outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME); MbElement
			 * rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME,
			 * "ReadyToProcessRequest", null);
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId",
			 * BusProcId);
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId"
			 * ,mbTransFileId.getValueAsString());
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
			 * "transSetId", mbTransSetId.getValueAsString());
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "event",
			 * "INB"); rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
			 * "eventData", procCnt);
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eligSysCd",
			 * eligSysCd); rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
			 * "reprInd", ReprIndicator);
			 * 
			 * outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			 * out.propagate(outAssembly); outMessage.clearMessage();
			 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
			 * "IS_READY_TO_PROCESS_TRIGGER");
			 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
			 * "IsReadyToProcess is triggered for TransSetId = " +
			 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
			 * mbTransFileId.getValueAsString());
			 * //label1.propagate(inAssembly);
			 * 
			 * GlobalCache.insertCache(inboundMap,
			 * mbTransSetId.getValueAsString(), Integer.toString(actCnt)+ "," +
			 * Integer.toString(procCnt)); }
			 */
		}

		/*
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "POST-PROCESSEDCHECKCOUNT");
		 * mbAuditData.getFirstElementByPath("AuditMessage"
		 * ).setValue("End of Checking processed count against the actual inbound"
		 * ); //label1.propagate(inAssembly);
		 * 
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "END-INBOUND_DBLOADER");
		 * mbAuditData.getFirstElementByPath("AuditMessage"
		 * ).setValue("End of DB Loader Transaction for TransSetId = " +
		 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
		 * mbTransFileId.getValueAsString()); //label1.propagate(inAssembly);
		 */
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			CommonUtil
					.AuditLog(
							"POST-PROCESSEDCHECKCOUNT",
							"FALSE",
							"End of Checking processed count against the actual inbound for TransSetId = "
							+ mbTransSetId.getValueAsString(),
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);
			// label1.propagate(inAssembly);
			CommonUtil.AuditLog(
					"END-INBOUND_DBLOADER",
					"FALSE",
					"End of DB Loader Transaction for TransSetId = "
							+ mbTransSetId.getValueAsString()
							+ " TransFileId  = "
							+ mbTransFileId.getValueAsString(), inAssembly,
					mbAuditData, label1, "INFO", Brk_LogLevel, ApplicationName,
					BusProcId);
			// label1.propagate(inAssembly);
		}
		//alt.propagate(inAssembly);  /* commented by Srikanth Y as no propagation to Alt terminal is required here. */
	}

	private String getDateTime() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss.SSSSSS");
		return sdf.format(date);
	}
	
	private String getDate() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		return sdf.format(date);
	}

}

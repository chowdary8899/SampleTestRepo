package com.gpscsp.inboundProc;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

public class QueueDepth 
{
	public static synchronized String getLimitValue(String qMgrStr,String qName, String noOfThreads, String threshQueueDepth) //throws MbException 
	{
		
		MQQueueManager qMgr = null;
		boolean mqConn 	= false;
		int threadCnt = Integer.parseInt(noOfThreads);
		int threshQDptCnt = Integer.parseInt(threshQueueDepth);
		int mqRetryLimit = 3;
		for (int noOfRetry=0;noOfRetry<=mqRetryLimit;noOfRetry++){
 		   	try{
 		   		if(!mqConn){
     				qMgr = new MQQueueManager(qMgrStr);
     				mqConn = true;
     				break;
     			}
 		   	}catch (MQException e){
 		   		if (noOfRetry == mqRetryLimit){
 		   			return "NoQMConn";
 		   		    //throw new MbUserException("QueueDepth", "BE128_SP_FullMbrShpInq_Debatcher_ReadZipPropagate", "", "4039",
						//"", new Object[]{"4039", "USER Error Code:4039  Error Description:Error in MQ Connection"});
 		   		}
     		   	
 		   	}
		}
		
		int currDepth 			=		0;
		int limitMessage  		= 		0;
		int allowedDepth		=		0;
		MQQueue m_receiver		=		null;
		int qOptions 			= 		MQC.MQOO_INQUIRE + MQC.MQOO_FAIL_IF_QUIESCING + MQC.MQOO_INPUT_SHARED;
		try
		{
			m_receiver 			= 		qMgr.accessQueue(qName, qOptions);
			currDepth			=		m_receiver.getCurrentDepth();
			if(currDepth<threshQDptCnt)
			{
				allowedDepth	=		(threshQDptCnt - currDepth);
				if(allowedDepth > (threadCnt))
				{    
				   limitMessage = 	(threshQDptCnt - currDepth)/threadCnt;
				}
				else
				{
				   limitMessage = allowedDepth;
				}
			}
			else
			{
				limitMessage	=		0;
			}
			
			m_receiver.close();
		}
		catch(Exception e)
		{
			return "NoQConn";
			//throw new MbUserException(QueueDepth.class, "evaluate()", "", "", e.toString(),null);
		}
		return Integer.toString(limitMessage);
	}

	/* Threshold limit  implementation for MQ message posting -- start */
	public static String getDBLoadLimitValue(String qMngr,String qName, String threshQueueDepth, String udpRetryLimit)
	{
	int currDepth 			=		0;
	int allowedDepth		=		0;
	int threshold           = 		Integer.parseInt(threshQueueDepth) ;
	MQQueue m_receiver		=		null;
	
	int qOptions 			= 		MQC.MQOO_INQUIRE + MQC.MQOO_FAIL_IF_QUIESCING + MQC.MQOO_INPUT_SHARED;
	 for (int noOfRetry=0;noOfRetry<=Integer.parseInt(udpRetryLimit);noOfRetry++){
			try{
				MQQueueManager qMgr = new MQQueueManager(qMngr) ;
				m_receiver 			= 		qMgr.accessQueue(qName, qOptions);
				currDepth			=		m_receiver.getCurrentDepth();
				if(currDepth<threshold){
					allowedDepth	=		(threshold - currDepth);
				}else{
					allowedDepth	=		0;
				}
				m_receiver.close();
				break;
				}catch(MQException e){
					if (noOfRetry == Integer.parseInt(udpRetryLimit)){
						return "-1" ;
					}
				}
	 }
	 return String.valueOf(allowedDepth);
	}

/* Threshold limit  implementation for MQ message posting -- end */
	
	/*Thread sleep call - start*/
	public static String threadSleep(String sleepTime)
	{
		try {
			Thread.sleep(Integer.parseInt(sleepTime));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "true";
	}
	/*Thread sleep call - end*/
}

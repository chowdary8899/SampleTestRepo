package com.eems.be128.exchangefileproc;


public class BE128_ExchangeFileProc_JavaCompute {
	
public static String iibDashboardReport(String iib_Dashboard_Report,String B2BFileID,String fileReportPropFile,String reportFileName,
		String reportOutFileDir, String IIBENV, String timeoutInSeconds ) {
	int value = 0;
	try {
	ProcessBuilder pb = new ProcessBuilder(iib_Dashboard_Report,B2BFileID,fileReportPropFile,reportFileName,reportOutFileDir,IIBENV);
	Process p = pb.start();
    
	if ( Integer.parseInt(timeoutInSeconds) < 0 ){
		value 	  = p.waitFor();
	}
	else{
		long now = System.currentTimeMillis();
	    long timeoutInMillis = 1000L * Integer.parseInt(timeoutInSeconds);
	    long finish = now + timeoutInMillis;
	    while ( isAlive( p ) && ( System.currentTimeMillis() < finish ) )
	    {
	        Thread.sleep( 10 );
	    }
	    if ( isAlive( p ) )
	    {
	       throw new InterruptedException( "Process timeout out after " + timeoutInSeconds + " seconds" );
	    }
	    value = p.exitValue();
	}
	} catch (Exception e) {
    	e.printStackTrace();
  		value = 2;
	}
	return String.valueOf(value);
}

public static boolean isAlive( Process p ) {
    try
    {
        p.exitValue();
        return false;
    } catch (IllegalThreadStateException e) {
        return true;
    }
}

/*Method to get the modified Time stamp of a file*/	

public static String getTime() {
	return ""+System.currentTimeMillis();
	
}


}
package com.gpscsp.cob;


public class GPSCSP_FILE_To_COB_MF_JavaCompute {

/* Method to call the iib_to_csp_COBFile_xfer.sh script  */
    public static String iibcspCOBFile1(String iib_to_csp_COBFile_xfer, String timeoutInSeconds ) {
	int value = 0;
	try {
	ProcessBuilder pb = new ProcessBuilder(iib_to_csp_COBFile_xfer);
	Process p = pb.start();
    
	if ( Integer.parseInt(timeoutInSeconds) < 0 ){
		value 	  = p.waitFor();
	}
	else{
		long now = System.currentTimeMillis();
	    long timeoutInMillis = 1000L * Integer.parseInt(timeoutInSeconds);
	    long finish = now + timeoutInMillis;
	    while ( isAlive( p ) && ( System.currentTimeMillis() < finish ) )
	    {
	        Thread.sleep( 10 );
	    }
	    if ( isAlive( p ) )
	    {
	       throw new InterruptedException( "Process timeout out after " + timeoutInSeconds + " seconds" );
	    }
	    value = p.exitValue();
	}
	} catch (Exception e) {
    	e.printStackTrace();
  		value = 2;
	}
	return String.valueOf(value);
}

public static boolean isAlive( Process p ) {
    try
    {
        p.exitValue();
        return false;
    } catch (IllegalThreadStateException e) {
        return true;
    }
}
}

	

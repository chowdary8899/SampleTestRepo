package com.eems.inflightapp;

import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;

public class InflighPriority_QueueBrowser {

	
	/* Method to get the current queue depth */
	public static String queueDepth(String qMngr, String qName) {
		int currDepth = 0;
		MQQueue m_receiver = null;
		int qOptions = CMQC.MQOO_INQUIRE + CMQC.MQOO_FAIL_IF_QUIESCING	+ CMQC.MQOO_INPUT_SHARED;
		int RetryLimit = 3;

		for (int noOfRetry = 0; noOfRetry <= RetryLimit; noOfRetry++) {
			try {
				MQQueueManager qMgr = new MQQueueManager(qMngr);
				m_receiver = qMgr.accessQueue(qName, qOptions);
				currDepth = m_receiver.getCurrentDepth();
				m_receiver.close();
				qMgr.close();
				break;
			} catch (Exception e) {
				if (noOfRetry == RetryLimit) {
					currDepth = 0;
				}
			}
		}
		return String.valueOf(currDepth);
	}

	/* Method to get the modified Time stamp of a file */

	public static String getTime() {
		return "" + System.currentTimeMillis();

	}
}

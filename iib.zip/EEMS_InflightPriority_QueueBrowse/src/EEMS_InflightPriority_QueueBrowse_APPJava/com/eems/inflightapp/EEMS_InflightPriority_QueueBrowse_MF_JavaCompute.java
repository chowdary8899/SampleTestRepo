package com.eems.inflightapp;

import com.be128.globalcache.GlobalCache;
import common.java.util.CommonUtil;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbXMLNSC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;

public class EEMS_InflightPriority_QueueBrowse_MF_JavaCompute extends
MbJavaComputeNode {
	@Override
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		
		String ApplicationName 	= (String) getUserDefinedAttribute("ApplicationName");
		String BrkConfigKey 	= (String) getUserDefinedAttribute("BrkConfigKey");
		String varGCMapName 	= (String) getUserDefinedAttribute("varGCMapName");
		String PriorityMap 		= (String) getUserDefinedAttribute("PriorityMap");
		String PriorityKey 		= (String) getUserDefinedAttribute("PriorityKey");
		MbOutputTerminal out 	= getOutputTerminal("out");
		String Brk_LogLevel 	= "";
		String Brk_LogSwitch 	= "";
		long sTm 				= System.currentTimeMillis();
		long eTm, totalTm 		= 0;
		String mapContent 		= null;
		String TransFileId 		= null;
		String TransSetId 		= null;
		MbRoute labelAudit 		= getRoute("AUDIT");

		MbElement env = inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables");

		if (env == null) {
			env = inAssembly.getGlobalEnvironment().getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Variables",	null);
		}
		MbElement envAudt = env.createElementAsLastChild(MbElement.TYPE_NAME,"AuditData", null);
		
		try{
			mapContent = GlobalCache.readCache(varGCMapName,BrkConfigKey);
			if (mapContent == null){
				 Brk_LogLevel = "DEBUG";
				 Brk_LogSwitch = "ON"; 
			}else{
				envAudt.createElementAsLastChildFromBitstream(mapContent.getBytes(), MbXMLNSC.PARSER_NAME, "", "","", 0, 0, 0);
				String Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,getBroker().getName(),envAudt);
				Brk_LogLevel = Brk_LogLevel_LogSwitch.substring(0,Brk_LogLevel_LogSwitch.indexOf(",")-1); 
				Brk_LogSwitch = Brk_LogLevel_LogSwitch.substring(Brk_LogLevel_LogSwitch.indexOf(",")+1); 
			}
		}catch(Exception e){
			 Brk_LogLevel = "DEBUG";
			 Brk_LogSwitch = "ON"; 
		}finally{
		}
		
		MQGetMessageOptions gmoBrowse = null;
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage outMessage = new MbMessage(inMessage);
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage);
		MQQueueManager qMgr = null;
		boolean mqConn = false;
		int currDepth = 0;
		String QueueManager = getBroker().getQueueManagerName();
		
		MQQueue queue = null;
		String cGBcache = null;
		
		MbElement root = inMessage.getRootElement();
		
		MbElement inFlightPriority = root.getFirstElementByPath("XMLNSC/InflightTrigger");
		String srcQueue = inFlightPriority.getFirstElementByPath("SourceQueue").getValueAsString();
		String BusProcId = inFlightPriority.getFirstElementByPath("Uniqueid").getValueAsString();

		
		
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("[[BROWSE-START]]", "FALSE",
					"InflightPriority_QueueBrowser started for Queue: "
							+ srcQueue, outAssembly, envAudt, labelAudit,
					"INFO", Brk_LogLevel, ApplicationName, BusProcId);
		}
		
		int noOfRetry = 0;
		int udpRetryLimit = 0;
		int prtyCount = 0;
		try {
			cGBcache = GlobalCache.readCache(PriorityMap, PriorityKey);
			if (cGBcache == null) {
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
							"[[BROWSE-CACHE_EMPTY-END]]",
							"FALSE",
							"Gloabal cache returned null value,InflightPriority_QueueBrowser will end ",
							outAssembly, envAudt, labelAudit, "INFO",
							Brk_LogLevel, ApplicationName, BusProcId);
				}

			} else {
				/* Queue Manager connection */
				for (noOfRetry = 0; noOfRetry <= udpRetryLimit ; noOfRetry++) {
					if (!mqConn) {
						qMgr = new MQQueueManager(QueueManager);
						mqConn = true;
						break;
					}
				}
				gmoBrowse = new MQGetMessageOptions();

				/* Queue browse and Read -- START */
				int openOptions = CMQC.MQOO_FAIL_IF_QUIESCING | CMQC.MQOO_INPUT_SHARED | CMQC.MQOO_BROWSE | CMQC.MQOO_INQUIRE;
				queue = qMgr.accessQueue(srcQueue, openOptions);
				MQMessage theMessage = new MQMessage();
				gmoBrowse.options = CMQC.MQGMO_BROWSE_FIRST;
				gmoBrowse.matchOptions = CMQC.MQMO_NONE;
				currDepth = queue.getCurrentDepth();
				int noOfMsgs = currDepth;
				while (currDepth > 0) {
					currDepth--;
					queue.get(theMessage, gmoBrowse);
					TransFileId = theMessage.getStringProperty("TransFileId");
					TransSetId = theMessage.getStringProperty("TransSetId");
					
					if (theMessage.priority != 9 && cGBcache.contains("_" + TransFileId + "_" + TransSetId+ "_")) {
						
							if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
								AuditLog(
										"[[BROWSE-PRIORITY_MESSGAE]]",
										"FALSE",
										"This TransFileId_TransSetId "
												+ TransFileId
												+ "_"
												+ TransSetId
												+ " has a priority message ",
										outAssembly, envAudt, labelAudit,
										"DEBUG", Brk_LogLevel, ApplicationName,
										BusProcId);
							}
							prtyCount = 1;
					
						break;
					}
					gmoBrowse.options = CMQC.MQGMO_BROWSE_NEXT;
				}
				
				eTm = System.currentTimeMillis();
				totalTm = eTm - sTm;
	

				if(prtyCount > 0){
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog("********BROWSE-END-READ_TRIGGER**********", "FALSE", "Queue Browse App sent trigger for the queue: " + srcQueue
								+ " " + totalTm + " (millSec) :" + " total depth:" + noOfMsgs + " browse position :" + (noOfMsgs-currDepth), outAssembly, envAudt,
								labelAudit, "INFO", Brk_LogLevel, ApplicationName,
								BusProcId);
					}
					//outMessage = inMessage;
					MbElement outroot = outMessage.getRootElement();
					outroot.getFirstElementByPath("MQMD").getFirstElementByPath("MsgId").setValue(theMessage.messageId);
					out.propagate(outAssembly);
				}else{
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog("[[BROWSE-END-NO_PRIORITY]]", "FALSE", "Queue Browse App end - no trigger for for the queue: " + srcQueue
								+ " " + totalTm + " (millSec)" + " total depth:" + noOfMsgs , outAssembly, envAudt,
								labelAudit, "INFO", Brk_LogLevel, ApplicationName,
								BusProcId);
					}
				}
			}
		} catch (MQException e) {
			if (noOfRetry == udpRetryLimit) {
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("[[MQ_CONN:FAIL]]", "TRUE",
							"Retry Limit Reached, failing message",
							outAssembly, envAudt, labelAudit, "WARN",
							Brk_LogLevel, ApplicationName, BusProcId);
				}
			}
			switch (e.reasonCode) {
			case CMQC.MQRC_CONNECTION_BROKEN: {
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("MQ_CONNECTION:BROKEN", "FALSE",
							"Error: MQRC_CONNECTION_BROKEN ", outAssembly,
							envAudt, labelAudit, "WARN", Brk_LogLevel,
							ApplicationName, BusProcId);
				}
				break;
			}
			case CMQC.MQRC_NO_MSG_AVAILABLE: {
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog("[[NO_MESSGAES_FOR_CHECK]]", "FALSE",
								"MQRC_NO_MSG_AVAILABLE -- No messages to browse in the queue: "
										+ srcQueue, outAssembly, envAudt,
								labelAudit, "INFO", Brk_LogLevel,
								ApplicationName, BusProcId);
					}
				break;
			}
			case CMQC.MQRC_PROPERTY_NOT_AVAILABLE: {
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("[[MQRFH2_Header_Exception]]", "FALSE",
							"In MQRFH2 header, MQRFH2.usr.TransFileId and MQRFH2.usr.TransSetId value should be set as xml elements instead of attrributes" +
							" | Exception in the queue browse: "
									+ srcQueue, outAssembly, envAudt,
							labelAudit, "ERROR", Brk_LogLevel,
							ApplicationName, BusProcId);
				}
			break;
		}
			default: {
				mqConn = false;
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("[[MQ:FAIL]]", "FALSE",
							"Error: MQRC Error  , --- retrying---",
							outAssembly, envAudt, labelAudit, "ERROR",
							Brk_LogLevel, ApplicationName, BusProcId);
				}

				break;
			}

			}
		} catch (Exception e) {
			if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
				AuditLog(e.toString(), "FALSE", e.getMessage(), outAssembly,
						envAudt, labelAudit, "DEBUG", Brk_LogLevel,
						ApplicationName, BusProcId);
			}
		} finally {
			if (queue != null)
				try {
					queue.close();
				} catch (MQException e) {
					e.printStackTrace();
				}
			if (qMgr != null)
				try {
					qMgr.close();
				} catch (MQException e) {
					e.printStackTrace();
				}
		}
	}

	public void AuditLog(String TransactionLevel,String PayloadFlag, String AuditMessage, MbMessageAssembly outAssembly, MbElement mbAuditData,MbRoute labelAudit, 
			String appLogLevel,String Brk_LogLevel,String ApplicationName,String busProcId)throws MbException{
		if (Brk_LogLevel.equalsIgnoreCase("DEBUG")
					|| (Brk_LogLevel.equalsIgnoreCase("ERROR") && appLogLevel.equalsIgnoreCase("ERROR"))
					|| (Brk_LogLevel.equalsIgnoreCase("WARN") && (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR")))
					|| (Brk_LogLevel.equalsIgnoreCase("INFO") && (appLogLevel.equalsIgnoreCase("INFO") || (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR"))))) {
				if (mbAuditData.getFirstElementByPath("TransactionLevel") == null) {
					mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,"loggerAppender", ApplicationName);
					mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"uniqueID", busProcId);
					mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"Payload", PayloadFlag);
					mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"TransactionLevel", TransactionLevel);
					mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AuditMessage", AuditMessage);
					mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AppLogLevel", appLogLevel);
				} else {

					mbAuditData.getFirstElementByPath("TransactionLevel").setValue(TransactionLevel);
					mbAuditData.getFirstElementByPath("Payload").setValue(PayloadFlag);
					mbAuditData.getFirstElementByPath("AuditMessage").setValue(AuditMessage);
					mbAuditData.getFirstElementByPath("AppLogLevel").setValue(appLogLevel) ;
				}
				labelAudit.propagate(outAssembly);
			}
		
	
}
}

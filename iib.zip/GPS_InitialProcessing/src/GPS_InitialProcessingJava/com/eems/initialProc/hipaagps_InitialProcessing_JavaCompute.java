package com.eems.initialProc;

import java.text.SimpleDateFormat;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;

public class hipaagps_InitialProcessing_JavaCompute extends MbJavaComputeNode {

	/* Method to call the hipaagps_initProc_SubmtCnt.sh script -- added for GPS Project  */
	public static String hipaagps_initProc_SubmtCnt(String udpinitProcSubmtCnt,String CH_InputFileNM, String transFileId,String eligSysCd) {
		int value = 0;
		try {
		ProcessBuilder pb = new ProcessBuilder(udpinitProcSubmtCnt,CH_InputFileNM,transFileId,eligSysCd);
		Process p = pb.start();
        value 	  = p.waitFor();
         } catch (Exception e) {
        	e.printStackTrace();
      		value = 2;
		}
		return String.valueOf(value);
	}

	/* Method to call the hipaagps_initProc_Split.sh script  */
	public static String hipaagps_initProc_Split(String udpinitProcSplit,String CH_InputSplitFileLaction,String CH_SubIDTransPrty, String CH_TransFileId,String PriorityFlag,String eligSysCd) {
		int value2 = 0;
		try {
		ProcessBuilder pb = new ProcessBuilder(udpinitProcSplit,CH_InputSplitFileLaction,CH_SubIDTransPrty,CH_TransFileId,PriorityFlag,eligSysCd);
		Process p = pb.start();
        value2 	  = p.waitFor();
         } catch (Exception e) {
        	 e.printStackTrace();
      		value2 = 2;
		}
		return String.valueOf(value2);
	}
	/* Method to call the initProc_SubmtCnt.sh script  */
	public static String gps_initProc_SubmtCnt(String udpinitProcSubmtCnt,String CH_InputFileNM, String transFileId) {
		int value = 0;
		try {
		ProcessBuilder pb = new ProcessBuilder(udpinitProcSubmtCnt,CH_InputFileNM,transFileId);
		Process p = pb.start();
        value 	  = p.waitFor();
         } catch (Exception e) {
        	e.printStackTrace();
      		value = 2;
		}
		return String.valueOf(value);
	}
	
	/* Method to call the initProc_Split.sh script  */
	public static String gps_initProc_Split(String udpinitProcSplit,String CH_InputSplitFileLaction,String CH_SubIDTransPrty, String CH_TransFileId,String PriorityFlag) {
		int value2 = 0;
		try {
		ProcessBuilder pb = new ProcessBuilder(udpinitProcSplit,CH_InputSplitFileLaction,CH_SubIDTransPrty,CH_TransFileId,PriorityFlag);
		Process p = pb.start();
        value2 	  = p.waitFor();
         } catch (Exception e) {
        	 e.printStackTrace();
      		value2 = 2;
		}
		return String.valueOf(value2);
	}
	
	/**
	 * Getting Curent time in yyyy-MM-dd HH:mm:ss format
	 */
	public static String getDateTime() {
		java.util.Date date = new java.util.Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss.SSSSSS");
		return sdf.format(date);
	}
	@Override
	public void evaluate(MbMessageAssembly arg0) throws MbException {
		// TODO Auto-generated method stub
		
	}
	
}


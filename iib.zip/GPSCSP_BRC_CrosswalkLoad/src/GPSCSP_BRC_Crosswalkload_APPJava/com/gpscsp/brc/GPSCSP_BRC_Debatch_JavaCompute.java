package com.gpscsp.brc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbUserException;
import common.java.util.CommonUtil;
import com.be128.globalcache.GlobalCache;
public class GPSCSP_BRC_Debatch_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");
		MbElement mEnv = null;
		final SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMddHHmmssSSSS");
		mEnv = inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables");
		if(mEnv == null)
		{
			mEnv = inAssembly.getGlobalEnvironment().getRootElement().createElementAsLastChild(MbElement.TYPE_NAME, "Variables", null);
		}
		
		MbRoute labelAudit 					= getRoute ("AUDIT");
		String BrkConfigKey 				= 		(String) getUserDefinedAttribute("BrkConfigKey_1");
		String varGCMapName 				= 		(String) getUserDefinedAttribute("varGCMapName_1");
		String ApplicationName 				= 		(String) getUserDefinedAttribute("ApplicationName");
		String SchemaName 						= 		(String) getUserDefinedAttribute("SchemaName_1");
		String Brk_LogLevel_LogSwitch 		= 		"";
		String Brk_LogLevel					= 		"";
		String Brk_LogSwitch				= 		"";

		Random randomGenerator = new Random();
		
		int randomInt = randomGenerator.nextInt(100000)*999999;
		String busProcId = SDF.format(new Timestamp(System.currentTimeMillis()))+String.valueOf(randomInt).substring(0, 5);
		
		/**
		 * Setting Environment Variables for Exception Handler
		 */
		MbElement mEnvExc = mEnv.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ExceptionData", null);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Custnumber", "N/A");
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BusinessProcessID", busProcId);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TransSetId", "NA");
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TransFileId", "NA");
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "SubmitterId", "NA");
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BusProcId", busProcId);
		mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Payload", "NA");
		/**
		 * Setting Environment Variables for Audit Logging 
		 */
		MbElement mbAuditData =mEnv.createElementAsLastChild(MbElement.TYPE_NAME, "AuditData", "");
		MbElement envConfig = mEnv.createElementAsLastChild( MbElement.TYPE_NAME, "ConfigCacheXML", null);
		CommonUtil.readBkrConfigCacheXML(BrkConfigKey, varGCMapName, envConfig, SchemaName);
		MbElement mVarCacheConfig = envConfig.getFirstElementByPath("XMLNSC/BRK_CONFIG");
		Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,getBroker().getName(), mVarCacheConfig);
		Brk_LogLevel = Brk_LogLevel_LogSwitch.substring(0,Brk_LogLevel_LogSwitch.indexOf(","));
		Brk_LogSwitch = Brk_LogLevel_LogSwitch.substring(Brk_LogLevel_LogSwitch.indexOf(",") + 1);
		mEnv.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Brk_LogLevel", Brk_LogLevel);
		mEnv.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Brk_LogSwitch", Brk_LogSwitch);
		
		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
            String  brcLine = null;
            StringBuffer brcBatch= new StringBuffer();
            int noOfRecs = 0;
            int recsInBatch=0;
            int batchNbr =0;
            int totalBatchCount=0;
            int totalRecords=0;
            double batchcount =0;
            SimpleDateFormat PickupDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat ArchiveTimeFormat = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss_");
            String currentFilePickupDate = PickupDateFormat.format(new Date());
            String CSP_FileName_Prefix=null;
		    /*
		     * File can come in <databaseName>.FSG_INCX_INCW_EXPORT.txt 
		     * The database name is CSP specific DB name and will be varying by environment
		     * 
		     */
			
			File InboundDir = new File("/eems/iib/inbound/BRC/");
			
			if(InboundDir.isDirectory()){
				
				File[] listOfFiles= InboundDir.listFiles();
				boolean matchNotFound=true;
				for (int i = 0; i < listOfFiles.length; i++) {
					if(listOfFiles[i].isFile() && listOfFiles[i].getName().endsWith(".FSG_INCX_INCW_EXPORT.txt")){
						CSP_FileName_Prefix=listOfFiles[i].getName().substring(0, listOfFiles[i].getName().indexOf('.'));
						break;
					}
					
				}
			}
			
			
			File inboundFile = new File("/eems/iib/inbound/BRC/" + CSP_FileName_Prefix + ".FSG_INCX_INCW_EXPORT.txt");
			File lockedFileName = new File("/eems/iib/inbound/BRC/" + CSP_FileName_Prefix + ".FSG_INCX_INCW_EXPORT.txt.lock");
			if(!inboundFile.exists()){
				mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "InboundFilename", "NOFILE!! ");
				AuditLog("GPSCSP_BRC_CrosswalkLoad_APP:START","FALSE", "Exiting as there is no file to read!!! ", outAssembly,mbAuditData,labelAudit
						,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
				return;
			}
			/*boolean creatCache1 =GlobalCache.insertCache("GPSCSP_BRC_XWalkLoad_Map", "FilePickupDate", currentFilePickupDate+",17");
        	boolean creatCache2 =GlobalCache.insertCache("GPSCSP_BRC_XWalkLoad_Map", "FilePickupDate_Status", "C");
        	boolean creatCache3 =GlobalCache.insertCache("GPSCSP_BRC_XWalkLoad_Map", "FilePickupDate_BatchCount", "0");*/
			mEnvExc.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "InboundFilename", inboundFile.getName());
			
			AuditLog("GPSCSP_BRC_CrosswalkLoad_APP:START","FALSE", "Start of reading the file: "+inboundFile.getName(), outAssembly,mbAuditData,labelAudit
					,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);
			
			
			inboundFile.renameTo(lockedFileName);
			inboundFile = new File("/eems/iib/inbound/BRC/" + CSP_FileName_Prefix + ".FSG_INCX_INCW_EXPORT.txt.lock");
			
        	//Get total batch count..takes same about of time as that of a wc -l command.
        	BufferedReader buffBatchReader = new BufferedReader(new FileReader(inboundFile));
        	
        	
        	while (buffBatchReader.readLine() != null) {
        		totalRecords++;
        	}
        	buffBatchReader.close();
        	batchcount=(double)totalRecords/1000;
        	totalBatchCount=(int) Math.ceil(batchcount);
        	boolean creatCache1 =GlobalCache.insertCache("GPSCSP_BRC_XWalkLoad_Map", "FilePickupDate", currentFilePickupDate+","+totalBatchCount+","+busProcId);
        	boolean creatCache2 =GlobalCache.insertCache("GPSCSP_BRC_XWalkLoad_Map", "FilePickupDate_Status", "C");
        	boolean creatCache3 =GlobalCache.insertCache("GPSCSP_BRC_XWalkLoad_Map", "FilePickupDate_BatchCount", "0");
        	//Read thru records
			
		    BufferedReader br = new BufferedReader(new FileReader(inboundFile));
		    
		         while ((brcLine = br.readLine()) != null) {
		                if(brcLine.trim().length()>0 && brcLine.substring(8, 24).trim().length()>0){
		                      
		                      
		                      brcBatch=brcBatch.append(brcLine+currentFilePickupDate+"\n");
		                      noOfRecs++;
		                      recsInBatch++; 
		                      
		                      if(recsInBatch>=1000){
		                             recsInBatch=0;
		                             
		                             //Send MQ message with brcBatch.toString() as message;
		                             String finalMessage=brcBatch.toString();
		                             
		                             outMessage = new MbMessage();
		                             MbElement outRoot = outMessage.getRootElement();
		                          // Create the Broker Blob Parser element
		                          MbElement outParser = outRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
		                          // Create the BLOB element in the Blob parser domain with the required text
		                          MbElement outBody = outParser.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", finalMessage.getBytes());
		                          
		                          outAssembly = new MbMessageAssembly(inAssembly, outMessage );
		                          out.propagate(outAssembly);
		                          outMessage.clearMessage();
		                          
		                         /* AuditLog("GPSCSP_BRC_CrosswalkLoad_APP:INTERMEDIATE","FALSE", "Sending Batch: "+String.valueOf(recsInBatch)+" for file: "+inboundFile.getName()
		                        		  , outAssembly,mbAuditData,labelAudit,"DEBUG",Brk_LogLevel,Brk_LogSwitch,ApplicationName,busProcId);*/
		                          
		                          //reset buffer
		                          brcBatch = new StringBuffer();
		                      }
		                      
		                }
		         }
		         
		         if(brcBatch.length()>0){
		                //Send MQ message with brcBatch.toString() as message;
		             //Send MQ message with brcBatch.toString() as message;
		             String finalMessage=brcBatch.toString();
		             
		             outMessage = new MbMessage();
		             MbElement outRoot = outMessage.getRootElement();
		          // Create the Broker Blob Parser element
		             MbElement outParser = outRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
		          // Create the BLOB element in the Blob parser domain with the required text
		             MbElement outBody = outParser.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", finalMessage.getBytes());
		          
		          outAssembly = new MbMessageAssembly(inAssembly, outMessage );
		          out.propagate(outAssembly);
		          outMessage.clearMessage();
		          
		         }
		        
		        br.close();
		        String archiveTime = ArchiveTimeFormat.format(new Date());
		        
		        File archivedInboundFile = new File("/eems/iib/archive/BRC/" + archiveTime + CSP_FileName_Prefix + ".FSG_INCX_INCW_EXPORT.txt");
		        inboundFile.renameTo(archivedInboundFile);
		        
		        //archive two other files
		        File additionalFile1 = new File("/eems/iib/inbound/BRC/" + CSP_FileName_Prefix + ".FSG_BRCX_BRCL_EXPORT.txt");
		    	File additionalFile2 = new File("/eems/iib/inbound/BRC/" + CSP_FileName_Prefix + ".FSG_INLX_INLI_EXPORT.txt");
		    	if(additionalFile1.exists() && additionalFile1.isFile()){
		    		File archivedAdditionalFile1 = new File("/eems/iib/archive/BRC/" + archiveTime + CSP_FileName_Prefix + ".FSG_BRCX_BRCL_EXPORT.txt");
		    		additionalFile1.renameTo(archivedAdditionalFile1);
		    	}
		    	if(additionalFile2.exists() && additionalFile2.isFile()){
		    		File archivedAdditionalFile2 = new File("/eems/iib/archive/BRC/" + archiveTime + CSP_FileName_Prefix + ".FSG_INLX_INLI_EXPORT.txt");
		    		additionalFile2.renameTo(archivedAdditionalFile2);
		    	}
		    	
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw new MbUserException(this.getClass().getName(), "GPSCSP_BRC_Debatch_JavaCompute", "", "1115", 
					"Message : "+ e.getMessage(), 
					new Object[]{"1115", "USER Error Code:1115  Error Description:Error in execution of batch"});
			//	throw e;
		} catch (RuntimeException e) {
			throw new MbUserException(this.getClass().getName(), "GPSCSP_BRC_Debatch_JavaCompute", "", "1116", 
					"Message : "+ e.getMessage(), 
					new Object[]{"1116", "USER Error Code:1116  Error Description:Error in execution of batch"});
//			throw e;
		} catch (Exception e) {
			throw new MbUserException(this.getClass().getName(), "GPSCSP_BRC_Debatch_JavaCompute", "", "1117", 
					"Message : "+ e.getMessage(), 
					new Object[]{"1117", "USER Error Code:1117  Error Description:Error in execution of batch"});
//			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
//					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		//out.propagate(outAssembly);

	}

	
	/**
	 * AUDIT Logging subflow routing		
	 */
	public void AuditLog(String TransactionLevel,String PayloadFlag, String AuditMessage, MbMessageAssembly outAssembly, MbElement mbAuditData,MbRoute labelAudit, 
			String appLogLevel, String Brk_LogLevel,  String Brk_LogSwitch, String ApplicationName,String busProcId)throws MbException{
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			CommonUtil.AuditLog(TransactionLevel,	PayloadFlag,AuditMessage, outAssembly,	mbAuditData, labelAudit, appLogLevel, Brk_LogLevel, ApplicationName,busProcId);
		}
	}
	
}

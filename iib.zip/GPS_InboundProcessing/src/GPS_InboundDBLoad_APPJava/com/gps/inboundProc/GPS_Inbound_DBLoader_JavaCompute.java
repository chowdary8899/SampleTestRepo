package com.gps.inboundProc;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.be128.globalcache.GlobalCache;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

/*-------------------------------------------------------
 * Module 	   : GPS_Inbound_DBLoader_JavaCompute

 * Description : This module does following operations:
 1.	Makes connection to database and executes the INSERT queries for batch of members.
 2.	This also updates the Global cache with the processed count and invokes IsReadyToProcess only when processed and actual inbound count matches in Global cache Map (GPS_Inbound_Map).
 3.  Sets the Required parameters in Environment for Audit Logging and Exception Handling.
 4.	�START� and �END� tags are checked in MQRFH2 header to do Entry and Exit of Status code logging for DBLoader for the currently processing TransSetId. 

 * Modification History:
 * * Date 				Author 			       Version 		    Description
 * 13 Feb, 2017 		Ashok Chintoju		     1.1 			Initial version
 * 10 April, 2017		Srikanth Yekollu		 1.2			Updated code for retry logic incase of DB Exception
 * ----------------------------------------------------*/

public class GPS_Inbound_DBLoader_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		String ApplicationName = (String) getUserDefinedAttribute("UDP_ApplicationName");
		String brkrList = (String) getUserDefinedAttribute("brkrList");
		String inboundMap = (String) getUserDefinedAttribute("InboundMap");
		String sDSN = (String) getUserDefinedAttribute("DSN");
		String commonMap = (String) getUserDefinedAttribute("CommonMap");
		boolean BATCH_FAIL_MODE = (boolean) getUserDefinedAttribute("BATCH_FAIL_MODE");
		int sleepTime = (int) getUserDefinedAttribute("sleepTime");
		String Brk_LogLevel = "";
		String Brk_LogSwitch = "";

		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbElement root = inMessage.getRootElement();

		MbMessageAssembly outAssembly = null;
		
		//MbMessage retryMessage 	= 	inAssembly.getMessage();
		//MbMessageAssembly retryAssembly = new MbMessageAssembly(inAssembly,	retryMessage);
		MbElement globRoot = inAssembly.getGlobalEnvironment().getRootElement();
		MbElement mVar = globRoot.getFirstElementByPath("Variables");
		//MbElement retryRoot = null;
		
		if (mVar == null) {
			mVar = globRoot.createElementAsLastChild(MbElement.TYPE_NAME,"Variables", null);
		}

		/*
		 * Accessing Main map in Global Cache
		 */
		MbElement mbTransSetId = root.getFirstElementByPath("MQRFH2/usr/TransSetId");
		MbElement mbTransFileId = root.getFirstElementByPath("MQRFH2/usr/TransFileId");
		Brk_LogLevel = root.getFirstElementByPath("MQRFH2/usr/Brk_LogLevel").getValueAsString();
		Brk_LogSwitch = root.getFirstElementByPath("MQRFH2/usr/Brk_LogSwitch").getValueAsString();
		
				//Investigate why the headers are not properly populated and fix the issue. Below line is a temporary code fix
		if (Brk_LogLevel == null) {
				Brk_LogLevel = "DEBUG";
		}

		if (Brk_LogSwitch == null) {
				Brk_LogSwitch = "ON";
		}
		//Brk_LogLevel = "DEBUG";
		//Brk_LogSwitch = "ON";
		if (mbTransFileId == null) {
			throw new MbUserException(this.getClass().getName(),"GPS_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error : ","No TransFileId in the MQRFH2 header" });
		}

		if (mbTransSetId == null) {
			throw new MbUserException(this.getClass().getName(),"GPS_Inbound_DBLoader_JavaCompute", "", "", "",	
					new Object[] { "Error : ","No TransSetId in the MQRFH2 header" });
		}

		String mapContent = GlobalCache.readCache(commonMap,mbTransFileId.getValueAsString() + "_"+ mbTransSetId.getValueAsString());
		mVar.createElementAsLastChildFromBitstream(mapContent.getBytes(),MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0);

		/*
		 * if(mVar.getFirstElementByPath("XMLNSC/CachingLayout/FailureStatus").
		 * getValueAsString().equalsIgnoreCase("Y")) { return; }
		 */
		MbRoute label1 = getRoute("AUDIT");

		Connection conn = null;
		Statement stmt = null;
		ResultSet rsx = null;
		
		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/BusProcId") == null) {
			throw new MbUserException(
					this.getClass().getName(),
					"GPS_Inbound_DBLoader_JavaCompute","","","",
					new Object[] {"Error : ","No BusProcId in the Global Cache, Expected Structure : CachingLayout/BusProcId" });
		}

		String BusProcId = mVar.getFirstElementByPath("XMLNSC/CachingLayout/BusProcId").getValueAsString();
		String InFileName = mVar.getFirstElementByPath("XMLNSC/CachingLayout/InFileName").getValueAsString();
		String SubmitterID = mVar.getFirstElementByPath("XMLNSC/CachingLayout/AssignedSubmitterName").getValueAsString();
		String eligSysCd = mVar.getFirstElementByPath("XMLNSC/CachingLayout/eligSysCd").getValueAsString();
		String ReprIndicator = mVar.getFirstElementByPath("XMLNSC/CachingLayout/ReprIndicator").getValueAsString();
		String priorityFlag = mVar.getFirstElementByPath("XMLNSC/CachingLayout/PriorityFlag").getValueAsString();
		String transSet = root.getFirstElementByPath("MQRFH2/usr/TransSetId").getValueAsString();
		
		/* Audit FrameWork Changes -- START */

		MbElement mbAuditData = mVar.createElementAsLastChild(MbElement.TYPE_NAME, "AuditData", "");

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("INBOUND_DBLOAD_START","FALSE",
					"Start of DB Loader Transaction for TransSetId = "+ mbTransSetId.getValueAsString()+ " TransFileId  = "
					+ mbTransFileId.getValueAsString(), inAssembly,mbAuditData, label1, "INFO", Brk_LogLevel, ApplicationName,BusProcId);
		}


		/*
		 * File StatusCode Logging
		 */
		MbElement mbUsr = root.getFirstElementByPath("MQRFH2/usr");
		String sMsgFlag = mbUsr.getFirstElementByPath("MsgFlag")
				.getValueAsString();
		if (mbUsr.getFirstElementByPath("SplitFileNumber") == null) {
			throw new MbUserException(this.getClass().getName(),"GPS_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error Code : 5001","No MiniSplit file count in MQRFH2 header" });
		}

		if (sMsgFlag.equalsIgnoreCase("START")) {
			Connection connProc = null;
			Statement stmtProc = null;
			for (int i = 1; i <= 3; i++) {
				try {
					connProc = getJDBCType4Connection(sDSN,
							JDBC_TransactionType.MB_TRANSACTION_AUTO);
					stmtProc = connProc.createStatement();
					String time = getDateTime();

					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
							+ "VALUES ('INBOUND_DBLOAD','START','"
							+ time
							+ "',"
							+ BusProcId
							+ ",'INBOUND_PROCESSING','IIB',"
							+ mbTransFileId.getValueAsString()
							+ ","
							+ mbTransSetId.getValueAsString()
							+ ",'','"
							+ InFileName
							+ "','"
							+ "''"
							+ "', '',0,'"
							+ SubmitterID
							+ "','"
							+ time
							+ "','MiniFile_"
							+ mbUsr.getFirstElementByPath("SplitFileNumber")
									.getValueAsString() + "')";
					stmtProc.execute(sql);
					break;
				} catch (SQLException sqlExcep) {
					if (i == 3) {
						if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
							AuditLog(
											"SQL-ERROR_PROCFILE",
											"FALSE",
											"Error Loading database even after re-trying 3 times for PROCFILE_START and SQLMsg = "
													+ sqlExcep.getMessage()
													+ ", SQLState = "
													+ sqlExcep.getSQLState()
													+ ", SQLErrorCode = "
													+ sqlExcep.getErrorCode(),
											inAssembly, mbAuditData, label1,
											"ERROR", Brk_LogLevel,
											ApplicationName, BusProcId);
							
						}
					}
				} finally {
					try {
						if (stmtProc != null) {
							stmtProc.close();
						}
					} catch (SQLException sqlExcepProcStart) {
			
					}
				}
			}
		} else if (sMsgFlag.equalsIgnoreCase("END")) {
			Connection connProc = null;
			Statement stmtProc = null;
			for (int i = 1; i <= 3; i++) {
				try {
					connProc = getJDBCType4Connection(sDSN,
							JDBC_TransactionType.MB_TRANSACTION_AUTO);
					stmtProc = connProc.createStatement();
					String time = getDateTime();
					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
							+ "VALUES ('INBOUND_DBLOAD','END','"
							+ time
							+ "',"
							+ BusProcId
							+ ",'INBOUND_PROCESSING','IIB',"
							+ mbTransFileId.getValueAsString()
							+ ","
							+ mbTransSetId.getValueAsString()
							+ ",'','"
							+ InFileName
							+ "','"
							+ "''"
							+ "', '',0,'"
							+ SubmitterID
							+ "','"
							+ time
							+ "','MiniFile_"
							+ mbUsr.getFirstElementByPath("SplitFileNumber")
									.getValueAsString() + "')";

					stmtProc.execute(sql);
					break;
				} catch (SQLException sqlExcep) {
					if (i == 3) {
				
						if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
							AuditLog(
											"SQL-ERROR_PROCFILE",
											"FALSE",
											"Error Loading database even after re-trying 3 times for PROCFILE_END and SQLMsg = "
													+ sqlExcep.getMessage()
													+ ", SQLState = "
													+ sqlExcep.getSQLState()
													+ ", SQLErrorCode = "
													+ sqlExcep.getErrorCode(),
											inAssembly, mbAuditData, label1,
											"ERROR", Brk_LogLevel,
											ApplicationName, BusProcId);
							
						}

					}
				} finally {
					try {
						if (stmtProc != null) {
							stmtProc.close();
						}
					} catch (SQLException sqlExcepProcEnd) {
						// throw new MbUserException(this.getClass().getName(),

					}
				}
			}

			if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
				AuditLog(
								"END-INBOUND_DBLOADER_TRANSETID",
								"FALSE",
								"End of DBLoad Operation for the entire TranSetId = "
										+ mbTransSetId.getValueAsString()
										+ " with MiniFile = "
										+ mbUsr.getFirstElementByPath(
												"SplitFileNumber")
												.getValueAsString(),
								inAssembly, mbAuditData, label1, "DEBUG",
								Brk_LogLevel, ApplicationName, BusProcId);
				
			}
			return;
		}

		/*
		 * Makes JDBC batch connection and retries 3 times in case of DB
		 * Failures
		 */

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("PRE-DBLOAD", "FALSE",
					"Start of Loading Database", inAssembly, mbAuditData,
					label1, "INFO", Brk_LogLevel, ApplicationName, BusProcId);
		}

		boolean batchFailMode = false;
		boolean isRetry = false;  
		//Indices that will hold the insert query index/number for the failed ones incase of a retry 
        ArrayList<Integer> errInsrtQryIndices = new ArrayList<Integer>(); 
		List list1 = null;
		if (root.getFirstElementByPath("XMLNSC") != null) {
			list1 = (List) root.getFirstElementByPath("XMLNSC/BatchQueries").evaluateXPath("BatchMemberQueries");
		}
		
		for (int i = 1; i <= 3; i++) {
			try {
				if (batchFailMode) {
					break;
				}
				conn = getJDBCType4Connection(sDSN,JDBC_TransactionType.MB_TRANSACTION_AUTO);
				//conn.setAutoCommit(false); 
				stmt = conn.createStatement();
				
				int batchQryIdx=0;
				stmt.clearBatch();
				for (int k = 0; k < list1.size(); k++) {
					Boolean isMbrErred=false; 
					MbElement mbBatchMemQueries = (MbElement) list1.get(k);
					List mbTbQueryList = (List) mbBatchMemQueries.evaluateXPath("TableQuery");
					int size = mbTbQueryList.size();
					if (isRetry){
						for(int j = 0; j < size; j++){
							if (errInsrtQryIndices.contains(j+batchQryIdx) && !isMbrErred) {
									isMbrErred = true;
									batchFailMode = true;
									String updateEligSys ;
									String insertEligSys;
									String transId = "";
									String failedquery = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
									if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
										AuditLog("FAILED_MEMBER", "FALSE",
												"Query failed while Loading to Database for TransSetId = "
														+ mbTransSetId.getValueAsString() + " first failed query is : " +failedquery, inAssembly, mbAuditData,
												label1, "WARN", Brk_LogLevel, ApplicationName, BusProcId);
									}
									/*
									 * ELECELIG.ELIG_SYS_TRANS table changes
									 */
									
									String firstQuery = ((MbElement) mbTbQueryList.get(0)).getValueAsString();
									firstQuery = firstQuery.substring(firstQuery.lastIndexOf("(")+1);
									transId = firstQuery.substring(0,firstQuery.indexOf(","));
									Statement stmt1 = conn.createStatement();
									String sql = "SELECT TRANS_ID FROM ELECELIG.ELIG_SYS_TRANS " 
													+ "WHERE TRANS_ID = "
													+ transId 
													+ " AND TRANS_SET_ID = "
													+ mbTransSetId.getValueAsString();
									rsx = stmt1.executeQuery(sql);
									if(rsx.next()){
										updateEligSys = "UPDATE ELECELIG.ELIG_SYS_TRANS "
															+ "SET ELIG_TRANS_TYP_CD = 'R'"
															+", PRE_PROC_IND = 'EE'"
															+ " WHERE TRANS_ID="
															+ transId 
															+ " AND TRANS_SET_ID = "
															+ mbTransSetId.getValueAsString();
										stmt.addBatch(updateEligSys);
									}else{
										insertEligSys = "INSERT INTO ELECELIG.ELIG_SYS_TRANS " 
												+ "(TRANS_ID,TRANS_SET_ID,ELIG_TRANS_TYP_CD,ELIG_SYS_CD,RSN_CD,LST_UPDT_DT,"
												+ "LST_UPDT_ID,STS_CD,TRANS_APPL_DT,PROC_CTL_REC_CNT,PROC_CTL_REC_NBR," 
												+ "SBMT_GRP_NM,TRANS_CREAT_DTTM,PRE_PROC_IND,AUX_ID)"
												+ " VALUES (" 
												+ transId
												+ ","
												+ mbTransSetId.getValueAsString()
												+ ","
												+ "'R'"
												+ ",'"
												+ eligSysCd
												+ "',"
												+ "'FL'"
												+ ",'"
												+ getDate()
												+ "','"
												+ BusProcId
												+ "',"
												+ "'11'"
												+ ",'"
												+ getDate()
												+ "','"
												+ "0"
												+ "','"
												+ "0"
												+ "','"
												+ SubmitterID
												+ "','" 
												+ getDateTime()
												+ "'," 
												+ "'EE'"
												+ ","
												+ "'MEMBER_FAIL_INB'"
												+ ")";
										stmt.addBatch(insertEligSys);
										
									}
									
									/*
									 * GPSINBOUND.GPS_MBR table changes
									 */
									
									//Statement stmt1 = conn.createStatement();
							 		sql = "SELECT TRANS_ID FROM GPSINBOUND.GPS_MBR " 
							 					+ "WHERE TRANS_ID = "
							 					+ transId 
							 					+ " AND TRANS_SET_ID = "
							 					+ mbTransSetId.getValueAsString();
							 		rsx = stmt1.executeQuery(sql);
							 		stmt1.clearBatch();
							 		if(rsx.next()){
							 			sql = "UPDATE GPSINBOUND.GPS_MBR SET " 
								 				+"MBR_TRAN_TYP_CD = NULL "
								 				+", MBR_FST_NM = NULL "
								 				+", MBR_MIDL_INIT_NM = NULL "
								 				+", MBR_LST_NM = NULL "
								 				+", MBR_NM_SUFX = NULL "
								 				+", MBR_GDR_CD = NULL "
								 				/*+", HIC_NBR = NULL "*/
								 				+", MBR_BTH_DT = NULL "
								 				+", PREF_LANG_CD = NULL "
								 				+", MEDCR_PART_A_EFF_DT = NULL "
								 				+", MEDCR_PART_B_EFF_DT = NULL "
								 				+", MBR_SOC_SECUR_NBR = NULL "
								 				+", BRAND = NULL "
								 				+", PLN_CATGY_CD = NULL "
								 				+", SIGN_PRES_IND = NULL "
								 				+", SIGN_DT = NULL "
								 				+", INSTITUTION_IND = NULL "
								 				+", HOSPICE_IND = NULL "
								 				+", MEDICAID_IND = NULL "
								 				+", ESRD_IND = NULL "
								 				+", WRK_AGE_IND = NULL "
								 				+", ELEC_PRD_CD = NULL "
								 				+", SEP_RSN_CD = NULL "
								 				+", PCP_NM = NULL "
								 				+", PCP_NBR = NULL "
								 				+", PCP_IND = NULL "
								 		 		+ "WHERE TRANS_ID = "
								 				+ transId 
								 				+ " AND TRANS_SET_ID = "
								 				+ mbTransSetId.getValueAsString();
							 					
							 		stmt.addBatch(sql);

							 		}else{
						 			String MBR_TABLE = "INSERT INTO GPSINBOUND.GPS_MBR (TRANS_ID,TRANS_SET_ID) " +
			 								"VALUES("+Integer.parseInt(transId)+","+Integer.parseInt(transSet)+")";
						 			stmt.addBatch(MBR_TABLE);
							 		}
							 		if(stmt1 != null){
										stmt1.close();
									}
							 		if (rsx != null) {
										rsx.close();
									}
									
							}
							
						}
						batchQryIdx = batchQryIdx + size ;
					}else{
						for (int j = 0; j < size; j++) {
							batchQryIdx++;
							String str = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
							if (str != null)
								stmt.addBatch(((MbElement) mbTbQueryList.get(j)).getValueAsString());
							}
					}
				}

				stmt.executeBatch();
				stmt.clearBatch();
				break;
			} catch (BatchUpdateException bue) {
				int[] counts = bue.getUpdateCounts();
				int len = counts.length;
				//Not needed 
				//batchFailMode = true; 
				//isRetry=true; 
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
									"FAILED-MESSAGE-FOR-ALL-TABLES-LOAD",
									"FALSE",
									"Logging the Message for which All Tables Load Failure Occured",
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
					
				}
				mbAuditData.getFirstElementByPath("Payload").setValue("FALSE");

				StringBuffer sbTest = new StringBuffer();
				sbTest.append("[");
				for (int k = 0; k < len; k++) {
					sbTest.append(counts[k]).append(",");
					if(counts[k] == Statement.EXECUTE_FAILED){
                        errInsrtQryIndices.add(k);
                  }

				}
				sbTest.append("]");

				SQLException ex = bue.getNextException();
				StringBuffer sbSpecExp = new StringBuffer();
				int k = 1;
				sbSpecExp.append("[");
				while (ex != null) {
					sbSpecExp.append("Specific SQL exception for Query = " + k
							+ "is as === ");
					sbSpecExp.append(" Message: " + ex.getMessage());
					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
					sbSpecExp.append(" Error code: " + ex.getErrorCode());
					sbSpecExp.append(" || ");
					ex = ex.getNextException();
					k++;
				}
				
				sbSpecExp.append("]");

				/* Java Stack trace */
				StringWriter sw = new StringWriter();
		        PrintWriter pw = new PrintWriter(sw);
		        bue.printStackTrace(pw);
		         
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("DBLOAD-FAILURE-JAVASTACKTRACE",
							"FALSE",
							"------\r\n" + sw.toString() + "------\r\n",
							inAssembly, mbAuditData, label1, "ERROR",
							Brk_LogLevel, ApplicationName, BusProcId);
					
					AuditLog("ALL-TABLES-LOAD-FAILURE",
									"TRUE",
									"Error Loading All the tables for the Batch...... Batch Response = "
											+ new String(sbTest)
											+ "...... Specific Exception for Every Insert Query = "
											+ new String(sbSpecExp),
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
				}
				
				
				if(BATCH_FAIL_MODE || /*batchFailMode ||*/ (sbSpecExp.indexOf("The batch is terminated non-atomically")>0 && i==3)){
					 batchFailMode = true; 
	
					 //	GlobalCache.updateCache(commonMap,mbTransFileId.getValueAsString() + "_" + mbTransSetId.getValueAsString(),"FailureStatus=Y;");
				 	
					 throw new MbUserException(
						this.getClass().getName(),"GPS_Inbound_DBLoader_JavaCompute",
						"","","Message : " + bue.getMessage() + "SQLState : "+ bue.getSQLState(),
						new Object[] {"Error Code : 2090","BATCH_FAIL_MODE is set to TRUE (or) Non-recoverable chain-breaking exception occurred during batch processing. The batch is terminated non-atomically." });
				 }
				
				 //if(BATCH_FAIL_MODE || batchFailMode){ // add batchFailMode if requirement is to fail the batch if   second time also batch failure happen in case of non-automicaly faield messages
				if(sbSpecExp.indexOf("The batch is terminated non-atomically")>0){
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
										"[RETRY]BATCH_TERMINATED_NON_ATOMICALLY_RETRY:"+i,
										"TRUE",
										"The batch is terminated non-atomically, batch will be retried 3 times before failing the message",
										inAssembly, mbAuditData, label1, "ERROR",
										Brk_LogLevel, ApplicationName, BusProcId);
						
					}
					try {
						Thread.sleep(sleepTime);  // retry after 5 sec
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else if(BATCH_FAIL_MODE == false){
					isRetry=true;
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
										"MEMBER_MARK_TO_FAIL",
										"FALSE",
										"The batch failed atomically, so will set ELECELIG.ELIG_SYS_TRANS entry to 'R' and continue processing with next batch/member",
										inAssembly, mbAuditData, label1, "ERROR",
										Brk_LogLevel, ApplicationName, BusProcId);
						
					}
				}
				
				
				
	
			} catch (SQLException sqlExcep) {
				if (i == 3) {

					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
										"SQL-ERROR",
										"FALSE",
										"Error Loading database even after retrying 3 times",
										inAssembly, mbAuditData, label1,
										"ERROR", Brk_LogLevel, ApplicationName,
										BusProcId);
						
					}
					GlobalCache.updateCache(commonMap,
							mbTransFileId.getValueAsString() + "_"
									+ mbTransSetId.getValueAsString(),
							"FailureStatus=N"); 
					throw new MbUserException(
							this.getClass().getName(),
							"GPS_Inbound_DBLoader_JavaCompute",
							"",
							"",
							"Message : " + sqlExcep.getMessage()
									+ "SQLState : " + sqlExcep.getSQLState(),
							new Object[] { "Error Code : 2080",
									"Error Connecting to Database even after 3 re-tries" });
				}
			} finally {
				if(stmt != null){
					try {
						stmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}


			}
		}

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("POST-DBLOAD", "FALSE",
					"End of Loading Database", inAssembly, mbAuditData, label1,
					"DEBUG", Brk_LogLevel, ApplicationName, BusProcId);
			
		}
		/*
		 * 1. Update Processed count in Global cache's inbound map 2. Once the
		 * processed and actual counts are equal, then create XML for
		 * IsReadyToProcess
		 */

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog(
							"PRE-PROCESSEDCHECKCOUNT",
							"FALSE",
							"Start of Checking processed count against the actual inbound",
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);
		
		}
		int MemCnt = Integer.parseInt(mbUsr
				.getFirstElementByPath("MemberCount").getValueAsString());
		// int ActualMemberCount =
		// Integer.parseInt(mbUsr.getFirstElementByPath("ActualMemberCount").getValueAsString());

		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/InboundMemberCount") == null) {
			throw new MbUserException(this.getClass().getName(),"GPS_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error Code : 2010","No InboundMemberCount in the Global Cache" });
		}

		int InboundMemberCount = Integer.parseInt(mVar.getFirstElementByPath("XMLNSC/CachingLayout/InboundMemberCount").getValueAsString());

		synchronized (this) {

			/* MultiBroker changes -- START */
			String updCheckisReady = GlobalCache.incrementAndIsReadyCheckInb(
					inboundMap, mbTransSetId.getValueAsString() + "_" + getBroker().getName(), String.valueOf(MemCnt),brkrList);

			if (updCheckisReady.equalsIgnoreCase("false")) {


				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
							"INBOUND-COUNT:UPDATE:FAIL",
							"FALSE",
							"Update inbound count utility failed for transSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "ERROR",
							Brk_LogLevel, ApplicationName, BusProcId);
				}

				if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/FailureStatus").getValueAsString().equalsIgnoreCase("Y")) {
	
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
								"COMMON GLOBAL CACHE STATUS:FAIL",
								"FALSE",
								"Global cache is in failure status for transSetId = "
										+ mbTransSetId.getValueAsString()
										+ " TransFileId  = "
										+ mbTransFileId.getValueAsString(),
								inAssembly, mbAuditData, label1, "ERROR",
								Brk_LogLevel, ApplicationName, BusProcId);
						
					}
				} else {
					throw new MbUserException(
							this.getClass().getName(),
							"GPS_Inbound_DBLoader_JavaCompute",
							"",
							"2011",
							"",
							new Object[] {
									"2011",
									"USER Error Code:2011  Error Description:GPS_Inbound_Map value is null for the transet Id:"
											+ mbTransSetId.getValueAsString()
											+ "/ also Global cache status is not in Failure. So failing the message and will set the Global cache Failurestatus to Y" });
				}

			} else if (updCheckisReady.equalsIgnoreCase("Y")) {

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog("IN-PROCESSEDCHECKCOUNT","FALSE",
							"Processed and Actual count (" + InboundMemberCount
									+ " )matches for TransSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);
					
				}
				// create new message as a copy of the input
				MbMessage outMessage = new MbMessage();
				MbElement outRoot = outMessage.getRootElement();
				MbElement mqmd = outRoot.createElementAsFirstChild("MQMD");
				// Prioritizing for FFM files
				if (priorityFlag.equals("Z")) {
					mqmd.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE,"Priority", 9);
				}
				MbElement xmlnsc = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "ReadyToProcessRequest", null);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"BusProcId", BusProcId);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId", mbTransFileId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transSetId", mbTransSetId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"event","INB");
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"eventData", InboundMemberCount);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"eligSysCd", eligSysCd);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"reprInd",ReprIndicator);

				outAssembly = new MbMessageAssembly(inAssembly, outMessage);
				out.propagate(outAssembly);
				outMessage.clearMessage();

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
							"IS_READY_TO_PROCESS_TRIGGER",
							"FALSE",
							"IsReadyToProcess is triggered for TransSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "INFO",
							Brk_LogLevel, ApplicationName, BusProcId);
					
				}


			} else {

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
									"IN-PROCESSEDCHECKCOUNT",
									"FALSE",
									"Processed and Actual count does not match yet for TransSetId = "
											+ mbTransSetId.getValueAsString()
											+ " TransFileId  = "
											+ mbTransFileId.getValueAsString()
											+ ", with current counts in all the Brokers as (ActualCount,Processed Count) = ("
											+ updCheckisReady + ")",
									inAssembly, mbAuditData, label1, "INFO",
									Brk_LogLevel, ApplicationName, BusProcId);
					
				}
			}

			/* MultiBroker changes -- END */
			
		}


		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("POST-PROCESSEDCHECKCOUNT","FALSE","End of Checking processed count against the actual inbound",inAssembly, 
						mbAuditData, label1, "DEBUG",Brk_LogLevel, ApplicationName, BusProcId);
			
			AuditLog("END-INBOUND_DBLOADER","FALSE","End of DB Loader Transaction for TransSetId = " + mbTransSetId.getValueAsString()
							+ " TransFileId  = " + mbTransFileId.getValueAsString(), inAssembly,mbAuditData, label1, 
							"INFO", Brk_LogLevel, ApplicationName,BusProcId);
			
		}
		//alt.propagate(inAssembly);
	}

	/**
	 * Code changes to use local audit method instead of common-framework code	
	 */
	public void AuditLog(String TransactionLevel,String PayloadFlag, String AuditMessage, MbMessageAssembly outAssembly, MbElement mbAuditData,MbRoute labelAudit, 
				String appLogLevel,String Brk_LogLevel,String ApplicationName,String busProcId)throws MbException{
			if (Brk_LogLevel.equalsIgnoreCase("DEBUG")
						|| (Brk_LogLevel.equalsIgnoreCase("ERROR") && appLogLevel.equalsIgnoreCase("ERROR"))
						|| (Brk_LogLevel.equalsIgnoreCase("WARN") && (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR")))
						|| (Brk_LogLevel.equalsIgnoreCase("INFO") && (appLogLevel.equalsIgnoreCase("INFO") || (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR"))))) {
					if (mbAuditData.getFirstElementByPath("TransactionLevel") == null) {
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,"loggerAppender", ApplicationName);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"uniqueID", busProcId);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"Payload", PayloadFlag);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"TransactionLevel", TransactionLevel);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AuditMessage", AuditMessage);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AppLogLevel", appLogLevel);
					} else {

						mbAuditData.getFirstElementByPath("TransactionLevel").setValue(TransactionLevel);
						mbAuditData.getFirstElementByPath("Payload").setValue(PayloadFlag);
						mbAuditData.getFirstElementByPath("AuditMessage").setValue(AuditMessage);
						mbAuditData.getFirstElementByPath("AppLogLevel").setValue(appLogLevel) ;
					}
					labelAudit.propagate(outAssembly);
				}
	}
	
	private String getDateTime() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss.SSSSSS");
		return sdf.format(date);
	}
	private String getDate() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		return sdf.format(date);
	}
}

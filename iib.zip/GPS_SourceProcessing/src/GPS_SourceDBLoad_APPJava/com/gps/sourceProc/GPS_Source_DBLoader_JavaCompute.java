package com.gps.sourceProc;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import com.be128.globalcache.GlobalCache;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.ibm.broker.plugin.MbNode.JDBC_TransactionType;

/*-----------------------------------------------------------------------------------------------------------------------------------------------------
 * Module 	   : GPS_Source_DBLoader_JavaCompute

 * Description : This module does following operations:
 1.	Makes connection to database and executes the INSERT queries for batch of members.
 2.	This also updates the Global cache with the processed count and invokes IsReadyToProcess only when processed and actual SOURCE count matches in Global cache Map (BE128_Source_Map).
 3.  Sets the Required parameters in Environment for Audit Logging and Exception Handling.
 4.	�START� and �END� tags are checked in MQRFH2 header to do Entry and Exit of Status code logging for DBLoader for the currently processing TransSetId. 

 * Modification History:
 * * Date 				Author 			       Version 		    Description
 * 24 Feb, 2017 	Nirusha Divyakolu		     1.1 			Initial version
 * 02 May, 2017		Srikanth Yekollu		 	 1.2			Added code for DB Load retry logic incase of any query loading failed.
 * 																	If BATCH_FAIL_MODE is set to TRUE when deployed then whole batch will be failed 
 * 																	as like the existing design. If it is set to 'FALSE' then, new code will find
 * 																 	which query failed and update the ELIG_SYS_TRANS, MBR tables with pend data.
 * 09 may, 2017		Srikanth Yekollu			 1.3			Update the cache with failed subscriberid's so that isReady updates 
 * 																	the ELIG_SYS_TRANS table with status 'S' 
 * 28July, 2017		Srikanth yekollu			 1.4			Changed source count increment method to use incrementAndIsReadyCheckSrc instead of 
 * 																	incrementAndIsReadyCheckInb to synchronize the increment in initial and srcDbLoad
 * -----------------------------------------------------------------------------------------------------------------------------------------------------*/

public class GPS_Source_DBLoader_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		String ApplicationName 	= (String) getUserDefinedAttribute("UDP_ApplicationName");
		String brkrList 		= (String) getUserDefinedAttribute("brkrList");
		String SOURCEMap 		= (String) getUserDefinedAttribute("SourceMap");
		String sDSN 			= (String) getUserDefinedAttribute("DSN");
		String commonMap 		= (String) getUserDefinedAttribute("CommonMap");
		boolean BATCH_FAIL_MODE	= (boolean)getUserDefinedAttribute("BATCH_FAIL_MODE");
		int sleepTime 			= (int) getUserDefinedAttribute("sleepTime");
		String Brk_LogLevel 	= "";
		String Brk_LogSwitch 	= "";

		MbOutputTerminal out 	= getOutputTerminal("out");
		MbOutputTerminal alt 	= getOutputTerminal("alternate");

		MbMessage inMessage 	= inAssembly.getMessage();
		MbElement root 			= inMessage.getRootElement();

		MbMessageAssembly outAssembly = null;

		MbElement globRoot 		= inAssembly.getGlobalEnvironment().getRootElement();
		MbElement mVar 			= globRoot.getFirstElementByPath("Variables");

		if (mVar == null) {
			mVar = globRoot.createElementAsLastChild(MbElement.TYPE_NAME,"Variables", null);
		}

		/*
		 * Accessing Main map in Global Cache
		 */
		MbElement mbTransSetId 	= root.getFirstElementByPath("MQRFH2/usr/TransSetId");
		MbElement mbTransFileId = root.getFirstElementByPath("MQRFH2/usr/TransFileId");
		Brk_LogLevel 			= root.getFirstElementByPath("MQRFH2/usr/Brk_LogLevel").getValueAsString();
		Brk_LogSwitch 			= root.getFirstElementByPath("MQRFH2/usr/Brk_LogSwitch").getValueAsString();
		String SubscriberID 	= root.getFirstElementByPath("MQRFH2/usr/SubscriberID").getValueAsString();
		Random randomGenerator = new Random();
		int randomInt = randomGenerator.nextInt(100000);
		
		if (mbTransFileId == null) {
			throw new MbUserException(this.getClass().getName(),
					"GPS_Source_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error : ",
							"No TransFileId in the MQRFH2 header" });
		}

		if (mbTransSetId == null) {
			throw new MbUserException(this.getClass().getName(),
					"GPS_Source_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error : ",
							"No TransSetId in the MQRFH2 header" });
		}

		String mapContent = GlobalCache.readCache(commonMap,mbTransFileId.getValueAsString() + "_" + mbTransSetId.getValueAsString());
		mVar.createElementAsLastChildFromBitstream(mapContent.getBytes(),MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0); 

		/*
		 * if(mVar.getFirstElementByPath("XMLNSC/CachingLayout/FailureStatus").
		 * getValueAsString().equalsIgnoreCase("Y")) { return; }
		 */
/*
		List list1 = null;
		if (root.getFirstElementByPath("XMLNSC") != null) {
			list1 = (List) root.getFirstElementByPath("XMLNSC/BatchQueries")
					.evaluateXPath("BatchMemberQueries");
		}
*/
		MbRoute label1 = getRoute("AUDIT");

		Connection conn = null;
		Statement stmt = null;
		ResultSet rsx = null;
		
	/*	String custNum = mVar.getFirstElementByPath(
				"XMLNSC/CachingLayout/CustNumber").getValueAsString();*/
		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/BusProcId") == null) {
			throw new MbUserException(
					this.getClass().getName(),
					"GPS_Source_DBLoader_JavaCompute",
					"",
					"",
					"",
					new Object[] {
							"Error : ",
							"No BusProcId in the Global Cache, Expected Structure : CachingLayout/BusProcId" });
		}

		String BusProcId 	= mVar.getFirstElementByPath("XMLNSC/CachingLayout/BusProcId").getValueAsString();
		String InFileName 	= mVar.getFirstElementByPath("XMLNSC/CachingLayout/InFileName").getValueAsString();
		String SubmitterID 	= mVar.getFirstElementByPath("XMLNSC/CachingLayout/SubmitterId").getValueAsString();
		String eligSysCd 	= mVar.getFirstElementByPath("XMLNSC/CachingLayout/eligSysCd").getValueAsString();
		String ReprIndicator= mVar.getFirstElementByPath("XMLNSC/CachingLayout/ReprIndicator").getValueAsString();
		String priorityFlag = mVar.getFirstElementByPath("XMLNSC/CachingLayout/PriorityFlag").getValueAsString();                                             
		

		/* Audit FrameWork Changes -- START */

		MbElement mbAuditData = mVar.createElementAsLastChild(MbElement.TYPE_NAME, "AuditData", "");                             

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("SOURCE_DBLOAD_START",
					"FALSE",
					"Start of DB Loader Transaction for TransSetId = "
							+ mbTransSetId.getValueAsString()
							+ " TransFileId  = "
							+ mbTransFileId.getValueAsString() + " for Batch Unique Id " + randomInt, inAssembly,
					mbAuditData, label1, "INFO", Brk_LogLevel, ApplicationName,
					BusProcId);
			
		}
                                                                              
		/*	 Audit FrameWork Changes -- END */

		/*
		 * File StatusCode Logging
		 */
		MbElement mbUsr = root.getFirstElementByPath("MQRFH2/usr");
		String sMsgFlag = mbUsr.getFirstElementByPath("MsgFlag").getValueAsString();

		if (sMsgFlag.equalsIgnoreCase("START") || sMsgFlag.equalsIgnoreCase("START_END")) {
			Connection connProc = null;
			Statement stmtProc = null;
			for (int i = 1; i <= 3; i++) {
				try {
					connProc = getJDBCType4Connection(sDSN,
							JDBC_TransactionType.MB_TRANSACTION_AUTO);
					stmtProc = connProc.createStatement();
					String time = getDateTime();

					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
							+ "VALUES ('SOURCE_DBLOAD','START','"
							+ time
							+ "',"
							+ BusProcId
							+ ",'SOURCE_PROCESSING','IIB',"
							+ mbTransFileId.getValueAsString()
							+ ","
							+ mbTransSetId.getValueAsString()
							+ ",'','"
							+ InFileName
							+ "','"
							+ "''"
							+ "', '',0,'"
							+ SubmitterID
							+ "','"
							+ time
							+ "','"
							+"')";
					
					stmtProc.execute(sql);                                     
					break;
				} catch (SQLException sqlExcep) {
					if (i == 3) {
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
							AuditLog(
											"SQL-ERROR_PROCFILE",
											"FALSE",
											"Error Loading database even after re-trying 3 times for PROCFILE_START and SQLMsg = "
													+ sqlExcep.getMessage()
													+ ", SQLState = "
													+ sqlExcep.getSQLState()
													+ ", SQLErrorCode = "
													+ sqlExcep.getErrorCode(),
											inAssembly, mbAuditData, label1,
											"ERROR", Brk_LogLevel,
											ApplicationName, BusProcId);                                  
						}
					}
				} finally {
					try {
						if (stmtProc != null) {
							stmtProc.close();
						}
					} catch (SQLException sqlExcepProcStart) {
					}
				}
			}
		}  if (sMsgFlag.equalsIgnoreCase("END") || sMsgFlag.equalsIgnoreCase("START_END") ) {
			Connection connProc = null;
			Statement stmtProc = null;
			for (int i = 1; i <= 3; i++) {
				try {
					connProc = getJDBCType4Connection(sDSN,
							JDBC_TransactionType.MB_TRANSACTION_AUTO);
					stmtProc = connProc.createStatement();
					String time = getDateTime();
					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
							+ "VALUES ('SOURCE_DBLOAD','END','"
							+ time
							+ "',"
							+ BusProcId
							+ ",'SOURCE_PROCESSING','IIB',"
							+ mbTransFileId.getValueAsString()
							+ ","
							+ mbTransSetId.getValueAsString()
							+ ",'','"
							+ InFileName
							+ "','"
							+ "''"
							+ "', '',0,'"
							+ SubmitterID
							+ "','"
							+ time
							+ "','"
							+"')";

					stmtProc.execute(sql);                     
					break;
				} catch (SQLException sqlExcep) {
					if (i == 3) {
					
						if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
							AuditLog(
											"SQL-ERROR_PROCFILE",
											"FALSE",
											"Error Loading database even after re-trying 3 times for PROCFILE_END and SQLMsg = "
													+ sqlExcep.getMessage()
													+ ", SQLState = "
													+ sqlExcep.getSQLState()
													+ ", SQLErrorCode = "
													+ sqlExcep.getErrorCode(),
											inAssembly, mbAuditData, label1,
											"ERROR", Brk_LogLevel,
											ApplicationName, BusProcId);               
						}
						}
				} finally {
					try {
						if (stmtProc != null) {
							stmtProc.close();
						}
					} catch (SQLException sqlExcepProcEnd) {
		
					}
				}
			}
		}

		/*
		 * Makes JDBC batch connection and retries 3 times in case of DB
		 * Failures
		 */
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("PRE-DBLOAD", "FALSE",
					"Start of Loading Database" + " for Batch Unique Id " + randomInt, inAssembly, mbAuditData,
					label1, "INFO", Brk_LogLevel, ApplicationName, BusProcId);                   
			
		}

		boolean batchFailMode = false;
		boolean isRetry = false;  
		//Indices that will hold the insert query index/number for the failed ones incase of a retry 
        ArrayList<Integer> errInsrtQryIndices = new ArrayList<Integer>(); 
		List list1 = null;
		if (root.getFirstElementByPath("XMLNSC") != null) {
			list1 = (List) root.getFirstElementByPath("XMLNSC/BatchQueries").evaluateXPath("BatchMemberQueries");
		}
		
		for (int i = 1; i <= 3; i++) {
			try {
				if (batchFailMode) {
					break;
				}
				conn = getJDBCType4Connection(sDSN,JDBC_TransactionType.MB_TRANSACTION_AUTO);
				//conn.setAutoCommit(false); 
				stmt = conn.createStatement();
				
				int batchQryIdx=0;
				stmt.clearBatch();
				for (int k = 0; k < list1.size(); k++) {
					Boolean isMbrErred=false; 
					MbElement mbBatchMemQueries = (MbElement) list1.get(k);
					List mbTbQueryList = (List) mbBatchMemQueries.evaluateXPath("TableQuery");
					int size = mbTbQueryList.size();
					if (isRetry){
						for(int j = 0; j < size; j++){
							if (errInsrtQryIndices.contains(j+batchQryIdx) && !isMbrErred) {
									isMbrErred = true;
									batchFailMode = true;
									//String updateEligSys ;
									//String insertEligSys;
									//String transId = "";
									
									String failedquery = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
									if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
										AuditLog("FAILED_MEMBER",
												"FALSE",
												"Query failed while Loading to Database for TransSetId = " 
												+ mbTransSetId.getValueAsString() + " first failed query in this member is : " +failedquery , inAssembly, mbAuditData,
												label1, "WARN", Brk_LogLevel, ApplicationName, BusProcId);                   
										
									}
									
									/* Update the cache with failed subscriberid's so that isReady updates the ELIG_SYS_TRANS table with status 'S' */
									String errContent = null;
									String SubscriberList = "";
									boolean ins = false ;
									errContent = GlobalCache.readCache(commonMap,"EE_"+mbTransSetId.getValueAsString());
									if(errContent != null){
										SubscriberList = errContent + ",'" + SubscriberID + "'";
									}else{
										SubscriberList = "'" + SubscriberID + "'";
									}
									ins = GlobalCache.insertCache(commonMap, "EE_"+mbTransSetId.getValueAsString(), SubscriberList);
									
									if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
										AuditLog("UPDATE_CACHE",
												"FALSE",
												"Updated global cache for TransSetId = " 
												+ mbTransSetId.getValueAsString() + " with failed subscriber id " +SubscriberID 
												+ " total subscribers in error are : " +SubscriberList 
												+ "update status is :" + ins , inAssembly, mbAuditData,
												label1, "WARN", Brk_LogLevel, ApplicationName, BusProcId);                   
										
									}
								      
							          
									/*
									String firstQuery = ((MbElement) mbTbQueryList.get(0)).getValueAsString();
									firstQuery = firstQuery.substring(firstQuery.lastIndexOf("(")+1);
									transId = firstQuery.substring(0,firstQuery.indexOf(","));
									
									
									 //ELECELIG.ELIG_SYS_TRANS table changes
									
									
									Statement stmt1 = conn.createStatement();
									String sql = "SELECT TRANS_ID FROM ELECELIG.ELIG_SYS_TRANS " 
													+ "WHERE TRANS_ID = "
													+ transId 
													+ " AND TRANS_SET_ID = "
													+ mbTransSetId.getValueAsString();
									rsx = stmt1.executeQuery(sql);
									if(rsx.next()){
										updateEligSys = "UPDATE ELECELIG.ELIG_SYS_TRANS "
															+ "SET ELIG_TRANS_TYP_CD = 'S' " 
															+ " WHERE TRANS_ID="
															+ transId 
															+ " AND TRANS_SET_ID = "
															+ mbTransSetId.getValueAsString();
										stmt.addBatch(updateEligSys);
									}else{
										String SubscriberID = "";
										if (root.getFirstElementByPath("MQRFH2/usr/SubscriberID") != null) {
											SubscriberID = root.getFirstElementByPath("MQRFH2/usr/SubscriberID").getFirstChild().getValueAsString();
										}
										
										insertEligSys = "INSERT INTO ELECELIG.ELIG_SYS_TRANS " 
												+ "(TRANS_ID,TRANS_SET_ID,ELIG_TRANS_TYP_CD,ELIG_SYS_CD,RSN_CD,LST_UPDT_DT,"
												+ "LST_UPDT_ID,STS_CD,TRANS_APPL_DT,PROC_CTL_REC_CNT,PROC_CTL_REC_NBR,SBSCR_ID," 
												+ "SBMT_GRP_NM,TRANS_CREAT_DTTM,AUX_ID)"
												+ " VALUES (" 
												+ transId
												+ ","
												+ mbTransSetId.getValueAsString()
												+ ","
												+ "'S'"
												+ ",'"
												+ eligSysCd
												+ "',"
												+ "''"
												+ ",'"
												+ getDate()
												+ "','"
												+ BusProcId
												+ "',"
												+ "'29'"
												+ ",'"
												+ getDate()
												+ "','"
												+ "0"
												+ "','"
												+ "0"
												+ "','"
												+ SubscriberID
												+ "','"
												+ SubmitterID
												+ "','" 
												+ getDateTime()
												+ "'," 
												+ "'MEMBER_FAIL_SRC'"
												+ ")";
										stmt.addBatch(insertEligSys);
										
									}
									
									
									  //GPSINBOUND.GPS_MBR table changes
									 
									
							 		sql = "SELECT TRANS_ID FROM GPSSOURCE.GPS_MBR " 
							 					+ "WHERE TRANS_ID = "
							 					+ transId 
							 					+ " AND TRANS_SET_ID = "
							 					+ mbTransSetId.getValueAsString();
							 		rsx = stmt1.executeQuery(sql);
							 		stmt1.clearBatch();
							 		if(rsx.next()){
							 			sql = "UPDATE GPSSOURCE.GPS_MBR SET " 
								 				+"MBR_FST_NM = NULL "
								 				+", MBR_LST_NM = NULL "
								 				//+", HIC_NBR = NULL "
								 				+", MBR_BTH_DT = NULL "
								 				+", BILL_GRP_NBR = NULL "
								 				+ "WHERE TRANS_ID = "
								 				+ transId 
								 				+ " AND TRANS_SET_ID = "
								 				+ mbTransSetId.getValueAsString();
							 		stmt.addBatch(sql);			
							 		
							 		}else{
						 			String MBR_TABLE = "INSERT INTO GPSSOURCE.GPS_MBR (TRANS_ID,TRANS_SET_ID) " +
			 								"VALUES("+Integer.parseInt(transId)+","+Integer.parseInt(mbTransSetId.getValueAsString())+")";
						 			stmt.addBatch(MBR_TABLE);
							 		}
							
							 		if(stmt1 != null){
										stmt1.close();
									}
							 		if (rsx != null) {
										rsx.close();
									}
							 	*/	
									
							}
							
						}
						batchQryIdx = batchQryIdx + size ;
					}else{
						for (int j = 0; j < size; j++) {
							batchQryIdx++;
							String str = ((MbElement) mbTbQueryList.get(j)).getValueAsString();
							if (str != null)
								stmt.addBatch(((MbElement) mbTbQueryList.get(j)).getValueAsString());
							}
					}
				}
				
				stmt.executeBatch();
				stmt.clearBatch();
				break;
			} catch (BatchUpdateException bue) {
				int[] counts = bue.getUpdateCounts();
				int len = counts.length;
				//Not needed 
				//batchFailMode = true; 
				//isRetry=true; 
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
									"FAILED-MESSAGE-FOR-ALL-TABLES-LOAD",
									"FALSE",
									"Logging the Message for which All Tables Load Failure Occured",
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
					
				}
				mbAuditData.getFirstElementByPath("Payload").setValue("FALSE");

				StringBuffer sbTest = new StringBuffer();
				sbTest.append("[");
				for (int k = 0; k < len; k++) {
					sbTest.append(counts[k]).append(",");
					if(counts[k] == Statement.EXECUTE_FAILED){
                        errInsrtQryIndices.add(k);
                  }

				}
				sbTest.append("]");

				SQLException ex = bue.getNextException();
				StringBuffer sbSpecExp = new StringBuffer();
				int k = 1;
				sbSpecExp.append("[");
				while (ex != null) {
					sbSpecExp.append("Specific SQL exception for Query = " + k
							+ "is as === ");
					sbSpecExp.append(" Message: " + ex.getMessage());
					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
					sbSpecExp.append(" Error code: " + ex.getErrorCode());
					sbSpecExp.append(" || ");
					ex = ex.getNextException();
					k++;
				}
				sbSpecExp.append("]");

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
									"ALL-TABLES-LOAD-FAILURE",
									"TRUE",
									"Error Loading All the tables for the Batch...... Batch Response = "
											+ new String(sbTest)
											+ "...... Specific Exception for Every Insert Query = "
											+ new String(sbSpecExp),
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);
					
				}
				
				if(BATCH_FAIL_MODE || /*batchFailMode ||*/ (sbSpecExp.indexOf("The batch is terminated non-atomically")>0 && i==3)){
					 batchFailMode = true; 
	
					 //	GlobalCache.updateCache(commonMap,mbTransFileId.getValueAsString() + "_" + mbTransSetId.getValueAsString(),"FailureStatus=Y;");
				 	
					 throw new MbUserException(
						this.getClass().getName(),"GPS_Inbound_DBLoader_JavaCompute",
						"","","Message : " + bue.getMessage() + "SQLState : "+ bue.getSQLState(),
						new Object[] {"Error Code : 2090","BATCH_FAIL_MODE is set to TRUE / Non-recoverable chain-breaking exception occurred during batch processing. The batch is terminated non-atomically." });
				 }
				
				 //if(BATCH_FAIL_MODE || batchFailMode){ // add batchFailMode if requirement is to fail the batch if   second time also batch failure happen in case of non-automicaly faield messages
				if(sbSpecExp.indexOf("The batch is terminated non-atomically")>0){
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
										"[RETRY]BATCH_TERMINATED_NON_ATOMICALLY_RETRY:"+i,
										"FALSE",
										"The batch is terminated non-atomically, batch will be retried 3 times before failing the message",
										inAssembly, mbAuditData, label1, "ERROR",
										Brk_LogLevel, ApplicationName, BusProcId);
						
					}
					try {
						Thread.sleep(sleepTime);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} // retry after 5 sec
				}else if(BATCH_FAIL_MODE == false){
					isRetry=true;
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog("MEMBER_MARK_TO_FAIL","FALSE",
								 "The batch failed atomically, so will set ELECELIG.ELIG_SYS_TRANS entry to 'S' " +
								 "and continue processing with next batch/member",
								 inAssembly, mbAuditData, label1, "ERROR",Brk_LogLevel, ApplicationName, BusProcId);
						
					}
				}
				
				
				
	
			} catch (SQLException sqlExcep) {
				if (i == 3) {

					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
										"SQL-ERROR",
										"FALSE",
										"Error Loading database even after retrying 3 times",
										inAssembly, mbAuditData, label1,
										"ERROR", Brk_LogLevel, ApplicationName,
										BusProcId);
						
					}
					GlobalCache.updateCache(commonMap,
							mbTransFileId.getValueAsString() + "_"
									+ mbTransSetId.getValueAsString(),
							"FailureStatus=N"); 
					throw new MbUserException(
							this.getClass().getName(),
							"GPS_Inbound_DBLoader_JavaCompute",
							"",
							"",
							"Message : " + sqlExcep.getMessage()
									+ "SQLState : " + sqlExcep.getSQLState(),
							new Object[] { "Error Code : 2080",
									"Error Connecting to Database even after 3 re-tries" });
				}
			} finally {
				if(stmt != null){
					try {
						stmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}


			}
		}

		
		
/*
		boolean retryBatch = false;
		for (int i = 1; i <= 3; i++) {
			try {
				if (retryBatch) {
					break;
				}
				conn = getJDBCType4Connection(sDSN,
						JDBC_TransactionType.MB_TRANSACTION_AUTO);

				stmt = conn.createStatement();

				for (int k = 0; k < list1.size(); k++) {
					MbElement mbBatchMemQueries = (MbElement) list1.get(k);
					List mbTbQueryList = (List) mbBatchMemQueries
							.evaluateXPath("TableQuery");
					for (int j = 0; j < mbTbQueryList.size(); j++) {
						String str = ((MbElement) mbTbQueryList.get(j))
								.getValueAsString();
						if (str != null)
							stmt.addBatch(((MbElement) mbTbQueryList.get(j))
									.getValueAsString());
					}
				}

				stmt.executeBatch();
				stmt.clearBatch();

				break;
			} catch (BatchUpdateException bue) {
				int[] counts = bue.getUpdateCounts();
				int len = counts.length;
				retryBatch = true;

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
		//			AuditLog(
		//							"FAILED-MESSAGE-FOR-ALL-TABLES-LOAD",
		//							"FALSE",
		//							"Logging the Message for which All Tables Load Failure Occured",
		//							inAssembly, mbAuditData, label1, "ERROR",
		//							Brk_LogLevel, ApplicationName, BusProcId);                
		//			
				}
		//		mbAuditData.getFirstElementByPath("Payload").setValue("FALSE");         

				StringBuffer sbTest = new StringBuffer();
				sbTest.append("[");
				for (int k = 0; k < len; k++) {
					sbTest.append(counts[k]).append(",");
				}
				sbTest.append("]");

				SQLException ex = bue.getNextException();
				StringBuffer sbSpecExp = new StringBuffer();
				int k = 1;
				sbSpecExp.append("[");
				while (ex != null) {
					sbSpecExp.append("Specific SQL exception for Query = " + k
							+ "is as === ");
					sbSpecExp.append(" Message: " + ex.getMessage());
					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
					sbSpecExp.append(" Error code: " + ex.getErrorCode());
					sbSpecExp.append(" || ");
					ex = ex.getNextException();
					k++;
				}
				sbSpecExp.append("]");
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
									"ALL-TABLES-LOAD-FAILURE",
									"TRUE",
									"Error Loading All the tables for the Batch...... Batch Response = "
											+ new String(sbTest)
											+ "...... Specific Exception for Every Insert Query = "
											+ new String(sbSpecExp),
									inAssembly, mbAuditData, label1, "ERROR",
									Brk_LogLevel, ApplicationName, BusProcId);   
					
				}

				throw new MbUserException(
						this.getClass().getName(),
						"Source_DBLoader_JavaCompute",
						"",
						"",
						"Message : " + bue.getMessage() + "SQLState : "
								+ bue.getSQLState(),
						new Object[] {
								"Error Code : 2080",
								"Could not load all the tables, check the logs for indiviudal query specific exception" });
			} catch (SQLException sqlExcep) {
				if (i == 3) {
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
										"SQL-ERROR",
										"FALSE",
										"Error Loading database even after retrying 3 times",
										inAssembly, mbAuditData, label1,
										"ERROR", Brk_LogLevel, ApplicationName,
										BusProcId);             
						
					}
					throw new MbUserException(
							this.getClass().getName(),
							"Source_DBLoader_JavaCompute",
							"",
							"",
							"Message : " + sqlExcep.getMessage()
									+ "SQLState : " + sqlExcep.getSQLState(),
							new Object[] { "Error Code : 2080",
									"Error Connecting to Database even after 3 re-tries" });
				}
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
				} catch (SQLException sqlExcepBatStmt) {
						throw new MbUserException(this.getClass().getName(),
							"BE128_Source_DBLoader_JavaCompute", "", "",
							"Message : " + sqlExcepBatStmt.getMessage()
									+ "SQLState : "
									+ sqlExcepBatStmt.getSQLState(),
							new Object[] { "Error Code : 2081",
									"Error while closing the Batch statement" });
				}

			}
		}
		
		*/
		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog("POST-DBLOAD", "FALSE",
					"End of Loading Database for Batch Unique Id " + randomInt, inAssembly, mbAuditData, label1,
					"DEBUG", Brk_LogLevel, ApplicationName, BusProcId);         
			
		}
		/*
		 * 1. Update Processed count in Global cache's Source map 2. Once the
		 * processed and actual counts are equal, then create XML for
		 * IsReadyToProcess
		 */

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog(
							"PRE-PROCESSEDCHECKCOUNT",
							"FALSE",
							"Start of Checking processed count against the actual Source",
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);        
			
		}
		int MemCnt = Integer.parseInt(mbUsr.getFirstElementByPath("MemCount").getValueAsString()); 

		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/SourceFamilyCount") == null) { 
			throw new MbUserException(this.getClass().getName(),
					"Source_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error Code : 2010",
							"No SourceMemberCount in the Global Cache" });
		}

		int SourceMemberCount = Integer.parseInt(mVar.getFirstElementByPath("XMLNSC/CachingLayout/SourceFamilyCount").getValueAsString());

		synchronized (this) {

			/* MultiBroker changes -- START */
			/*String updCheckisReady = GlobalCache.incrementAndIsReadyCheckInb(
					SOURCEMap, mbTransSetId.getValueAsString() + "_"
							+ getBroker().getName(), String.valueOf(MemCnt),
					brkrList);*/
			
			String updCheckisReady = GlobalCache.incrementAndIsReadyCheckSrc(
					SOURCEMap, mbTransSetId.getValueAsString() + "_4_"
							+ getBroker().getName(), String.valueOf(MemCnt),
					brkrList,"Y", "C", "N");
			if (updCheckisReady.equalsIgnoreCase("false")) {

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
							"Source-COUNT:UPDATE:FAIL",
							"FALSE",
							"Update Source count utility failed for transSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "ERROR",
							Brk_LogLevel, ApplicationName, BusProcId);  
					
				}

				if (mVar.getFirstElementByPath(
						"XMLNSC/CachingLayout/FailureStatus")
						.getValueAsString().equalsIgnoreCase("Y")) {
					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
						AuditLog(
								"COMMON GLOBAL CACHE STATUS:FAIL",
								"FALSE",
								"Global cache is in failure status for transSetId = "
										+ mbTransSetId.getValueAsString()
										+ " TransFileId  = "
										+ mbTransFileId.getValueAsString(),
								inAssembly, mbAuditData, label1, "ERROR",
								Brk_LogLevel, ApplicationName, BusProcId);
						
					}
				} else {
					throw new MbUserException(
							this.getClass().getName(),
							"Source_DBLoader_JavaCompute",
							"",
							"2011",
							"",
							new Object[] {
									"2011",
									"USER Error Code:2011  Error Description:GPS_Source_Map value is null for the transet Id:"
											+ mbTransSetId.getValueAsString()
											+ "/ also Global cache status is not in Failure. So failing the message and will set the Global cache Failurestatus to Y" });
				}

			} else if (updCheckisReady.equalsIgnoreCase("Y")) {

				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
							"IN-PROCESSEDCHECKCOUNT",
							"FALSE",
							"Processed and Actual count (" + SourceMemberCount
									+ " )matches for TransSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);  
					
				}
				// create new message as a copy of the input
				MbMessage outMessage = new MbMessage();
				MbElement outRoot = outMessage.getRootElement();
				MbElement mqmd = outRoot.createElementAsFirstChild("MQMD");
				// Prioritizing for FFM files
				if (priorityFlag.equals("Z")) {
					mqmd.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE,"Priority", 9);
				}
					MbElement xmlnsc = outRoot
						.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "ReadyToProcessRequest", null);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"BusProcId", BusProcId);         
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId", mbTransFileId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transSetId", mbTransSetId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"event","SRC");             
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"eventData", SourceMemberCount);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"eligSysCd", eligSysCd);  
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"reprInd",ReprIndicator);         

				outAssembly = new MbMessageAssembly(inAssembly, outMessage);
				out.propagate(outAssembly);
				outMessage.clearMessage();
			if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
							"IS_READY_TO_PROCESS_TRIGGER",
							"FALSE",
							"IsReadyToProcess is triggered for TransSetId = "
									+ mbTransSetId.getValueAsString()
									+ " TransFileId  = "
									+ mbTransFileId.getValueAsString(),
							inAssembly, mbAuditData, label1, "INFO",
							Brk_LogLevel, ApplicationName, BusProcId);       
					
				}

			} else {
				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
					AuditLog(
									"IN-PROCESSEDCHECKCOUNT",
									"FALSE",
									"Processed and Actual count does not match yet for TransSetId = "
											+ mbTransSetId.getValueAsString()
											+ " TransFileId  = "
											+ mbTransFileId.getValueAsString()
											+ ", with current counts in all the Brokers are ( "
											+ updCheckisReady + " ) for Batch Unique Id " + randomInt,
									inAssembly, mbAuditData, label1, "INFO",
									Brk_LogLevel, ApplicationName, BusProcId);        
					
				}
			}

			/* MultiBroker changes -- END */
	}

		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
			AuditLog(
							"POST-PROCESSEDCHECKCOUNT",
							"FALSE",
							"End of Checking processed count against the actual Source",
							inAssembly, mbAuditData, label1, "DEBUG",
							Brk_LogLevel, ApplicationName, BusProcId);      
			
			AuditLog(
					"END-SOURCE_DBLOADER",
					"FALSE",
					"End of DB Loader Transaction for TransSetId = "
							+ mbTransSetId.getValueAsString()
							+ " TransFileId  = "
							+ mbTransFileId.getValueAsString(), inAssembly,
					mbAuditData, label1, "INFO", Brk_LogLevel, ApplicationName,
					BusProcId);                        
			
		}
		alt.propagate(inAssembly);
	}

	/**
	 * Code changes to use local audit method instead of common-framework code	
	 */
	public void AuditLog(String TransactionLevel,String PayloadFlag, String AuditMessage, MbMessageAssembly outAssembly, MbElement mbAuditData,MbRoute labelAudit, 
				String appLogLevel,String Brk_LogLevel,String ApplicationName,String busProcId)throws MbException{
			if (Brk_LogLevel.equalsIgnoreCase("DEBUG")
						|| (Brk_LogLevel.equalsIgnoreCase("ERROR") && appLogLevel.equalsIgnoreCase("ERROR"))
						|| (Brk_LogLevel.equalsIgnoreCase("WARN") && (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR")))
						|| (Brk_LogLevel.equalsIgnoreCase("INFO") && (appLogLevel.equalsIgnoreCase("INFO") || (appLogLevel.equalsIgnoreCase("WARN") || appLogLevel.equalsIgnoreCase("ERROR"))))) {
					if (mbAuditData.getFirstElementByPath("TransactionLevel") == null) {
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,"loggerAppender", ApplicationName);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"uniqueID", busProcId);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"Payload", PayloadFlag);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"TransactionLevel", TransactionLevel);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AuditMessage", AuditMessage);
						mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,"AppLogLevel", appLogLevel);
					} else {

						mbAuditData.getFirstElementByPath("TransactionLevel").setValue(TransactionLevel);
						mbAuditData.getFirstElementByPath("Payload").setValue(PayloadFlag);
						mbAuditData.getFirstElementByPath("AuditMessage").setValue(AuditMessage);
						mbAuditData.getFirstElementByPath("AppLogLevel").setValue(appLogLevel) ;
					}
					labelAudit.propagate(outAssembly);
				}
	}
	
	private String getDateTime() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss.SSSSSS");
		return sdf.format(date);
	}
	/**
	 * Current date in yyyy-MM-dd HH:mm:ss format		
	 */
			private String getDate() {
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				return sdf.format(date);
			}
}

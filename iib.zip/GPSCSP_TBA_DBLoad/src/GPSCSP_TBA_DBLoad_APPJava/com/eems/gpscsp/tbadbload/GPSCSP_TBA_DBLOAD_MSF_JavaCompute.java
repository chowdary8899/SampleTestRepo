package com.eems.gpscsp.tbadbload;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.be128.globalcache.GlobalCache;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRoute;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import common.java.util.CommonUtil;

//import common.java.util.Common_Utility;


public class GPSCSP_TBA_DBLOAD_MSF_JavaCompute extends MbJavaComputeNode {


	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
	String ApplicationName = (String) getUserDefinedAttribute("UDP_ApplicationName");
//		String GlobalCacheInsert_DeleteLater = (String) getUserDefinedAttribute("GlobalCacheInsert_DeleteLater"); // delete
																// added
//		String brkrList = (String) getUserDefinedAttribute("brkrList");
//		String inboundMap = (String) getUserDefinedAttribute("InboundMap");
		String sDSN = (String) getUserDefinedAttribute("DSN");
		String commonMap = (String) getUserDefinedAttribute("CommonMap");
//		String Brk_LogLevel = "";
//		String Brk_LogSwitch = "";

		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbElement root = inMessage.getRootElement();

		MbMessageAssembly outAssembly = null;
		MbElement globRoot = inAssembly.getGlobalEnvironment().getRootElement();
		MbElement mVar = globRoot.getFirstElementByPath("Variables");

		if (mVar == null) {
			mVar = globRoot.createElementAsLastChild(MbElement.TYPE_NAME,
					"Variables", null);
		}

		/*
		 * Accessing Main map in Global Cache
		 */
		
		MbElement mbTransSetId = root
				.getFirstElementByPath("MQRFH2/usr/TransSetId");
		MbElement mbTransFileId = root
				.getFirstElementByPath("MQRFH2/usr/TransFileId");
		
//		MbElement ReprIndicator = N;
//		String ReprIndicator ="N";
		
		MbElement mbGroupId =root.getFirstElementByPath("MQRFH2/usr/GroupId");
		MbElement mbBatchcount=root.getFirstElementByPath("MQRFH2/usr/Batchcount");
		MbElement BatchSequence=root.getFirstElementByPath("MQRFH2/usr/BatchSequence");
		MbElement mbReprIndicator=root.getFirstElementByPath("MQRFH2/usr/ReprIndicator");
		MbElement mbFailureStatus=root.getFirstElementByPath("MQRFH2/usr/FailureStatus");
		MbElement mbsbmtGrpNm =root.getFirstElementByPath("MQRFH2/usr/sbmtGrpNm");
		MbElement mbBusProcId =root.getFirstElementByPath("MQRFH2/usr/BusProcId");
		MbElement mbeligSysCd =root.getFirstElementByPath("MQRFH2/usr/eligSysCd");
		
		MbElement mbfileCompl =root.getFirstElementByPath("MQRFH2/usr/lastSetInd");
		
		
		
		
		
		
		
//		MbElement outRoot = outMessage.getRootElement();
		
		
		
	//	Brk_LogLevel = root
	//			.getFirstElementByPath("MQRFH2/usr/Brk_LogLevel").getValueAsString();
	//	Brk_LogSwitch = root
		//		.getFirstElementByPath("MQRFH2/usr/Brk_LogSwitch").getValueAsString();
		if (mbTransFileId == null) {
			throw new MbUserException(this.getClass().getName(),
					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error : ",
							"No TransFileId in the MQRFH2 header" });
		}

		if (mbTransSetId == null) {
			throw new MbUserException(this.getClass().getName(),
					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
					new Object[] { "Error : ",
							"No TransSetId in the MQRFH2 header" });
		}
		
//		String mapContent = GlobalCache.readCache(
//				commonMap,
//				mbTransFileId.getValueAsString() + "_"
//						+ mbTransSetId.getValueAsString());
//		mVar.createElementAsLastChildFromBitstream(mapContent.getBytes(),
//				MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0);

		/*
		 * if(mVar.getFirstElementByPath("XMLNSC/CachingLayout/FailureStatus").
		 * getValueAsString().equalsIgnoreCase("Y")) { return; }
		 */

		List list1 = null;
		if (root.getFirstElementByPath("XMLNSC") != null) {
			list1 = (List) root.getFirstElementByPath("XMLNSC/BatchQueries")
					.evaluateXPath("BatchMemberQueries");
		}

		MbRoute label1 = getRoute("AUDIT");

		Connection conn = null;
		Statement stmt = null;
//
//		String custNum = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/CustomerNumber").getValueAsString();
//		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/BusProcId") == null) {
//			throw new MbUserException(
//					this.getClass().getName(),
//					"BE128_Inbound_DBLoader_JavaCompute",
//					"",
//					"",
//					"",
//					new Object[] {
//							"Error : ",
//							"No BusProcId in the Global Cache, Expected Structure : CachingLayout/BusProcId" });
//		}
//
//		String BusProcId = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/BusProcId").getValueAsString();
//		String InFileName = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/InFileName").getValueAsString();
//		String SubmitterID = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/AssignedSubmitterName")
//				.getValueAsString();
//		String eligSysCd = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/eligSysCd").getValueAsString();
//		String ReprIndicator = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/ReprIndicator").getValueAsString();
//		String priorityFlag = mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/PriorityFlag").getValueAsString();

		/*
		 * Setting Environment Variables for Audit Logging
		 */
		// MbElement mbAuditData
//		 =mVar.createElementAsLastChild(MbElement.TYPE_NAME, "AuditData", "");
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,
		// "loggerAppender", ApplicationName);
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "uniqueID", BusProcId);
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "Payload", "FALSE");

		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "TransactionLevel", "START-INBOUND_DBLOADER");
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "AuditMessage", "Start of DB Loader Transaction for TransSetId = " +
		// mbTransSetId.getValueAsString()+ " TransFileId  = "+
		// mbTransFileId.getValueAsString());
		// //label1.propagate(inAssembly);

		/* Audit FrameWork Changes -- START */

		MbElement mbAuditData = mVar.createElementAsLastChild(
				MbElement.TYPE_NAME, "AuditData", "");
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME,
		// "loggerAppender", ApplicationName);
		// mbAuditData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,
		// "uniqueID", BusProcId);

		/* MbElement mVarAudit =
		 root.getFirstElementByPath("MQRFH2/usr/BrkConfig/XMLNSC/BRK_CONFIG");

		if (mVarAudit != null) {
			Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,
					getBroker().getName(), mVarAudit);
		} else {*/
//			MbElement mVarCache = mVar.createElementAsLastChild(
//					MbElement.TYPE_NAME, "ConfigCacheXML", null);
//			CommonUtil.readBkrConfigCacheXML(BrkConfigKey, varGCMapName,
//					mVarCache, SchemaName);
//			MbElement mVarCacheConfig = mVarCache
//					.getFirstElementByPath("XMLNSC/BRK_CONFIG");
//			Brk_LogLevel_LogSwitch = CommonUtil.readBrkConfig(ApplicationName,
//					getBroker().getName(), mVarCacheConfig);

//		}

//		Brk_LogLevel = Brk_LogLevel_LogSwitch.substring(0,
//				Brk_LogLevel_LogSwitch.indexOf(","));
//		Brk_LogSwitch = Brk_LogLevel_LogSwitch.substring(Brk_LogLevel_LogSwitch
//				.indexOf(",") + 1);

//		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
//			CommonUtil.AuditLog(
//					"INBOUND_DBLOAD_START",
//					"FALSE",
//					"Start of DB Loader Transaction for TransSetId = "
//							+ mbTransSetId.getValueAsString()
//							+ " TransFileId  = "
//							+ mbTransFileId.getValueAsString(), inAssembly,
//					mbAuditData, label1, "INFO", Brk_LogLevel, ApplicationName,
//					BusProcId);
//			// label1.propagate(inAssembly);
//		}

		/* Audit FrameWork Changes -- END */

		/*
		 * File StatusCode Logging
		 */
//		MbElement mbUsr = root.getFirstElementByPath("MQRFH2/usr");
//		String sMsgFlag = mbUsr.getFirstElementByPath("MsgFlag")
//				.getValueAsString();
//		if (mbUsr.getFirstElementByPath("SplitFileNumber") == null) {
//			throw new MbUserException(this.getClass().getName(),
//					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
//					new Object[] { "Error Code : 5001",
//							"Np MiniSplit file count in MQRFH2 header" });
//		}

//		if (sMsgFlag.equalsIgnoreCase("START")) {
//			Connection connProc = null;
//			Statement stmtProc = null;
//			for (int i = 1; i <= 3; i++) {
//				try {
//					connProc = getJDBCType4Connection(sDSN,
//							JDBC_TransactionType.MB_TRANSACTION_AUTO);
//					stmtProc = connProc.createStatement();
//					String time = getDateTime();
//
//					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
//							+ "VALUES ('INBOUND_DBLOAD','START','"
//							+ time
//							+ "',"
//							+ BusProcId
//							+ ",'INBOUND_PROCESSING','IIB',"
//							+ mbTransFileId.getValueAsString()
//							+ ","
//							+ mbTransSetId.getValueAsString()
//							+ ",'','"
//							+ InFileName
//							+ "','"
//							+ custNum
//							+ "', '',0,'"
//							+ SubmitterID
//							+ "','"
//							+ time
//							+ "','MiniFile_"
//							+ mbUsr.getFirstElementByPath("SplitFileNumber")
//									.getValueAsString() + "')";
//					stmtProc.execute(sql);
//					break;
//				} catch (SQLException sqlExcep) {
//					if (i == 3) {
//						/*
//						 * mbAuditData.getFirstElementByPath("TransactionLevel").
//						 * setValue("SQL-ERROR_PROCFILE");
//						 * mbAuditData.getFirstElementByPath
//						 * ("AuditMessage").setValue(
//						 * "Error Loading database even after re-trying 3 times for PROCFILE_START and SQLMsg = "
//						 * + sqlExcep.getMessage() + ", SQLState = " +
//						 * sqlExcep.getSQLState() + ", SQLErrorCode = " +
//						 * sqlExcep.getErrorCode());
//						 * //label1.propagate(inAssembly);
//						 */
////						if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
////							CommonUtil
////									.AuditLog(
////											"SQL-ERROR_PROCFILE",
////											"FALSE",
////											"Error Loading database even after re-trying 3 times for PROCFILE_START and SQLMsg = "
////													+ sqlExcep.getMessage()
////													+ ", SQLState = "
////													+ sqlExcep.getSQLState()
////													+ ", SQLErrorCode = "
////													+ sqlExcep.getErrorCode(),
////											inAssembly, mbAuditData, label1,
////											"ERROR", Brk_LogLevel,
////											ApplicationName, BusProcId);
////							// //label1.propagate(inAssembly);
////						}
//						// GlobalCache.updateCache(commonMap,
//						// mbTransFileId.getValueAsString() + "_" +
//						// mbTransSetId.getValueAsString(), "FailureStatus=Y");
//
//						// throw new MbUserException(this.getClass().getName(),
//						// "BE128_Inbound_DBLoader_JavaCompute", "", "",
//						// "Message : "+ sqlExcep.getMessage() + "SQLState : "+
//						// sqlExcep.getSQLState(), new
//						// Object[]{"Error Code : 5001",
//						// "Proc File DB exception, even after 3 retries"});
//					}
//				} finally {
//					try {
//						if (stmtProc != null) {
//							stmtProc.close();
//						}
//					} catch (SQLException sqlExcepProcStart) {
//						// GlobalCache.updateCache(commonMap,
//						// mbTransFileId.getValueAsString() + "_" +
//						// mbTransSetId.getValueAsString(), "FailureStatus=Y");
//						// throw new MbUserException(this.getClass().getName(),
//						// "BE128_Inbound_DBLoader_JavaCompute", "", "",
//						// "Message : "+ sqlExcepProcStart.getMessage() +
//						// "SQLState : "+ sqlExcepProcStart.getSQLState(), new
//						// Object[]{"Error Code : 5001",
//						// "Error while closing the statment of ProcFile START event"});
//					}
//				}
//			}
//		} else if (sMsgFlag.equalsIgnoreCase("END")) {
//			Connection connProc = null;
//			Statement stmtProc = null;
//			for (int i = 1; i <= 3; i++) {
//				try {
//					connProc = getJDBCType4Connection(sDSN,
//							JDBC_TransactionType.MB_TRANSACTION_AUTO);
//					stmtProc = connProc.createStatement();
//					String time = getDateTime();
//					String sql = "INSERT INTO ELECELIG.PROC_FL_STS "
//							+ "VALUES ('INBOUND_DBLOAD','END','"
//							+ time
//							+ "',"
//							+ BusProcId
//							+ ",'INBOUND_PROCESSING','IIB',"
//							+ mbTransFileId.getValueAsString()
//							+ ","
//							+ mbTransSetId.getValueAsString()
//							+ ",'','"
//							+ InFileName
//							+ "','"
//							+ custNum
//							+ "', '',0,'"
//							+ SubmitterID
//							+ "','"
//							+ time
//							+ "','MiniFile_"
//							+ mbUsr.getFirstElementByPath("SplitFileNumber")
//									.getValueAsString() + "')";
//
//					stmtProc.execute(sql);
//					break;
//				} catch (SQLException sqlExcep) {
//					if (i == 3) {
//						/*
//						 * mbAuditData.getFirstElementByPath("TransactionLevel").
//						 * setValue("SQL-ERROR_PROCFILE");
//						 * mbAuditData.getFirstElementByPath
//						 * ("AuditMessage").setValue(
//						 * "Error Loading database even after re-trying 3 times for PROCFILE_END and SQLMsg = "
//						 * + sqlExcep.getMessage() + ", SQLState = " +
//						 * sqlExcep.getSQLState() + ", SQLErrorCode = " +
//						 * sqlExcep.getErrorCode());
//						 * ////label1.propagate(inAssembly);
//						 */
////						if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
////							CommonUtil
////									.AuditLog(
////											"SQL-ERROR_PROCFILE",
////											"FALSE",
////											"Error Loading database even after re-trying 3 times for PROCFILE_END and SQLMsg = "
////													+ sqlExcep.getMessage()
////													+ ", SQLState = "
////													+ sqlExcep.getSQLState()
////													+ ", SQLErrorCode = "
////													+ sqlExcep.getErrorCode(),
////											inAssembly, mbAuditData, label1,
////											"ERROR", Brk_LogLevel,
////											ApplicationName, BusProcId);
////							// //label1.propagate(inAssembly);
////						}
//						// GlobalCache.updateCache(commonMap,
//						// mbTransFileId.getValueAsString() + "_" +
//						// mbTransSetId.getValueAsString(), "FailureStatus=Y");
//
//						// throw new MbUserException(this.getClass().getName(),
//						// "BE128_Inbound_DBLoader_JavaCompute", "", "",
//						// "Message : "+ sqlExcep.getMessage() + "SQLState : "+
//						// sqlExcep.getSQLState(), new
//						// Object[]{"Error Code : 5001",
//						// "Proc File DB exception, even after 3 retries"});
//					}
//				} finally {
//					try {
//						if (stmtProc != null) {
//							stmtProc.close();
//						}
//					} catch (SQLException sqlExcepProcEnd) {
//						// throw new MbUserException(this.getClass().getName(),
//						// "BE128_Inbound_DBLoader_JavaCompute", "", "",
//						// "Message : "+ sqlExcepProcEnd.getMessage() +
//						// "SQLState : "+ sqlExcepProcEnd.getSQLState(), new
//						// Object[]{"Error Code : 5001",
//						// "Error while closing the statment of ProcFile END event"});
//					}
//				}
//			}
//			/*
//			 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
//			 * "END-INBOUND_DBLOADER_TRANSETID");
//			 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
//			 * "End of DBLoad Operation for the entire TranSetId = " +
//			 * mbTransSetId.getValueAsString() + " with MiniFile = " +
//			 * mbUsr.getFirstElementByPath
//			 * ("SplitFileNumber").getValueAsString());
//			 * ////label1.propagate(inAssembly);
//			 */
////			if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
////				CommonUtil
////						.AuditLog(
////								"END-INBOUND_DBLOADER_TRANSETID",
////								"FALSE",
////								"End of DBLoad Operation for the entire TranSetId = "
////										+ mbTransSetId.getValueAsString()
////										+ " with MiniFile = "
////										+ mbUsr.getFirstElementByPath(
////												"SplitFileNumber")
////												.getValueAsString(),
////								inAssembly, mbAuditData, label1, "DEBUG",
////								Brk_LogLevel, ApplicationName, BusProcId);
////				// //label1.propagate(inAssembly);
////			}
//			return;
//		}

		/*
		 * Makes JDBC batch connection and retries 3 times in case of DB
		 * Failures
		 */
		/*
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "PRE-DBLOAD");
		 * mbAuditData.getFirstElementByPath("AuditMessage").setValue
		 * ("Start of Loading Database"); //label1.propagate(inAssembly);
		 */
//		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
//			CommonUtil.AuditLog("PRE-DBLOAD", "FALSE",
//					"Start of Loading Database", inAssembly, mbAuditData,
//					label1, "INFO", Brk_LogLevel, ApplicationName, BusProcId);
//			// label1.propagate(inAssembly);
//		}

		boolean retryBatch = false;
		for (int i = 1; i <= 3; i++) {
			try {
				if (retryBatch) {
					break;
				}
				conn = getJDBCType4Connection(sDSN,
						JDBC_TransactionType.MB_TRANSACTION_AUTO);

				stmt = conn.createStatement();

				for (int k = 0; k < list1.size(); k++) {
					MbElement mbBatchMemQueries = (MbElement) list1.get(k);
					List mbTbQueryList = (List) mbBatchMemQueries
							.evaluateXPath("TableQuery");
					for (int j = 0; j < mbTbQueryList.size(); j++) {
						String str = ((MbElement) mbTbQueryList.get(j))
								.getValueAsString();
						str = str.replaceAll("\'NULL\'", "NULL");
						//str = str.replaceAll("\'INSERT INTO","INSERT INTO");
						//str = str.replaceAll(");\'",");");
						
						
						
						if (str != null)
							stmt.addBatch(((MbElement) mbTbQueryList.get(j))
									.getValueAsString());
					}
				}

				stmt.executeBatch();
				stmt.clearBatch();

				///-----------------------Actual chnages-----------------------------------
			
			MbMessage outMessage = new MbMessage();
				MbElement outRoot = outMessage.getRootElement();
			MbElement xmlnsc = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "TBATRACKER", null);
//				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transSetId", mbTransSetId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "GroupId", mbGroupId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId",mbBusProcId.getValueAsString());
			    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
			    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"eligSysCd",mbeligSysCd.getValueAsString());
			    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "ReprIndicator",mbReprIndicator.getValueAsString());
//				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "ReprIndicator",N);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
				out.propagate(outAssembly);
				outMessage.clearMessage();
				break;
		
				//-------------------------------Changes end---------------------------------
				

				
//				CommonUtil.("UPDATE", mbTransSetId.getValueAsString(),mbGroupId.getValueAsString(),"C");
				
				
				
//				stmt.clearBatch();
				
				/*MbElement mbBatchcount=root.getFirstElementByPath("MQRFH2/usr/Batchcount");
				MbElement BatchSequence=
*/
//				if(mbBatchcount.getValueAsString().equalsIgnoreCase(BatchSequence.getValueAsString())){
//					//call here
//				}
				
//				break;
			} catch (BatchUpdateException bue) {
//				int[] counts = bue.getUpdateCounts();
//				int len = counts.length;
//				retryBatch = true;
////				CommonUtil.CallTBA_Tracker("UPDATE", mbTransSetId.getValueAsString(),mbGroupId.getValueAsString(),"F");
//
//				/*
//				 * mbAuditData.getFirstElementByPath("Payload").setValue("TRUE");
//				 * mbAuditData
//				 * .getFirstElementByPath("TransactionLevel").setValue
//				 * ("FAILED-MESSAGE-FOR-ALL-TABLES-LOAD");
//				 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
//				 * "Logging the Message for which All Tables Load Failure Occured"
//				 * ); //label1.propagate(inAssembly);
//				 */
////				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
////					CommonUtil
////							.AuditLog(
////									"FAILED-MESSAGE-FOR-ALL-TABLES-LOAD",
////									"FALSE",
////									"Logging the Message for which All Tables Load Failure Occured",
////									inAssembly, mbAuditData, label1, "ERROR",
////									Brk_LogLevel, ApplicationName, BusProcId);
////					// label1.propagate(inAssembly);
////				}
//				mbAuditData.getFirstElementByPath("Payload").setValue("FALSE");
//
//				StringBuffer sbTest = new StringBuffer();
//				sbTest.append("[");
//				for (int k = 0; k < len; k++) {
//					sbTest.append(counts[k]).append(",");
//				}
//				sbTest.append("]");
//
//				SQLException ex = bue.getNextException();
//				StringBuffer sbSpecExp = new StringBuffer();
//				int k = 1;
//				sbSpecExp.append("[");
//				while (ex != null) {
//					sbSpecExp.append("Specific SQL exception for Query = " + k
//							+ "is as === ");
//					sbSpecExp.append(" Message: " + ex.getMessage());
//					sbSpecExp.append(" SQLSTATE: " + ex.getSQLState());
//					sbSpecExp.append(" Error code: " + ex.getErrorCode());
//					sbSpecExp.append(" || ");
//					ex = ex.getNextException();
//					k++;
//				}
//				sbSpecExp.append("]");
//----------------------------TBA CHANGES START-------------------------------------------------------------------------------
				MbMessage outMessage = new MbMessage();
				MbElement outRoot = outMessage.getRootElement();
			MbElement xmlnsc = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "TBAFAIL", null);
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId",mbBusProcId.getValueAsString());
			    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
//				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transSetId", mbTransSetId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "GroupId", mbGroupId.getValueAsString());
				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eligSysCd", mbeligSysCd.getValueAsString());
			    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "ReprIndicator",mbReprIndicator.getValueAsString());
//				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "ReprIndicator",N);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
				out.propagate(outAssembly);
				outMessage.clearMessage();
				
				
//				--------------------------------------TBA CHANGES END--------------------------------------------------------
				
				
				
				
				
				
				
				/*
				 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue
				 * ("ALL-TABLES-LOAD-FAILURE");
				 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
				 * "Error Loading All the tables for the Batch...... Batch Response = "
				 * +new String(sbTest) +
				 * "...... Specific Exception for Every Insert Query = " + new
				 * String(sbSpecExp)); //label1.propagate(inAssembly);
				 */
//				if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
//					CommonUtil
//							.AuditLog(
//									"ALL-TABLES-LOAD-FAILURE",
//									"TRUE",
//									"Error Loading All the tables for the Batch...... Batch Response = "
//											+ new String(sbTest)
//											+ "...... Specific Exception for Every Insert Query = "
//											+ new String(sbSpecExp),
//									inAssembly, mbAuditData, label1, "ERROR",
//									Brk_LogLevel, ApplicationName, BusProcId);
//					// label1.propagate(inAssembly);
//				}
//				GlobalCache.updateCache(
//						commonMap,
//						mbTransFileId.getValueAsString() + "_"
//								+ mbTransSetId.getValueAsString(),
//						"FailureStatus=Y;");

//				throw new MbUserException(
//						this.getClass().getName(),
//						"BE128_Inbound_DBLoader_JavaCompute",
//						"",
//						"",
//						"Message : " + bue.getMessage() + "SQLState : "
//								+ bue.getSQLState(),
//						new Object[] {
//								"Error Code : 2080",
//								"Could not load all the tables, check the logs for indiviudal query specific exception" });
			} catch (SQLException sqlExcep) {
				if (i == 3) {
					/*
					 * mbAuditData.getFirstElementByPath("TransactionLevel").
					 * setValue("SQL-ERROR");
					 * mbAuditData.getFirstElementByPath("AuditMessage"
					 * ).setValue
					 * ("Error Loading database even after retrying 3 times");
					 * //label1.propagate(inAssembly);
					 */
//					if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
//						CommonUtil
//								.AuditLog(
//										"SQL-ERROR",
//										"FALSE",
//										"Error Loading database even after retrying 3 times",
//										inAssembly, mbAuditData, label1,
//										"ERROR", Brk_LogLevel, ApplicationName,
//										BusProcId);
//						// label1.propagate(inAssembly);
//					}
//					GlobalCache.updateCache(commonMap,
//							mbTransFileId.getValueAsString() + "_"
//									+ mbTransSetId.getValueAsString(),
//							"FailureStatus=Y");
//-------------------------TBA CHANGES START---------------------
					MbMessage outMessage = new MbMessage();
					MbElement outRoot = outMessage.getRootElement();
				MbElement xmlnsc = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
					MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "TBAFAIL", null);
//					rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
					rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transSetId", mbTransSetId.getValueAsString());
					rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "GroupId", mbGroupId.getValueAsString());
					rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId",mbBusProcId.getValueAsString());
				    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
					rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eligSysCd", mbeligSysCd.getValueAsString());
					rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "ReprIndicator",mbReprIndicator.getValueAsString());
				outAssembly = new MbMessageAssembly(inAssembly, outMessage);
					out.propagate(outAssembly);
					outMessage.clearMessage();
					
					
					
					
					
					
					
					
					
					
					
					
					
//					---------------------------TBA CHANGES END---------------------------------
					//					throw new MbUserException(
//							this.getClass().getName(),
//							"BE128_Inbound_DBLoader_JavaCompute",
//							"",
//							"",
//							"Message : " + sqlExcep.getMessage()
//									+ "SQLState : " + sqlExcep.getSQLState(),
//							new Object[] { "Error Code : 2080",
//									"Error Connecting to Database even after 3 re-tries" });
				}
			} finally {
////TBA CHANGES START--------------------------------------------
//				MbMessage outMessage = new MbMessage();
//				MbElement outRoot = outMessage.getRootElement();
//			MbElement xmlnsc = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
//				MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "TBAFAIL", null);
////				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
//				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transSetId", mbTransSetId.getValueAsString());
//				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "GroupId", mbGroupId.getValueAsString());
////				rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "ReprIndicator",N);
//			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
//				out.propagate(outAssembly);
//				outMessage.clearMessage();
				
				
//				TBA CHANGES END
				
				
				
				
				
				
				
				
				
				
				//				try {
//					if (stmt != null) {
//						stmt.close();
//					}
//				} catch (SQLException sqlExcepBatStmt) {
//					GlobalCache.updateCache(commonMap,
//							mbTransFileId.getValueAsString() + "_"
//									+ mbTransSetId.getValueAsString(),
//							"FailureStatus=Y");
//					throw new MbUserException(this.getClass().getName(),
//							"BE128_Inbound_DBLoader_JavaCompute", "", "",
//							"Message : " + sqlExcepBatStmt.getMessage()
//									+ "SQLState : "
//									+ sqlExcepBatStmt.getSQLState(),
//							new Object[] { "Error Code : 2081",
//									"Error while closing the Batch statement" });
				}

			}
//		}
		/*
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "POST-DBLOAD");
		 * mbAuditData.getFirstElementByPath("AuditMessage").setValue
		 * ("End of Loading Database"); //label1.propagate(inAssembly);
		 */
//		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
//			CommonUtil.AuditLog("POST-DBLOAD", "FALSE",
//					"End of Loading Database", inAssembly, mbAuditData, label1,
//					"DEBUG", Brk_LogLevel, ApplicationName, BusProcId);
//			// label1.propagate(inAssembly);
//		}
		/*
		 * 1. Update Processed count in Global cache's inbound map 2. Once the
		 * processed and actual counts are equal, then create XML for
		 * IsReadyToProcess
		 */

		/*
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "PRE-PROCESSEDCHECKCOUNT");
		 * mbAuditData.getFirstElementByPath("AuditMessage"
		 * ).setValue("Start of Checking processed count against the actual inbound"
		 * ); //label1.propagate(inAssembly);
		 */
//		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
//			CommonUtil
//					.AuditLog(
//							"PRE-PROCESSEDCHECKCOUNT",
//							"FALSE",
//							"Start of Checking processed count against the actual inbound",
//							inAssembly, mbAuditData, label1, "DEBUG",
//							Brk_LogLevel, ApplicationName, BusProcId);
//			// label1.propagate(inAssembly);
//		}
//		int MemCnt = Integer.parseInt(mbUsr
//				.getFirstElementByPath("MemberCount").getValueAsString());
		// int ActualMemberCount =
		// Integer.parseInt(mbUsr.getFirstElementByPath("ActualMemberCount").getValueAsString());

//		if (mVar.getFirstElementByPath("XMLNSC/CachingLayout/InboundMemberCount") == null) {
//			throw new MbUserException(this.getClass().getName(),
//					"BE128_Inbound_DBLoader_JavaCompute", "", "", "",
//					new Object[] { "Error Code : 2010",
//							"No InboundMemberCount in the Global Cache" });
//		}

//		int InboundMemberCount = Integer.parseInt(mVar.getFirstElementByPath(
//				"XMLNSC/CachingLayout/InboundMemberCount").getValueAsString());

		synchronized (this) {

			if(mbBatchcount.getValueAsString().equalsIgnoreCase(BatchSequence.getValueAsString()))
			{
			if(mbfileCompl.getValueAsString().equalsIgnoreCase("Y")){
			
			//			if(procCnt != actCnt)
			
			
		//new changes start//	
			
			MbMessage outMessage = new MbMessage();
			MbElement outRoot = outMessage.getRootElement();
			MbElement xmlnsc = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			MbElement rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME, "TBAREQUEST", null);
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId",mbTransFileId.getValueAsString());
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "transSetId", mbTransSetId.getValueAsString());
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "GroupId", mbGroupId.getValueAsString());
		    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "ReprIndicator",mbReprIndicator.getValueAsString());
		    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "FailureStatus",mbFailureStatus.getValueAsString());
		    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "sbmtGrpNm",mbsbmtGrpNm.getValueAsString());
		    rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId",mbBusProcId.getValueAsString());
			rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eligSysCd", mbeligSysCd.getValueAsString());

		    
		    
		    
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			out.propagate(outAssembly);
			outMessage.clearMessage();
		//new changes end//
			}
			
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			/*
			 * if(procCnt != actCnt) { GlobalCache.insertCache(inboundMap,
			 * mbTransSetId.getValueAsString(), Integer.toString(actCnt)+ "," +
			 * Integer.toString(procCnt));
			 * 
			 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
			 * "IN-PROCESSEDCHECKCOUNT");
			 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
			 * "Processed and Actual count does not matche for TransSetId = " +
			 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
			 * mbTransFileId.getValueAsString() +
			 * ", with current counts as (ActualCount,Processed Count) = (" +
			 * Integer.toString(actCnt) + ", " + Integer.toString(procCnt) +
			 * ")"); //label1.propagate(inAssembly); } else {
			 * mbAuditData.getFirstElementByPath
			 * ("TransactionLevel").setValue("IN-PROCESSEDCHECKCOUNT");
			 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
			 * "Processed and Actual count matches for TransSetId = " +
			 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
			 * mbTransFileId.getValueAsString() +
			 * ", with current counts as (ActualCount,Processed Count) = (" +
			 * Integer.toString(actCnt) + ", " + Integer.toString(procCnt) +
			 * ")"); //label1.propagate(inAssembly);
			 * 
			 * //create new message as a copy of the input MbMessage outMessage
			 * = new MbMessage(); MbElement outRoot =
			 * outMessage.getRootElement(); MbElement mqmd =
			 * outRoot.createElementAsFirstChild("MQMD"); //Prioritizing for FFM
			 * files if ( priorityFlag.equals("Z")){
			 * mqmd.createElementAsFirstChild
			 * (MbElement.TYPE_NAME_VALUE,"Priority",9); } MbElement xmlnsc =
			 * outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME); MbElement
			 * rootEle = xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME,
			 * "ReadyToProcessRequest", null);
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "BusProcId",
			 * BusProcId);
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,"transFileId"
			 * ,mbTransFileId.getValueAsString());
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
			 * "transSetId", mbTransSetId.getValueAsString());
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "event",
			 * "INB"); rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
			 * "eventData", procCnt);
			 * rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "eligSysCd",
			 * eligSysCd); rootEle.createElementAsLastChild(MbXMLNSC.ATTRIBUTE,
			 * "reprInd", ReprIndicator);
			 * 
			 * outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			 * out.propagate(outAssembly); outMessage.clearMessage();
			 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
			 * "IS_READY_TO_PROCESS_TRIGGER");
			 * mbAuditData.getFirstElementByPath("AuditMessage").setValue(
			 * "IsReadyToProcess is triggered for TransSetId = " +
			 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
			 * mbTransFileId.getValueAsString());
			 * //label1.propagate(inAssembly);
			 * 
			 * GlobalCache.insertCache(inboundMap,
			 * mbTransSetId.getValueAsString(), Integer.toString(actCnt)+ "," +
			 * Integer.toString(procCnt)); }
			 */
		}

		/*
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "POST-PROCESSEDCHECKCOUNT");
		 * mbAuditData.getFirstElementByPath("AuditMessage"
		 * ).setValue("End of Checking processed count against the actual inbound"
		 * ); //label1.propagate(inAssembly);
		 * 
		 * mbAuditData.getFirstElementByPath("TransactionLevel").setValue(
		 * "END-INBOUND_DBLOADER");
		 * mbAuditData.getFirstElementByPath("AuditMessage"
		 * ).setValue("End of DB Loader Transaction for TransSetId = " +
		 * mbTransSetId.getValueAsString()+ " TransFileId  = "+
		 * mbTransFileId.getValueAsString()); //label1.propagate(inAssembly);
		 */
//		if (Brk_LogSwitch.equalsIgnoreCase("ON")) {
//			CommonUtil
//					.AuditLog(
//							"POST-PROCESSEDCHECKCOUNT",
//							"FALSE",
//							"End of Checking processed count against the actual inbound",
//							inAssembly, mbAuditData, label1, "DEBUG",
//							Brk_LogLevel, ApplicationName, BusProcId);
//			// label1.propagate(inAssembly);
//			CommonUtil.AuditLog(
//					"END-INBOUND_DBLOADER",
//					"FALSE",
//					"End of DB Loader Transaction for TransSetId = "
//							+ mbTransSetId.getValueAsString()
//							+ " TransFileId  = "
//							+ mbTransFileId.getValueAsString(), inAssembly,
//					mbAuditData, label1, "INFO", Brk_LogLevel, ApplicationName,
//					BusProcId);
//			// label1.propagate(inAssembly);
//		}
		
	
		
		
		
		alt.propagate(inAssembly);
//		
//		if(mbBatchcount.getValueAsString().equalsIgnoreCase(BatchSequence.getValueAsString())){
//			out.propagate(inAssembly);//trial
//		}
//		out.propagate(inAssembly);/actual
	}

	private String getDateTime() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss.SSSSSS");
		return sdf.format(date);
	}

}
